﻿using System;
using System.Collections.Generic;
using System.Data;
using System.DirectoryServices.AccountManagement;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Login2 : System.Web.UI.Page
{
    #region VariableDeclare
    LoginModule obj = new LoginModule();
    #endregion
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            btnUserLogin.Focus();
            if (Session["EmpCode"] != null)
            {
                Response.Redirect("Dashboard.aspx");
            }
            else
            {
                // Generate a new CSRF token
                ViewState["CSRFToken"] = Guid.NewGuid().ToString();
                hiddenCsrfToken.Value = ViewState["CSRFToken"].ToString();
            }
        }
    }
    #region LoginUser
    protected void btnUserLogin_Click(object sender, EventArgs e)
    {
        if (ViewState["CSRFToken"] != null && ViewState["CSRFToken"].ToString() == hiddenCsrfToken.Value)
        {
            string UserId = string.Empty;
            string UserIdForVerification = string.Empty;
            try
            {
                if (HttpUtility.HtmlEncode(txtUserId.Text.Trim()).Contains("@"))
                {
                    UserId = HttpUtility.HtmlEncode(txtUserId.Text.Trim());
                    string[] UserName = UserId.Split('@');
                    UserIdForVerification = UserName[0];
                }
                else
                {
                    UserId = HttpUtility.HtmlEncode(txtUserId.Text.Trim()) + "@dsgroup.com";
                    UserIdForVerification = HttpUtility.HtmlEncode(txtUserId.Text.Trim());
                }
                bool Isvalid = CheckUserInDomain(UserIdForVerification, txtPassword.Text.Trim());
                if (Isvalid)
                {
                    if (HttpUtility.HtmlEncode(txtUserId.Text.Trim()) == "dispatch.dshq@dsgroup.com" || HttpUtility.HtmlEncode(txtUserId.Text.Trim()) == "dispatch.dshq")
                    {
                        Session["Title"] = "Mr.";
                        Session["EmployeeName"] = "Dispatch Admin";
                        Session["EmpCode"] = "5504905";
                        Session["EmpEmail"] = "dispatch.dshq@dsgroup.com";
                        Session["DeptCode"] = "HR";
                        btnUserLogin.Enabled = false;
                        btnUserLogin.Text = "Processing...";
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "showToastAndRedirect", "showToastAndRedirect('success', 'User ID and password have been authenticated successfully.', 'Success', 'SpocRequest/OutgoingMailRegister.aspx','1000');", true);
                    }
                    else
                    {
                        GetUserDetailsForAutoLogin(UserId);
                    }
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "showErrorToast", "showToast('error', 'User Id And Password is not correct!', 'Error');", true);
                }
            }
            catch (Exception ex)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "showErrorToast", "showToast('error', 'An unexpected error occurred. Please try again later.', 'Error');", true);
            }
        }
        else
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "showErrorToast", "showToast('error', 'Oops! It looks like your session has expired or there an issue with the form submission. Please try again. If the problem persists, contact support.', 'Error');", true);
        }
    }
    #endregion
    #region CheckUserInDomain
    protected bool CheckUserInDomain(string userName, string Pwd)
    {
        try
        {
            using (PrincipalContext pc = new PrincipalContext(ContextType.Domain, "dsl.com"))
            {
                return pc.ValidateCredentials(userName, Pwd);
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region GetUserDetailsForAutoLogin
    public void GetUserDetailsForAutoLogin(string UserId)
    {
        try
        {
            DataSet ds = obj.GetUserDetailsForAutoLogin(UserId);
            if (ds.Tables[0].Rows.Count > 0)
            {
                Session["Title"] = ds.Tables[0].Rows[0]["TITLE"].ToString();
                Session["EmployeeName"] = ds.Tables[0].Rows[0]["Employee_Name"].ToString();
                Session["EmpCode"] = ds.Tables[0].Rows[0]["Emp_Code"].ToString();
                Session["EmpEmail"] = ds.Tables[0].Rows[0]["Email_ID"].ToString();
                Session["DeptCode"] = ds.Tables[0].Rows[0]["Dept_Code"].ToString();
                Session["DeptName"] = ds.Tables[0].Rows[0]["Dept_Name"].ToString();
                btnUserLogin.Enabled = false;
                btnUserLogin.Text = "Processing...";
                ScriptManager.RegisterStartupScript(this, this.GetType(), "showToastAndRedirect", "showToastAndRedirect('success', 'User ID and password have been authenticated successfully.', 'Success', 'SpocRequest/Dashboard.aspx','1000');", true);
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
}