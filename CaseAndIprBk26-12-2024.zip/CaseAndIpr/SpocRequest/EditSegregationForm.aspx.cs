﻿using DocumentFormat.OpenXml.Spreadsheet;
using Oracle.ManagedDataAccess.Client;
using Saplin.Controls;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class SpocRequest_EditSegregationForm : System.Web.UI.Page
{
    #region Variabledeclare
    SegregationForm obj = new SegregationForm();
    #endregion
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["EmpCode"] != null)
            {
                lblDeptName.Text = Session["DeptName"].ToString();
                lblDeptNameHeader.Text = Session["DeptName"].ToString();
                if (!string.IsNullOrEmpty(Request.QueryString["RecId"]))
                {
                    hndRecId.Value = CommonUtility.Decryption(HttpUtility.UrlDecode(Request.QueryString["RecId"].ToString()));
                    GetSegregationActivityList();
                    GetProcessActivity();
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "showToastAndRedirect", "showToastAndRedirect('error', 'Dear User you do not have permission to access this page.', 'User Authentication', 'ViewSegregationOfDuties.aspx','1000');", true);
                }
            }
        }
    }
    #region GetProcessActivity
    private void GetProcessActivity()
    {
        try
        {
            DataSet ds = obj.GetProcessActivity(Session["EmpCode"].ToString(), Session["DeptCode"].ToString());
            if (ds.Tables[3].Rows.Count > 0)
            {
                if (ds.Tables[3].Rows[0]["HOD_STATUS"].ToString().Equals("Pending"))
                {
                    lblMsg.Visible = true;
                    btnUpdateProcess.Visible = false;
                }
                else
                {
                    lblMsg.Visible = false;
                    btnUpdateProcess.Visible = true;
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region GetSegregationActivityList
    private void GetSegregationActivityList()
    {
        try
        {
            DataSet ds = obj.GetSegregationActivityList(Session["EmpCode"].ToString(), hndRecId.Value);
            if (ds.Tables[0].Rows.Count > 0)
            {
                GrdActivity.DataSource = ds.Tables[0];
                GrdActivity.DataBind();
                hndTeamLeaderId.Value = ds.Tables[0].Rows[0]["TEAM_LEADER"].ToString();
            }
            else
            {
                GrdActivity.DataSource = ds.Tables[0];
                GrdActivity.DataBind();
            }
            // Loop through GridView rows to set dropdown selection
            foreach (GridViewRow row in GrdActivity.Rows)
            {
                DropDownList ddlTeamLeader = row.FindControl("ddlTeamLeader") as DropDownList;
                if (ddlTeamLeader != null)
                {
                    ddlTeamLeader.SelectedValue = hndTeamLeaderId.Value;
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    //#region GetDropdownData
    //protected void GrdActivity_RowDataBound(object sender, GridViewRowEventArgs e)
    //{
    //    try
    //    {
    //        if (e.Row.RowType == DataControlRowType.DataRow)
    //        {
    //            DataSet ds = obj.GetMasterData(Session["EmpCode"].ToString(), Session["DeptCode"].ToString());

    //            // Find the HiddenField control.
    //            HiddenField hndRecId1 = (e.Row.FindControl("hndRecId1") as HiddenField);

    //            // Find the Tea,Leader DropDownList control.
    //            DropDownList ddlTeamLeader = (DropDownList)e.Row.FindControl("ddlTeamLeader");

    //            // Find the Maker DropDownCheckBoxes control.
    //            DropDownCheckBoxes ddlMaker = (DropDownCheckBoxes)e.Row.FindControl("ddlMaker");
    //            Label lblSelectedMaker = (Label)e.Row.FindControl("lblSelectedMaker");

    //            // Find the Checker DropDownCheckBoxes control.
    //            DropDownCheckBoxes ddlChecker = (DropDownCheckBoxes)e.Row.FindControl("ddlChecker");
    //            Label lblSelectedChecker = (Label)e.Row.FindControl("lblSelectedChecker");

    //            // Find the Approver DropDownCheckBoxes control.
    //            DropDownCheckBoxes ddlApprover = (DropDownCheckBoxes)e.Row.FindControl("ddlApprover");
    //            Label lblSelectedApprover = (Label)e.Row.FindControl("lblSelectedApprover");

    //            // Find the Custodian DropDownCheckBoxes control.
    //            DropDownCheckBoxes ddlCustodian = (DropDownCheckBoxes)e.Row.FindControl("ddlCustodian");
    //            Label lblSelectedCustodian = (Label)e.Row.FindControl("lblSelectedCustodian");
    //            if (ds.Tables[1].Rows.Count > 0)
    //            {
    //                ddlTeamLeader.DataSource = ds.Tables[1];
    //                ddlTeamLeader.DataTextField = "EMPLOYEE_NAME";
    //                ddlTeamLeader.DataValueField = "EMP_CODE";
    //                ddlTeamLeader.DataBind();
    //                ddlTeamLeader.Items.Insert(0, new ListItem("--Select Team Leader--", ""));
    //            }
    //            if (ds.Tables[1].Rows.Count > 0)
    //            {
    //                ddlMaker.DataSource = ds.Tables[1];
    //                ddlMaker.DataTextField = "EMPLOYEE_NAME";
    //                ddlMaker.DataValueField = "EMP_CODE";
    //                ddlMaker.DataBind();
    //            }
    //            if (ds.Tables[1].Rows.Count > 0)
    //            {
    //                ddlChecker.DataSource = ds.Tables[1];
    //                ddlChecker.DataTextField = "EMPLOYEE_NAME";
    //                ddlChecker.DataValueField = "EMP_CODE";
    //                ddlChecker.DataBind();
    //            }
    //            if (ds.Tables[1].Rows.Count > 0)
    //            {
    //                ddlApprover.DataSource = ds.Tables[1];
    //                ddlApprover.DataTextField = "EMPLOYEE_NAME";
    //                ddlApprover.DataValueField = "EMP_CODE";
    //                ddlApprover.DataBind();
    //            }
    //            if (ds.Tables[1].Rows.Count > 0)
    //            {
    //                ddlCustodian.DataSource = ds.Tables[1];
    //                ddlCustodian.DataTextField = "EMPLOYEE_NAME";
    //                ddlCustodian.DataValueField = "EMP_CODE";
    //                ddlCustodian.DataBind();
    //            }
    //            DataSet dsMaker = obj.GetSelectedUserList(Session["EmpCode"].ToString(), Session["DeptCode"].ToString(), hndRecId1.Value,"M");
    //            if (dsMaker.Tables[0].Rows.Count > 0)
    //            {
    //                List<String> checkedList = new List<string>();
    //                for (int i = 0; i < dsMaker.Tables[0].Rows.Count; i++)
    //                {
    //                    // Set the selected value to the DropDownList
    //                    ListItem item = ddlMaker.Items.FindByValue(dsMaker.Tables[0].Rows[i]["EMP_CODE"].ToString());
    //                    if (item != null)
    //                    {
    //                        item.Selected = true;
    //                        checkedList.Add(item.Text);

    //                        lblSelectedMaker.Text = String.Join(", ", checkedList);
    //                    }
    //                }
    //            }
    //            DataSet dsChecker = obj.GetSelectedUserList(Session["EmpCode"].ToString(), Session["DeptCode"].ToString(), hndRecId1.Value, "C");
    //            if (dsChecker.Tables[0].Rows.Count > 0)
    //            {
    //                List<String> checkedList = new List<string>();
    //                for (int i = 0; i < dsChecker.Tables[0].Rows.Count; i++)
    //                {
    //                    // Set the selected value to the DropDownList
    //                    ListItem item = ddlChecker.Items.FindByValue(dsChecker.Tables[0].Rows[i]["EMP_CODE"].ToString());
    //                    if (item != null)
    //                    {
    //                        item.Selected = true;
    //                        checkedList.Add(item.Text);

    //                        lblSelectedChecker.Text = String.Join(", ", checkedList);
    //                    }
    //                }
    //            }
    //            DataSet dsApprover = obj.GetSelectedUserList(Session["EmpCode"].ToString(), Session["DeptCode"].ToString(), hndRecId1.Value, "A");
    //            if (dsApprover.Tables[0].Rows.Count > 0)
    //            {
    //                List<String> checkedList = new List<string>();
    //                for (int i = 0; i < dsApprover.Tables[0].Rows.Count; i++)
    //                {
    //                    // Set the selected value to the DropDownList
    //                    ListItem item = ddlApprover.Items.FindByValue(dsApprover.Tables[0].Rows[i]["EMP_CODE"].ToString());
    //                    if (item != null)
    //                    {
    //                        item.Selected = true;
    //                        checkedList.Add(item.Text);

    //                        lblSelectedApprover.Text = String.Join(", ", checkedList);
    //                    }
    //                }
    //            }
    //            DataSet dsCustodian = obj.GetSelectedUserList(Session["EmpCode"].ToString(), Session["DeptCode"].ToString(), hndRecId1.Value, "CD");
    //            if (dsCustodian.Tables[0].Rows.Count > 0)
    //            {
    //                List<String> checkedList = new List<string>();
    //                for (int i = 0; i < dsCustodian.Tables[0].Rows.Count; i++)
    //                {
    //                    // Set the selected value to the DropDownList
    //                    ListItem item = ddlCustodian.Items.FindByValue(dsCustodian.Tables[0].Rows[i]["EMP_CODE"].ToString());
    //                    if (item != null)
    //                    {
    //                        item.Selected = true;
    //                        checkedList.Add(item.Text);

    //                        lblSelectedCustodian.Text = String.Join(", ", checkedList);
    //                    }
    //                }
    //            }
    //        }
    //    }
    //    catch (Exception ex)
    //    {
    //        throw ex;
    //    }
    //}
    //#endregion
    #region GetDropdownData
    protected void GrdActivity_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        try
        {
            if (e.Row.RowType != DataControlRowType.DataRow) return;

            var empCode = Session["EmpCode"].ToString();
            var deptCode = Session["DeptCode"].ToString();

            if (string.IsNullOrEmpty(empCode) || string.IsNullOrEmpty(deptCode)) return;

            var masterData = obj.GetMasterData(empCode, deptCode);
            if (masterData == null || masterData.Tables.Count < 2 || masterData.Tables[1].Rows.Count == 0) return;

            // Hidden field to get record ID
            var hndRecId1 = e.Row.FindControl("hndRecId1") as HiddenField;
            if (hndRecId1 == null || string.IsNullOrEmpty(hndRecId1.Value)) return;

            // Dropdown controls
            var ddlTeamLeader = e.Row.FindControl("ddlTeamLeader") as DropDownList;
            var ddlMaker = e.Row.FindControl("ddlMaker") as DropDownCheckBoxes;
            var ddlChecker = e.Row.FindControl("ddlChecker") as DropDownCheckBoxes;
            var ddlApprover = e.Row.FindControl("ddlApprover") as DropDownCheckBoxes;
            var ddlCustodian = e.Row.FindControl("ddlCustodian") as DropDownCheckBoxes;

            // Label controls
            var lblSelectedMaker = e.Row.FindControl("lblSelectedMaker") as Label;
            var lblSelectedChecker = e.Row.FindControl("lblSelectedChecker") as Label;
            var lblSelectedApprover = e.Row.FindControl("lblSelectedApprover") as Label;
            var lblSelectedCustodian = e.Row.FindControl("lblSelectedCustodian") as Label;

            // Bind dropdowns
            BindDropdown(ddlTeamLeader, masterData.Tables[1], "--Select Team Leader--");
            BindDropdown(ddlMaker, masterData.Tables[1]);
            BindDropdown(ddlChecker, masterData.Tables[1]);
            BindDropdown(ddlApprover, masterData.Tables[1]);
            BindDropdown(ddlCustodian, masterData.Tables[1]);

            // Set selected values
            SetSelectedValues(ddlMaker, lblSelectedMaker, "M", empCode, deptCode, hndRecId1.Value);
            SetSelectedValues(ddlChecker, lblSelectedChecker, "C", empCode, deptCode, hndRecId1.Value);
            SetSelectedValues(ddlApprover, lblSelectedApprover, "A", empCode, deptCode, hndRecId1.Value);
            SetSelectedValues(ddlCustodian, lblSelectedCustodian, "CD", empCode, deptCode, hndRecId1.Value);
        }
        catch (Exception ex)
        {
            // Log the exception (replace with your logging mechanism)
            LogError(ex, "Error in GrdActivity_RowDataBound");
        }
    }

    /// <summary>
    /// Binds a dropdown with a data source.
    /// </summary>
    private void BindDropdown(ListControl dropdown, DataTable data, string defaultText = null)
    {
        if (dropdown == null || data == null || data.Rows.Count == 0) return;

        dropdown.DataSource = data;
        dropdown.DataTextField = "EMPLOYEE_NAME";
        dropdown.DataValueField = "EMP_CODE";
        dropdown.DataBind();

        if (!string.IsNullOrEmpty(defaultText))
        {
            dropdown.Items.Insert(0, new ListItem(defaultText, ""));
        }
    }

    /// <summary>
    /// Sets the selected values for a DropDownCheckBoxes control and updates the label with selected items.
    /// </summary>
    private void SetSelectedValues(
        DropDownCheckBoxes dropdown,
        Label label,
        string userType,
        string empCode,
        string deptCode,
        string recordId)
    {
        if (dropdown == null || label == null) return;

        var selectedData = obj.GetSelectedUserList(empCode, deptCode, recordId, userType);
        if (selectedData == null || selectedData.Tables.Count == 0 || selectedData.Tables[0].Rows.Count == 0) return;

        var selectedNames = new List<string>();

        foreach (DataRow row in selectedData.Tables[0].Rows)
        {
            var item = dropdown.Items.FindByValue(row["EMP_CODE"].ToString());
            if (item != null)
            {
                item.Selected = true;
                selectedNames.Add(item.Text);
            }
        }

        label.Text = string.Join(", ", selectedNames);
    }

    /// <summary>
    /// Logs errors (implement your logging logic).
    /// </summary>
    private void LogError(Exception ex, string message)
    {
        // Example: log to a file, event viewer, or monitoring system
        System.Diagnostics.Debug.WriteLine(string.Format("{0}: {1}", message, ex.Message));
    }
    #endregion
    #region ShowSelectedMaker
    protected void ddlMaker_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            foreach (GridViewRow row in GrdActivity.Rows)
            {
                // Find the Maker DropDownCheckBoxes control.
                DropDownCheckBoxes ddlMaker = row.FindControl("ddlMaker") as DropDownCheckBoxes;
                Label lblSelectedMaker = row.FindControl("lblSelectedMaker") as Label;

                List<String> checkedList = new List<string>();
                foreach (ListItem item in ddlMaker.Items)
                {
                    if (item.Selected)
                    {
                        checkedList.Add(item.Text);

                        lblSelectedMaker.Text = String.Join(", ", checkedList);
                    }
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region ShowSelectedChecker
    protected void ddlChecker_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            foreach (GridViewRow row in GrdActivity.Rows)
            {
                // Find the Checker DropDownCheckBoxes control.
                DropDownCheckBoxes ddlChecker = row.FindControl("ddlChecker") as DropDownCheckBoxes;
                Label lblSelectedChecker = row.FindControl("lblSelectedChecker") as Label;

                List<String> checkedList = new List<string>();
                foreach (ListItem item in ddlChecker.Items)
                {
                    if (item.Selected)
                    {
                        checkedList.Add(item.Text);

                        lblSelectedChecker.Text = String.Join(",", checkedList);
                    }
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region ShowSelectedApprover
    protected void ddlApprover_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            foreach (GridViewRow row in GrdActivity.Rows)
            {
                // Find the Approver DropDownCheckBoxes control.
                DropDownCheckBoxes ddlApprover = row.FindControl("ddlApprover") as DropDownCheckBoxes;
                Label lblSelectedApprover = row.FindControl("lblSelectedApprover") as Label;

                List<String> checkedList = new List<string>();
                foreach (ListItem item in ddlApprover.Items)
                {
                    if (item.Selected)
                    {
                        checkedList.Add(item.Text);

                        lblSelectedApprover.Text = String.Join(",", checkedList);
                    }
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region ShowSelectedCustodian
    protected void ddlCustodian_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            foreach (GridViewRow row in GrdActivity.Rows)
            {
                // Find the Custodian DropDownCheckBoxes control.
                DropDownCheckBoxes ddlCustodian = row.FindControl("ddlCustodian") as DropDownCheckBoxes;
                Label lblSelectedCustodian = row.FindControl("lblSelectedCustodian") as Label;

                List<String> checkedList = new List<string>();
                foreach (ListItem item in ddlCustodian.Items)
                {
                    if (item.Selected)
                    {
                        checkedList.Add(item.Text);

                        lblSelectedCustodian.Text = String.Join(",", checkedList);
                    }
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region UpdateProcessActivity
    protected void btnUpdateProcess_Click(object sender, EventArgs e)
    {
        try
        {
            var connectionString = ConfigurationManager.ConnectionStrings["ELogBook"].ConnectionString;
            using (var conn = new OracleConnection(connectionString))
            {
                conn.Open();
                using (var transaction = conn.BeginTransaction())
                {
                    foreach (GridViewRow row in GrdActivity.Rows)
                    {
                        // Retrieve controls.
                        HiddenField hndRecId1 = row.FindControl("hndRecId1") as HiddenField;
                        HiddenField hndProcessId = row.FindControl("hndProcessId") as HiddenField;
                        HiddenField hndSubProcessId = row.FindControl("hndSubProcessId") as HiddenField;
                        TextBox txtActivity = row.FindControl("txtActivity") as TextBox;
                        DropDownList ddlTeamLeader = row.FindControl("ddlTeamLeader") as DropDownList;
                        DropDownCheckBoxes ddlMaker = row.FindControl("ddlMaker") as DropDownCheckBoxes;
                        DropDownCheckBoxes ddlChecker = row.FindControl("ddlChecker") as DropDownCheckBoxes;
                        DropDownCheckBoxes ddlApprover = row.FindControl("ddlApprover") as DropDownCheckBoxes;
                        DropDownCheckBoxes ddlCustodian = row.FindControl("ddlCustodian") as DropDownCheckBoxes;

                        // Validate controls.
                        if (hndRecId1 == null || txtActivity == null || ddlTeamLeader == null)
                        {
                            DisplayError("Missing required controls. Please try again.");
                            return;
                        }

                        // Update the process activity.
                        int updateResult = obj.UpdateProcessActivity(
                            Session["EmpCode"].ToString(),
                            hndRecId1.Value,
                            HttpUtility.HtmlEncode(txtActivity.Text.Trim()),
                            ddlTeamLeader.SelectedValue
                        );

                        if (updateResult > 0)
                        {
                            // Delete existing roles.
                            int deleteResult = obj.DeleteProcessId(Session["EmpCode"].ToString(), hndRecId1.Value);
                            if (deleteResult == 0)
                            {
                                SaveUserRoles(hndRecId1.Value, ddlMaker, "M", conn, transaction);
                                SaveUserRoles(hndRecId1.Value, ddlChecker, "C", conn, transaction);
                                SaveUserRoles(hndRecId1.Value, ddlApprover, "A", conn, transaction);
                                SaveUserRoles(hndRecId1.Value, ddlCustodian, "CD", conn, transaction);
                                transaction.Commit();
                                DisplaySuccess("Process Activity is successfully saved.", "ViewSegregationOfDuties.aspx");
                            }
                            else
                            {
                                transaction.Rollback();
                                DisplayError("Failed to delete existing roles. Please try again later.");
                            }
                        }
                        else
                        {
                            transaction.Rollback();
                            DisplayError("Failed to update Process Activity. Please try again later.");
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            // Log the exception (not implemented here).
            DisplayError("An unexpected error occurred. Please contact support.");
        }
    }

    // Helper methods
    private void SaveUserRoles(string recId, DropDownCheckBoxes dropDown, string roleType, OracleConnection conn, OracleTransaction transaction)
    {
        if (dropDown == null) return;

        foreach (ListItem item in dropDown.Items)
        {
            if (item.Selected)
            {
                obj.SaveUserList(Session["EmpCode"].ToString(), recId, item.Value, roleType, conn, transaction);
            }
        }
    }

    private void DisplaySuccess(string message, string redirectUrl)
    {
        ScriptManager.RegisterStartupScript(
            this,
            this.GetType(),
            "showToastAndRedirect",
            string.Format("showToastAndRedirect('success', '{0}', 'Success', '{1}', '1000');", message, redirectUrl),
            true
        );
    }

    private void DisplayError(string message)
    {
        ScriptManager.RegisterStartupScript(
            this,
            this.GetType(),
            "showErrorToast",
            string.Format("showToast('error', '{0}', 'Error');", message),
            true
        );
    }
    #endregion
}