﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class SpocRequest_AdminPanel : System.Web.UI.Page
{
    #region VariableDeclare
    PolicyMaker obj = new PolicyMaker();
    #endregion
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!IsPostBack)
        {
            GetAllDocViewRequest();
        }
    }
    #region GetAllDocViewRequest
    public void GetAllDocViewRequest()
    {
        try
        {
            if (Session["EmpCode"] != null)
            {
                string empCode = Session["EmpCode"].ToString();
                DataSet ds = obj.GetAllDocViewRequest(empCode);

                if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    GrdListOfDocViewRequest.DataSource = ds.Tables[0];
                    GrdListOfDocViewRequest.DataBind();
                }
                else
                {
                    GrdListOfDocViewRequest.DataSource = null;
                    GrdListOfDocViewRequest.DataBind();
                }
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "Javascript", "javascript:SweetDynamicWrongRedirect('Oops...','Dear user your session has been expired.Please try again later.','Dashboard.aspx'); ", true);
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
}