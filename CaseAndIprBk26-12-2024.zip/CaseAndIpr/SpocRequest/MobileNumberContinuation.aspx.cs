﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class SpocRequest_MobileNumberContinuation : System.Web.UI.Page
{
    #region DeclareVariable
    ExternalMailRegister obj = new ExternalMailRegister();
    MailUtility objm = new MailUtility();
    string Url = "https://webportal.dsgroup.com/ExternalMailRegister/";
    #endregion
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!IsPostBack)
        {
            if (Session["EmpCode"] != null)
            {
                txtDate.Text = DateTime.Now.ToString("dd-MM-yyyy");
                GetUserDetails();
            }
        }
    }
    #region GetUserDetails
    public void GetUserDetails()
    {
        try
        {
            DataSet ds = obj.GetUserDetails(Session["EmpCode"].ToString());
            if (ds.Tables[1].Rows.Count > 0)
            {
                if (ds.Tables[0].Rows.Count > 0)
                {
                    txtNameOfRequestor.Text = ds.Tables[0].Rows[0]["Employee_Name"].ToString();
                    txtEmployeeNo.Text = ds.Tables[0].Rows[0]["Emp_Code"].ToString();
                    txtDepartment.Text = ds.Tables[0].Rows[0]["Department"].ToString();
                    txtPhExtNo.Text = ds.Tables[0].Rows[0]["ExtPhone"].ToString() == "" ? "-" : ds.Tables[0].Rows[0]["ExtPhone"].ToString();
                    txtEmployeeloginId.Text = ds.Tables[0].Rows[0]["Email_Id"].ToString();
                    lblDesignation.Text = ds.Tables[0].Rows[0]["Desig_NM"].ToString();
                    lblCadreBand.Text = ds.Tables[0].Rows[0]["CD_CODE"].ToString();
                    lblLocation.Text = ds.Tables[0].Rows[0]["LOC_DESC"].ToString();
                    #region GetDsDocumnetNo
                    DataSet DsDocumnetNo = obj.GetMobileDocumnetNo(Session["EmpCode"].ToString());

                    if (DsDocumnetNo.Tables[0].Rows.Count > 0)
                    {
                        lblDocumentNo.Text = DsDocumnetNo.Tables[0].Rows[0]["EMP_CODE"].ToString() + "/" + DsDocumnetNo.Tables[0].Rows[0]["BUSS_CODE"].ToString() + "/" +
                            DsDocumnetNo.Tables[0].Rows[0]["UNIT_CODE"].ToString() + "/" + DsDocumnetNo.Tables[0].Rows[0]["FYEAR"].ToString() + "/" +
                            DsDocumnetNo.Tables[0].Rows[0]["MAX_NO"].ToString();
                    }
                    #endregion
                    lblHodName.Text = ds.Tables[1].Rows[0]["Employee_Name"].ToString();
                    hndHodeCode.Value = ds.Tables[1].Rows[0]["Emp_Code"].ToString();
                    hndHodeEmail.Value = ds.Tables[1].Rows[0]["Hod_Email"].ToString();
                }
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "alert('Dear User, Your Reviewer is not defines, please contact to your Payroll HR.');window.location ='DocViewReqDashBoard.aspx';", true);
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region SaveDetails
    protected void btnSaveDetails_Click(object sender, EventArgs e)
    {
        int success = 0;
        string DocumentNo = string.Empty;
        try
        {
            DataSet DsDocumnetNo = obj.GetMobileDocumnetNo(Session["EmpCode"].ToString());

            if (DsDocumnetNo.Tables[0].Rows.Count > 0)
            {
                DocumentNo = DsDocumnetNo.Tables[0].Rows[0]["EMP_CODE"].ToString() + "/" + DsDocumnetNo.Tables[0].Rows[0]["BUSS_CODE"].ToString() + "/" +
                    DsDocumnetNo.Tables[0].Rows[0]["UNIT_CODE"].ToString() + "/" + DsDocumnetNo.Tables[0].Rows[0]["FYEAR"].ToString() + "/" +
                    DsDocumnetNo.Tables[0].Rows[0]["MAX_NO"].ToString();

                success = obj.SaveMobileNoContinuation(Session["EmpCode"].ToString(), DocumentNo, hndHodeCode.Value, "5501896", txtMobileNo.Text.Trim());
                if (success > 0)
                {
                    // Prepare email details
                    string subject = string.Format("Personal Mobile Number Continuation Request Document No.: {0}", lblDocumentNo.Text);
                    string body = string.Format("You have received a new Mobile Number Continuation Request. Kindly review it and take appropriate action.");
                    string baseUrl = Url + "SpocRequest/ListOfMobileNumberContinuation.aspx";
                    //string userEmailUrl = string.Format("{0}?ReqId={1}&emp_code={2}",
                    //    baseUrl,
                    //    CommonUtility.Encryption(hndReqId.Value),
                    //    CommonUtility.Encryption(HttpUtility.UrlEncode(hndHodeEmail.Value)));
                    // Send user email
                    SendEmail(Session["EmpEmail"].ToString(), Session["EmployeeName"].ToString(),
                              lblHodName.Text,
                              "prakash.singh@dsgroup.com",
                              subject, body, "", baseUrl);
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "showToastAndRedirect", "showToastAndRedirect('success', 'Mobile Number Continuation detail is successfully submitted.', 'Success', 'ListOfMobileNumberContinuation.aspx','1000');", true);
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "showErrorToast", "showToast('error', 'Mobile Number Continuation detail not submitted. Please try again later.', 'Error');", true);
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    /// <summary>
    /// Sends an email using the provided parameters.
    /// </summary>
    private void SendEmail(string senderEmail, string senderName, string recipientName, string recipientEmail, string subject, string body, string additionalComments, string url)
    {
        if (!string.IsNullOrWhiteSpace(senderEmail) && !string.IsNullOrWhiteSpace(recipientEmail))
        {
            objm.SendMail(senderEmail, senderName, recipientEmail, recipientName,  subject, body, HttpUtility.HtmlEncode(additionalComments), url);
        }
    }
    #region CheckExistingRequest
    protected void txtMobileNo_TextChanged(object sender, EventArgs e)
    {
        try
        {
            DataSet ds = obj.GetUserDetails(txtMobileNo.Text.Trim());
            if (ds.Tables[2].Rows.Count > 0)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "showErrorToast", "showToast('error', 'The continuation request for the mobile number " + txtMobileNo.Text.Trim() + " has already been submitted.', 'Error');", true);
                txtMobileNo.Text = "";
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
}