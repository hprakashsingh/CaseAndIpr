﻿using Saplin.Controls;
using System;
using System.Collections.Generic;
using System.Data;
using System.IdentityModel.Protocols.WSTrust;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;

public partial class PolicyRequest_DocViewRightsRequest : System.Web.UI.Page
{
    #region VariableDeclare
    PolicyMaker obj = new PolicyMaker();
    MailUtility objm = new MailUtility();
    #endregion
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!IsPostBack)
        {
            if (Session["EmpCode"] != null)
            {
                GetDocViewRightsRequest();
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "Javascript", "javascript:SweetDynamicWrongRedirect('Oops...','Dear user your session has been expired.Please try again later.','DocViewReqDashBoard.aspx'); ", true);
            }
        }
    }
    #region GetDocViewRightsRequest
    public void GetDocViewRightsRequest()
    {
        try
        {
            DataSet ds = obj.GetDocViewRightsApproverList(Session["EmpCode"].ToString());
            if (ds.Tables[0].Rows.Count > 0)
            {
                lblLevel2.Text = ds.Tables[0].Rows[0]["Employee_Name"].ToString();
                lblLevel3.Text = ds.Tables[0].Rows[1]["Employee_Name"].ToString();
                lblLevel4.Text = ds.Tables[0].Rows[2]["Employee_Name"].ToString();
                lblLevel5.Text = ds.Tables[0].Rows[3]["Employee_Name"].ToString();

                lblRequesterName.Text = Session["EmployeeName"].ToString();
                lblRequesterDate.Text = DateTime.Now.ToString("dd-MM-yyyy");
                lblRequesterSign.Text = Session["EmployeeName"].ToString();

                DataTable dTab = null;
                DataRow dr;

                dTab = GetTableWithNoData();
                dr = dTab.NewRow();
                dTab.Rows.Add(dr);
                dTab.AcceptChanges();
                ViewState["gridtable"] = null;
                grdDocViewRightsRequest.DataSource = dTab;
                grdDocViewRightsRequest.DataBind();
                if (ViewState["gridtable"] != null)
                {
                    ChangeGridViewControl();
                }
                HideRemoveButton();
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "alert('Dear User, You do not have permission to acces this page.');window.location ='DocViewReqDashBoard.aspx';", true);
            }
            if (ds.Tables[1].Rows.Count > 0)
            {
                ddlHodApprovalList.DataSource = ds.Tables[1];
                ddlHodApprovalList.DataTextField = "Employee_Name";
                ddlHodApprovalList.DataValueField = "Emp_Code";
                ddlHodApprovalList.DataBind();
                ddlHodApprovalList.Items.Insert(0, new ListItem("--Select HOD--", ""));
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region BindHodSign
    protected void ddlHodApprovalList_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            lblHodApprovalSign.Text = ddlHodApprovalList.SelectedItem.Text;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region AddNewRow
    protected void btnAddRow_Click(object sender, EventArgs e)
    {
        LinkButton btn = (LinkButton)sender;
        GridViewRow gvr = (GridViewRow)btn.NamingContainer;
        int i = gvr.RowIndex;
        AddNewRow(i);
    }
    #endregion
    #region AddNewRow
    public void AddNewRow(int index)
    {
        DataTable dt = GetTableWithNoData();
        DataRow dr = null;
        for (int i = 0; i < grdDocViewRightsRequest.Rows.Count; i++)
        {
            dr = dt.NewRow();
            dr["REQLIST_ID"] = (grdDocViewRightsRequest.Rows[i].Cells[0].FindControl("hdnReqId") as HiddenField).Value;
            dr["REQUESTER_NAME"] = (grdDocViewRightsRequest.Rows[i].Cells[0].FindControl("txtRequesterName") as TextBox).Text;
            dr["REQUESTOR_ID"] = (grdDocViewRightsRequest.Rows[i].Cells[1].FindControl("txtRequestorID") as TextBox).Text;
            dr["ENTITY"] = (grdDocViewRightsRequest.Rows[i].Cells[2].FindControl("txtEntity") as TextBox).Text;
            dr["SBU_CODE"] = (grdDocViewRightsRequest.Rows[i].Cells[3].FindControl("txtSBUCode") as TextBox).Text;
            dr["DEPARTMENT"] = (grdDocViewRightsRequest.Rows[i].Cells[4].FindControl("txtDepartment") as TextBox).Text;

            dr["DOCUMENT_TYPE"] = (grdDocViewRightsRequest.Rows[i].Cells[5].FindControl("ddlDocumentType") as DropDownCheckBoxes).SelectedValue;
            List<String> checkedList = new List<string>();
            foreach (ListItem item in (grdDocViewRightsRequest.Rows[i].Cells[5].FindControl("ddlDocumentType") as DropDownCheckBoxes).Items)
            {
                if (item.Selected)
                {
                    checkedList.Add(item.Text);

                    // Save the selected value to ViewState
                    ViewState["ddlDocumentType_" + i] = String.Join(",", checkedList);
                }
            }

            dr["VALIDITY_PERIOD"] = (grdDocViewRightsRequest.Rows[i].Cells[6].FindControl("txtValidityPeriod") as TextBox).Text;
            dr["VALIDITY_To"] = (grdDocViewRightsRequest.Rows[i].Cells[7].FindControl("txtValidityTo") as TextBox).Text;
            dt.Rows.Add(dr);
        }
        ViewState["gridtable"] = dt;
        dr = dt.NewRow();
        dt.Rows.Add(dr);
        dt.AcceptChanges();
        grdDocViewRightsRequest.DataSource = dt;
        grdDocViewRightsRequest.DataBind();
        ChangeGridViewControl("A");
    }
    #endregion
    #region RemoveRow
    protected void btnRemoveRow_Click(object sender, EventArgs e)
    {
        LinkButton btn = (LinkButton)sender;
        GridViewRow gvr = (GridViewRow)btn.NamingContainer;
        int i = gvr.RowIndex;
        RemoveRow(i);
    }
    #endregion
    #region RemoveRow
    public void RemoveRow(int index)
    {
        DataTable dt = GetTableWithNoData();
        DataRow dr = null;
        for (int i = 0; i < grdDocViewRightsRequest.Rows.Count; i++)
        {
            if (i == index)
            {
                // obj.DeleteDocViewRightsRequest((grdDocViewRightsRequest.Rows[index].Cells[0].FindControl("hdnReqId") as HiddenField).Value, "DetailsOfTravel");
            }
            if (i != index)
            {
                dr = dt.NewRow();
                dr["REQLIST_ID"] = (grdDocViewRightsRequest.Rows[i].Cells[0].FindControl("hdnReqId") as HiddenField).Value;
                dr["REQUESTER_NAME"] = (grdDocViewRightsRequest.Rows[i].Cells[0].FindControl("txtRequesterName") as TextBox).Text;
                dr["REQUESTOR_ID"] = (grdDocViewRightsRequest.Rows[i].Cells[1].FindControl("txtRequestorID") as TextBox).Text;
                dr["ENTITY"] = (grdDocViewRightsRequest.Rows[i].Cells[2].FindControl("txtEntity") as TextBox).Text;
                dr["SBU_CODE"] = (grdDocViewRightsRequest.Rows[i].Cells[3].FindControl("txtSBUCode") as TextBox).Text;
                dr["DEPARTMENT"] = (grdDocViewRightsRequest.Rows[i].Cells[4].FindControl("txtDepartment") as TextBox).Text;
                dr["DOCUMENT_TYPE"] = (grdDocViewRightsRequest.Rows[i].Cells[5].FindControl("ddlDocumentType") as DropDownCheckBoxes).SelectedValue;
                dr["VALIDITY_PERIOD"] = (grdDocViewRightsRequest.Rows[i].Cells[6].FindControl("txtValidityPeriod") as TextBox).Text;
                dr["VALIDITY_To"] = (grdDocViewRightsRequest.Rows[i].Cells[7].FindControl("txtValidityTo") as TextBox).Text;
                dt.Rows.Add(dr);
            }
        }
        ViewState["gridtable"] = dt;
        grdDocViewRightsRequest.DataSource = dt;
        grdDocViewRightsRequest.DataBind();
        ChangeGridViewControl();
    }
    #endregion
    #region HideRemoveButton
    public void HideRemoveButton()
    {
        for (int i = 0; i < grdDocViewRightsRequest.Rows.Count; i++)
        {
            LinkButton btn_add = (LinkButton)grdDocViewRightsRequest.Rows[i].Cells[8].FindControl("btnExAdd");
            LinkButton btn_remove = (LinkButton)grdDocViewRightsRequest.Rows[i].Cells[8].FindControl("btnExRemove");

            if (grdDocViewRightsRequest.Rows.Count == 1)
            {
                btn_add.Visible = true;
                btn_remove.Visible = false;
            }
            if (i < grdDocViewRightsRequest.Rows.Count - 1)
            {
                btn_add.Visible = false;
            }
        }
    }
    #endregion
    #region ChangeGridViewControl
    public void ChangeGridViewControl(string flag = "")
    {
        DataTable dt = new DataTable();
        try
        {
            if (ViewState["gridtable"] != null)
            {
                dt = (ViewState["gridtable"] as DataTable);
                int rowcount = dt.Rows.Count;
                if (flag == "A")
                    rowcount--;
                for (int i = 0; i < rowcount; i++)
                {
                    if (ViewState["ddlDocumentType_" + i] != null)
                    {
                        // Restore the selected value from ViewState
                        string savedValue = ViewState["ddlDocumentType_" + i] as string;

                        // Split saveValue data
                        string[] values = savedValue.Split(',');

                        // Assuming chkDeviceInformation is a CheckBoxList
                        foreach (string value in values)
                        {
                            // Set the selected value to the DropDownList
                            ListItem item = (grdDocViewRightsRequest.Rows[i].Cells[5].FindControl("ddlDocumentType") as DropDownCheckBoxes).Items.FindByValue(value.Trim());
                            if (item != null)
                            {
                                item.Selected = true;
                            }
                        }
                    }
                }
                for (int i = 0; i < grdDocViewRightsRequest.Rows.Count; i++)
                {
                    LinkButton btn_add = (LinkButton)grdDocViewRightsRequest.Rows[i].Cells[8].FindControl("btnExAdd");
                    LinkButton btn_remove = (LinkButton)grdDocViewRightsRequest.Rows[i].Cells[8].FindControl("btnExRemove");

                    if (grdDocViewRightsRequest.Rows.Count == 1)
                    {
                        btn_add.Visible = true;
                        btn_remove.Visible = false;
                    }
                    if (i < grdDocViewRightsRequest.Rows.Count - 1)
                    {
                        btn_add.Visible = false;
                    }
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region gettablewithnodata
    public DataTable GetTableWithNoData() // returns only structure if the select columns
    {
        try
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("REQLIST_ID", typeof(string));
            dt.Columns.Add("REQUESTER_NAME", typeof(string));
            dt.Columns.Add("REQUESTOR_ID", typeof(string));
            dt.Columns.Add("ENTITY", typeof(string));
            dt.Columns.Add("SBU_CODE", typeof(string));
            dt.Columns.Add("DEPARTMENT", typeof(string));
            dt.Columns.Add("DOCUMENT_TYPE", typeof(string));
            dt.Columns.Add("VALIDITY_PERIOD", typeof(string));
            dt.Columns.Add("VALIDITY_To", typeof(string));
            return dt;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region ResetFormDetails
    protected void btnResetFormDetails_Click(object sender, EventArgs e)
    {
        try
        {
            Response.Redirect("DocViewRightsRequest.aspx");
        }
        catch(Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region SubmitRequest
    protected void btnSubmitRequest_Click(object sender, EventArgs e)
    {
        string Subject = string.Empty;
        string Body = string.Empty;
        string Url = string.Empty;
        int success = 0;
        int ReqList = 0;
        int ApproverList = 0;
        string documentNo = string.Empty;
        try
        {
            Page.Validate("DocViewRightsRequest");
            if (Page.IsValid)
            {
                DataSet DsDocumnetNo = obj.GeDocViewRightsDocumnetNo(Session["EmpCode"].ToString());
                DataSet DsGetMailId = obj.HodMailId(ddlHodApprovalList.SelectedValue);

                if (DsDocumnetNo.Tables[0].Rows.Count > 0)
                {
                    documentNo = DsDocumnetNo.Tables[0].Rows[0]["ENTITY_CODE"].ToString() + "/" + DsDocumnetNo.Tables[0].Rows[0]["BUSS_CODE"].ToString() + "/" +
                        DsDocumnetNo.Tables[0].Rows[0]["UNIT_CODE"].ToString() + "/" + DsDocumnetNo.Tables[0].Rows[0]["FYEAR"].ToString() + "/" +
                        DsDocumnetNo.Tables[0].Rows[0]["MAX_NO"].ToString();
                }
                Subject = "Document View right Request Document No.:- " + documentNo;
                Body = "You have received a new Document View right request. Kindly review it and take appropriate action.";
                Url = "#";
                success = obj.SaveDocViewRightsRequest(Session["EmpCode"].ToString(),documentNo);
                if (success > 0)
                {
                    hndReqId.Value = success.ToString();
                    ReqList = SaveDocViewRightsUserList(hndReqId.Value);
                    if(ReqList > 0)
                    {
                        ApproverList = ForwaredDocViewRightsRequestToApprover(hndReqId.Value);
                        if(ApproverList > 0)
                        {

                            Url = "https://intranet.dsgroup.com/OnlineITForms/SpocRequest/ViewDocViewRequest.aspx?ReqId=" + CommonUtility.Encryption(hndReqId.Value) + "&emp_code=" + CommonUtility.Encryption(HttpUtility.UrlEncode(ddlHodApprovalList.SelectedValue));
                            objm.SendMailForPolicyDoc(Session["EmpEmail"].ToString(), Session["EmployeeName"].ToString(), DsGetMailId.Tables[0].Rows[0]["EMAIL_ID"].ToString(), DsGetMailId.Tables[0].Rows[0]["EMPLOYEE_NAME"].ToString(), Subject, Body, "", Url);
                        }
                        ScriptManager.RegisterStartupScript(this, GetType(), "Javascript",
                        "javascript:SweetDynamicSuccessRedirect('Document View Request', 'Document View Request is successfully submitted.', 'DocViewReqDashBoard.aspx');", true);
                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(this, GetType(), "Javascript", "javascript:SweetWrong('Due to technical or internet connection Requester List are not submitted. Please try again later.'); ", true);
                    }
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "Javascript", "javascript:SweetWrong('Due to technical or internet connection details are not submitted. Please try again later.'); ", true);
                }
            }
            else
            {
                grdDocViewRightsRequest.Focus();
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Please fill all required field')", true);
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region SaveDocViewRightsUserList
    public int SaveDocViewRightsUserList(string Req_Id)
    {
        int success = 0;
        string DocumentType = string.Empty;
        try
        {
            for (int i = 0; i < grdDocViewRightsRequest.Rows.Count; i++)
            {
                List<String> checkedList = new List<string>();
                foreach (ListItem item in (grdDocViewRightsRequest.Rows[i].Cells[5].FindControl("ddlDocumentType") as DropDownCheckBoxes).Items)
                {
                    if (item.Selected)
                    {
                        checkedList.Add(item.Text);

                        // Save the selected value to DocumentType
                        DocumentType = String.Join(",", checkedList);
                    }
                }
                string ReqId = (grdDocViewRightsRequest.Rows[i].Cells[0].FindControl("hdnReqId") as HiddenField).Value;
                string RequesterName = (grdDocViewRightsRequest.Rows[i].Cells[0].FindControl("txtRequesterName") as TextBox).Text;
                string RequestorID = (grdDocViewRightsRequest.Rows[i].Cells[1].FindControl("txtRequestorID") as TextBox).Text;
                string Entity = (grdDocViewRightsRequest.Rows[i].Cells[2].FindControl("txtEntity") as TextBox).Text;
                string SBUCode = (grdDocViewRightsRequest.Rows[i].Cells[3].FindControl("txtSBUCode") as TextBox).Text;
                string Department = (grdDocViewRightsRequest.Rows[i].Cells[4].FindControl("txtDepartment") as TextBox).Text;
                string ValidityPeriod = (grdDocViewRightsRequest.Rows[i].Cells[6].FindControl("txtValidityPeriod") as TextBox).Text;
                string ValidityTo = (grdDocViewRightsRequest.Rows[i].Cells[7].FindControl("txtValidityTo") as TextBox).Text;
                success = obj.SaveDocViewRightsUserList(Req_Id, RequesterName, RequestorID, Entity, SBUCode, Department, DocumentType, ValidityPeriod, ValidityTo);
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return success;
    }
    #endregion
    #region ForwaredDocViewRightsRequestToApprover
    public int ForwaredDocViewRightsRequestToApprover(string Req_Id)
    {
        int success = 0;
        try
        {
            DataSet ds = obj.GetDocViewRightsApproverList(Session["EmpCode"].ToString());
            if (ds.Tables[0].Rows.Count > 0)
            {
                success = obj.ForwaredDocViewRightsRequestToApprover(Req_Id, ddlHodApprovalList.SelectedValue,"1", "3");
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    success = obj.ForwaredDocViewRightsRequestToApprover(Req_Id, ds.Tables[0].Rows[i]["Emp_Code"].ToString(),
                    ds.Tables[0].Rows[i]["Level_Id"].ToString(), "1");
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return success;
    }
    #endregion
    #region ShowSelectedDocumentType
    protected void ddlDocumentType_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            foreach (GridViewRow row in grdDocViewRightsRequest.Rows)
            {
                DropDownCheckBoxes ddlDocumentType = (DropDownCheckBoxes)row.FindControl("ddlDocumentType");
                Label lblSelectedDocumentType = (Label)row.FindControl("lblSelectedDocumentType");
                List<String> checkedList = new List<string>();
                foreach (ListItem item in ddlDocumentType.Items)
                {
                    if (item.Selected)
                    {
                        checkedList.Add(item.Text);

                        lblSelectedDocumentType.Text = String.Join(", ", checkedList);
                    }
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
}