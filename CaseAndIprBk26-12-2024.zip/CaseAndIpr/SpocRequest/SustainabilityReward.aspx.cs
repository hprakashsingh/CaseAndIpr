﻿using Microsoft.Office.Interop.Excel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class SpocRequest_SustainabilityReward : System.Web.UI.Page
{
    #region DeclareVariable
    Sustainability obj = new Sustainability();
    MailUtility objm = new MailUtility();
    string Url = "https://webportal.dsgroup.com/ExternalMailRegister/";
    #endregion
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["EmpCode"] != null)
            {
                txtBeforeSustainabilityIdea.Attributes.Add("maxlength", txtBeforeSustainabilityIdea.MaxLength.ToString());
                txtAfterSustainabilityIdea.Attributes.Add("maxlength", txtAfterSustainabilityIdea.MaxLength.ToString());
                txtApplicableYesNoRemarks.Attributes.Add("maxlength", txtApplicableYesNoRemarks.MaxLength.ToString());
                txtQuantitativeImpactRemarks.Attributes.Add("maxlength", txtQuantitativeImpactRemarks.MaxLength.ToString());
                txtConsumptionGeneration.Attributes.Add("maxlength", txtConsumptionGeneration.MaxLength.ToString());
                txtGenerationImpactAtSite.Attributes.Add("maxlength", txtGenerationImpactAtSite.MaxLength.ToString());
                txtExistingProcessScnario.Attributes.Add("maxlength", txtExistingProcessScnario.MaxLength.ToString());
                txtQuantitativeValueOfConsumptionExisting.Attributes.Add("maxlength", txtQuantitativeValueOfConsumptionExisting.MaxLength.ToString());
                txtImprovementAction.Attributes.Add("maxlength", txtImprovementAction.MaxLength.ToString());
                txtQuantitativeValueOfConsumptionAfter.Attributes.Add("maxlength", txtQuantitativeValueOfConsumptionAfter.MaxLength.ToString());
                txtCommittee.Attributes.Add("maxlength", txtCommittee.MaxLength.ToString());
                lblDate.Text = DateTime.Now.ToString("dd-MM-yyyy");
                GetUserDetails();
            }
        }
    }
    #region GetUserDetails
    public void GetUserDetails()
    {
        try
        {
            DataSet ds = obj.GetUserDetails(Session["EmpCode"].ToString());
            if (ds.Tables[0].Rows.Count > 0)
            {
                lblEmployeeName.Text = ds.Tables[0].Rows[0]["Employee_Name"].ToString();
                lblCadreBand.Text = ds.Tables[0].Rows[0]["CD_CODE"].ToString();
                lblDepartment.Text = ds.Tables[0].Rows[0]["Department"].ToString();
                lblUnitCode.Text = ds.Tables[0].Rows[0]["UNIT_CODE"].ToString();
                lblUnitLocation.Text = ds.Tables[0].Rows[0]["LOC_DESC"].ToString();
                lblBusiness.Text = ds.Tables[0].Rows[0]["BUSS_CODE"].ToString();
                lblFunctional.Text = ds.Tables[0].Rows[0]["Functional_Reporting"].ToString();
                lblOperational.Text = ds.Tables[0].Rows[0]["Operational_Reporting"].ToString();
                lblEmployeeSignature.Text = ds.Tables[0].Rows[0]["EMPLOYEE_NAME"].ToString();
                lblHodSignature.Text = ds.Tables[0].Rows[0]["HOD_NAME"].ToString();
                lblUnitHeadSignature.Text = "-";
                lblManufacturingHeadSignature.Text = "-";
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "alert('Dear User, Your Reviewer is not defines, please contact to your Payroll HR.');window.location ='DocViewReqDashBoard.aspx';", true);
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
}