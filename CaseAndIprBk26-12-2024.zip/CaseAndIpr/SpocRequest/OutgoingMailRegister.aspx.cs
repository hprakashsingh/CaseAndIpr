﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection.Emit;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class SpocRequest_OutgoingMailRegister : System.Web.UI.Page
{
    #region DeclareVariable
    ExternalMailRegister obj = new ExternalMailRegister();
    #endregion
    protected void Page_Load(object sender, EventArgs e)
    {
        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "SelectSearchDropDown();", true);
        if (!IsPostBack)
        {
            if (Session["EmpCode"] != null)
            {
                txtRemark.Attributes.Add("maxlength", txtRemark.MaxLength.ToString());
                txtTimeIn.Text = "16:00";
                txtTimeOut.Text = "18:00";
                GetSenderName();
                GetDepartment();
            }
        }
    }
    #region GetSenderName
    private void GetSenderName()
    {
        try
        {
            DataSet dsDepartment = obj.GetSenderName(Session["EmpCode"].ToString());
            if (dsDepartment.Tables[0].Rows.Count > 0)
            {
                ddlEmployeeName.DataSource = dsDepartment.Tables[0];
                ddlEmployeeName.DataTextField = "EMPLOYEE_NAME";
                ddlEmployeeName.DataValueField = "EMP_CODE";
                ddlEmployeeName.DataBind();
                ddlEmployeeName.Items.Insert(0, new ListItem("--Select Employee--", ""));
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region GetDepartment
    private void GetDepartment()
    {
        try
        {
            DataSet dsDepartment = obj.GetDepartment(Session["EmpCode"].ToString());
            if (dsDepartment.Tables[0].Rows.Count > 0)
            {
                ddlDepartment.DataSource = dsDepartment.Tables[0];
                ddlDepartment.DataTextField = "DESCRIPTION";
                ddlDepartment.DataValueField = "DESCRIPTION";
                ddlDepartment.DataBind();
                ddlDepartment.Items.Insert(0, new ListItem("--Select Department--", ""));
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region GetDepartmentName
    protected void ddlEmployeeName_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            DataSet dsDepartment = obj.GetDepartment(Session["EmpCode"].ToString(), ddlEmployeeName.SelectedValue);
            if (dsDepartment.Tables[1].Rows.Count > 0)
            {
                ddlDepartment.SelectedValue = dsDepartment.Tables[1].Rows[0]["DESCRIPTION"].ToString();
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region SaveDetails
    protected void btnSaveDetails_Click(object sender, EventArgs e)
    {
        int success = 0;
        string DocumentNo = string.Empty;
        try
        {
            if (Session["EmpCode"] == null)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "alert('Session Expired.');window.location ='DocViewReqDashBoard.aspx';", true);
                return;
            }
            // Get Document No for IPR
            DataSet IprDocNo = obj.GetDocumentNo(Session["EmpCode"].ToString());

            if (IprDocNo.Tables[0].Rows.Count > 0)
            {
                DocumentNo = IprDocNo.Tables[0].Rows[0]["ENTITY_CODE"].ToString() + "/" + IprDocNo.Tables[0].Rows[0]["BUSS_CODE"].ToString() + "/" +
                    IprDocNo.Tables[0].Rows[0]["UNIT_CODE"].ToString() + "/" + IprDocNo.Tables[0].Rows[0]["FYEAR"].ToString() + "/" +
                    IprDocNo.Tables[0].Rows[0]["MAX_NO"].ToString();
                success = obj.SaveExternalMailRegister(Session["EmpCode"].ToString(), DocumentNo, HttpUtility.HtmlEncode(txtDate.Text.Trim()), ddlEmployeeName.SelectedItem.Text
                , ddlDepartment.SelectedValue, HttpUtility.HtmlEncode(txtReceiverName.Text.Trim()), HttpUtility.HtmlEncode(txtDestination.Text.Trim()),
                ddlCourierPost.SelectedValue, HttpUtility.HtmlEncode(txtReceiptNo.Text.Trim()), HttpUtility.HtmlEncode(txtTimeIn.Text.Trim()), HttpUtility.HtmlEncode(txtTimeOut.Text.Trim()),
                ddlDocumentParcel.SelectedValue, HttpUtility.HtmlEncode(txtWeight.Text.Trim()), HttpUtility.HtmlEncode(txtAmount.Text.Trim()), HttpUtility.HtmlEncode(txtRemark.Text.Trim()), "Outgoing", "A");
                if (success > 0)
                {
                    ClearFormData();
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "showSuccessToast", "showToast('success', 'External Mail Register (Outgoing) detail is successfully saved.', 'Success');", true);
                   // ScriptManager.RegisterStartupScript(this, this.GetType(), "showToastAndRedirect", "showToastAndRedirect('success', 'External Mail Register (Outgoing) detail is successfully saved.', 'Success', 'ListOfExternalMailOutging.aspx','1000');", true);
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "showErrorToast", "showToast('error', 'External Mail Register (Outgoing) detail not saved. Please try again later.', 'Error');", true);
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region ClearFormData
    private void ClearFormData()
    {
        try
        {
            txtDate.Text = "";
            ddlEmployeeName.SelectedValue = "";
            ddlDepartment.SelectedValue = "";
            txtReceiverName.Text = "";
            txtDestination.Text = "";
            ddlCourierPost.SelectedValue = "";
            txtReceiptNo.Text = "";
            txtTimeIn.Text = "";
            txtTimeOut.Text = "";
            ddlDocumentParcel.SelectedValue = "";
            txtWeight.Text = "";
            txtRemark.Text = "";
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
}