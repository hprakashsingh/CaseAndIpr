﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Security.Cryptography;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class PolicyRequest_ViewDocViewRequest : System.Web.UI.Page
{
    #region VariableDeclare
    PolicyMaker obj = new PolicyMaker();
    MailUtility objm = new MailUtility();
    #endregion
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Request.QueryString["ReqId"] != null)
            {
                hndReqId.Value = CommonUtility.Decryption(HttpUtility.UrlDecode(Request.QueryString["ReqId"].ToString()));
                GetDocViewRightsRequestDetails();
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "alert('Dear User, You do not have permission to access directly this page.');window.location ='Dashboard.aspx';", true);
            }
        }
    }
    #region GetDocViewRightsRequestDetails
    public void GetDocViewRightsRequestDetails()
    {
        try
        {
            DataSet ds = obj.GetDocViewRightsRequestDetails(Session["EmpCode"].ToString(), hndReqId.Value);
            if (ds.Tables[0].Rows.Count > 0)
            {
                grdDocViewRightsRequest.DataSource = ds.Tables[0];
                grdDocViewRightsRequest.DataBind();
            }
            if (ds.Tables[1].Rows.Count > 0)
            {
                lblRequesterName.Text = ds.Tables[1].Rows[0]["Employee_Name"].ToString();
                lblRequesterSign.Text = ds.Tables[1].Rows[0]["Employee_Name"].ToString();
                lblRequesterDate.Text = ds.Tables[1].Rows[0]["Created_On"].ToString();
                lblDocumentNo.Text = ds.Tables[1].Rows[0]["Document_No"].ToString();
                hndStatusId.Value = ds.Tables[1].Rows[0]["Status_Id"].ToString();
                rdlRequestercreated.SelectedValue = ds.Tables[1].Rows[0]["REQUESTORID_YESNO"].ToString();
                rblCompanyOwnedLaptop.SelectedValue = ds.Tables[1].Rows[0]["COMOWNLAPTOP_YESNO"].ToString();
                rdlHardeningOfLaptop.SelectedValue = ds.Tables[1].Rows[0]["HARDENINGLAPTOP_YESNO"].ToString();
                rblViewRightsAllocated.SelectedValue = ds.Tables[1].Rows[0]["VIEWRIGHTSALLOCATED_YESNO"].ToString();
                if (hndStatusId.Value.Equals("4"))
                {
                    btnPrintDocViewRequest.Visible = true;
                }
            }
            if (ds.Tables[2].Rows.Count > 0)
            {
                lblHodName.Text = ds.Tables[2].Rows[0]["Employee_Name"].ToString();
                lblHodApprovalDate.Text = ds.Tables[2].Rows[0]["Action_On"].ToString() == "" ? "-" : ds.Tables[2].Rows[0]["Action_On"].ToString();
                if (ds.Tables[2].Rows[0]["Status_Id"].ToString().Equals("5"))
                {
                    lblHodApprovalSign.ForeColor = Color.Red;
                    lblHodApprovalSign.Text = ds.Tables[2].Rows[0]["Employee_Name"].ToString() + "(" + ds.Tables[2].Rows[0]["Status_Name"].ToString() + ")";
                }
                else
                {
                    lblHodApprovalSign.ForeColor = Color.Green;
                    lblHodApprovalSign.Text = ds.Tables[2].Rows[0]["Employee_Name"].ToString() + "(" + ds.Tables[2].Rows[0]["Status_Name"].ToString() + ")";
                }
                lblHodComments.Text = ds.Tables[2].Rows[0]["Comments"].ToString();

                lblLevel2Name.Text = ds.Tables[2].Rows[1]["Employee_Name"].ToString();
                lblLevel2Date.Text = ds.Tables[2].Rows[1]["Action_On"].ToString() == "" ? "-" : ds.Tables[2].Rows[1]["Action_On"].ToString();
                if (ds.Tables[2].Rows[1]["Status_Id"].ToString().Equals("5"))
                {
                    lblLevel2Sign.ForeColor = Color.Red;
                    lblLevel2Sign.Text = ds.Tables[2].Rows[1]["Employee_Name"].ToString() + "(" + ds.Tables[2].Rows[1]["Status_Name"].ToString() + ")";
                }
                else
                {
                    lblLevel2Sign.ForeColor = Color.Green;
                    lblLevel2Sign.Text = ds.Tables[2].Rows[1]["Employee_Name"].ToString() + "(" + ds.Tables[2].Rows[1]["Status_Name"].ToString() + ")";
                }
                lblLevel2Comments.Text = ds.Tables[2].Rows[1]["Comments"].ToString();

                lblLevel3Name.Text = ds.Tables[2].Rows[2]["Employee_Name"].ToString();
                lblLevel3Date.Text = ds.Tables[2].Rows[2]["Action_On"].ToString() == "" ? "-" : ds.Tables[2].Rows[2]["Action_On"].ToString();
                if (ds.Tables[2].Rows[2]["Status_Id"].ToString().Equals("5"))
                {
                    lblLevel3Sign.ForeColor = Color.Red;
                    lblLevel3Sign.Text = ds.Tables[2].Rows[2]["Employee_Name"].ToString() + "(" + ds.Tables[2].Rows[2]["Status_Name"].ToString() + ")";
                }
                else
                {
                    lblLevel3Sign.ForeColor = Color.Green;
                    lblLevel3Sign.Text = ds.Tables[2].Rows[2]["Employee_Name"].ToString() + "(" + ds.Tables[2].Rows[2]["Status_Name"].ToString() + ")";
                }
                lblLevel3Comments.Text = ds.Tables[2].Rows[2]["Comments"].ToString();

                lblLevel4Name.Text = ds.Tables[2].Rows[3]["Employee_Name"].ToString();
                lblLevel4Date.Text = ds.Tables[2].Rows[3]["Action_On"].ToString() == "" ? "-" : ds.Tables[2].Rows[3]["Action_On"].ToString();
                if (ds.Tables[2].Rows[3]["Status_Id"].ToString().Equals("5"))
                {
                    lblLevel4Sign.ForeColor = Color.Red;
                    lblLevel4Sign.Text = ds.Tables[2].Rows[3]["Employee_Name"].ToString() + "(" + ds.Tables[2].Rows[3]["Status_Name"].ToString() + ")";
                }
                else
                {
                    lblLevel4Sign.ForeColor = Color.Green;
                    lblLevel4Sign.Text = ds.Tables[2].Rows[3]["Employee_Name"].ToString() + "(" + ds.Tables[2].Rows[3]["Status_Name"].ToString() + ")";
                }
                lblLevel4Comments.Text = ds.Tables[2].Rows[3]["Comments"].ToString();

                lblLevel5Name.Text = ds.Tables[2].Rows[4]["Employee_Name"].ToString();
                lblLevel5Date.Text = ds.Tables[2].Rows[4]["Action_On"].ToString() == "" ? "-" : ds.Tables[2].Rows[4]["Action_On"].ToString();
                if (ds.Tables[2].Rows[4]["Status_Id"].ToString().Equals("5"))
                {
                    lblLevel5Sign.ForeColor = Color.Red;
                    lblLevel5Sign.Text = ds.Tables[2].Rows[4]["Employee_Name"].ToString() + "(" + ds.Tables[2].Rows[4]["Status_Name"].ToString() + ")";
                }
                else
                {
                    lblLevel5Sign.ForeColor = Color.Green;
                    lblLevel5Sign.Text = ds.Tables[2].Rows[4]["Employee_Name"].ToString() + "(" + ds.Tables[2].Rows[4]["Status_Name"].ToString() + ")";
                }
                lblLevel5Comments.Text = ds.Tables[2].Rows[4]["Comments"].ToString();

                for (int i = 0; i < ds.Tables[2].Rows.Count; i++)
                {
                    if (hndStatusId.Value.Equals("6") && ds.Tables[2].Rows[i]["Emp_Code"].ToString().Equals(Session["EmpCode"].ToString()) && ds.Tables[2].Rows[i]["Status_Id"].ToString().Equals("3"))
                    {
                        btnAction.Visible = true;
                        hndApprovalId.Value = ds.Tables[2].Rows[i]["Approval_Id"].ToString();
                        hndLevelId.Value = ds.Tables[2].Rows[i]["Level_Id"].ToString();
                        if(ds.Tables[2].Rows[i]["Level_Id"].ToString().Equals("2"))
                        {
                            rdlRequestercreated.Enabled= true;
                            rblCompanyOwnedLaptop.Enabled= true;
                            rfvRequestercreated.Visible= true;
                            rfvCompanyOwnedLaptop.Visible= true;
                        }
                        if (ds.Tables[2].Rows[i]["Level_Id"].ToString().Equals("3"))
                        {
                            rdlHardeningOfLaptop.Enabled = true;
                            rfvHardeningOfLaptop.Visible = true;
                        }
                        if (ds.Tables[2].Rows[i]["Level_Id"].ToString().Equals("5"))
                        {
                            rblViewRightsAllocated.Enabled = true;
                            rfvViewRightsAllocated.Visible = true;
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region OpenAlertBox
    protected void btnAction_Click(object sender, EventArgs e)
    {
        try
        {
            ActionNotificationBox.Show();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region RejectRequest
    protected void btnRejectRequest_Click(object sender, EventArgs e)
    {
        int success = 0;
        string Subject = string.Empty;
        string Body = string.Empty;
        string Url = string.Empty;
        try
        {
            DataSet ds = obj.GetDocViewRightsRequestDetails(Session["EmpCode"].ToString(), hndReqId.Value);
            if (ds.Tables[1].Rows.Count > 0)
            {
                Subject = "Document View Right Request Document No.:- " + lblDocumentNo.Text;
                Body = "Your request for Document View Right has been rejected by " + Session["EmployeeName"].ToString() + ". Kindly review the details.";
                Url = "#";
                string empCode = Session["EmpCode"].ToString();
                string ReqId = hndReqId.Value;
                string additionalComment = HttpUtility.HtmlEncode(txtAdditionalComment.Text.Trim());
                success = obj.RejectDocViewRightsRequest(empCode, ReqId, "5", additionalComment, hndLevelId.Value, hndApprovalId.Value);
                if (success > 0)
                {
                    Url = "https://intranet.dsgroup.com/OnlineITForms/SpocRequest/ViewDocViewRequest.aspx?ReqId=" + CommonUtility.Encryption(hndReqId.Value) + "&emp_code=" + CommonUtility.Encryption(HttpUtility.UrlEncode(ds.Tables[1].Rows[0]["Emp_Code"].ToString()));
                    objm.SendMailForPolicyDoc(Session["EmpEmail"].ToString(), Session["EmployeeName"].ToString(), ds.Tables[1].Rows[0]["Email_Id"].ToString(), ds.Tables[1].Rows[0]["Employee_Name"].ToString(), Subject, Body, HttpUtility.HtmlEncode(txtAdditionalComment.Text.Trim()), Url);
                    ScriptManager.RegisterStartupScript(this, GetType(), "Javascript",
                        "javascript:SweetDynamicSuccessRedirect('Document View Right Request', 'Document View Right Request is successfully rejected.', 'DocViewReqDashBoard.aspx');", true);
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "Javascript", "javascript:SweetWrong('Due to technical or Internet connectivity issue Document View Right Request is not rejected. Please try again later.'); ", true);
                    ActionNotificationBox.Show();
                }
            }
        }
        catch(Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region ApprovedRequest
    protected void btnApprovedRequest_Click(object sender, EventArgs e)
    {
        int success = 0;
        string Subject = string.Empty;
        string Body = string.Empty;
        string Url = string.Empty;
        try
        {
            DataSet ds = obj.GetDocViewRightsRequestDetails((Convert.ToInt32(hndLevelId.Value) + 1).ToString(), hndReqId.Value);
            if (ds.Tables[1].Rows.Count > 0)
            {
                string empCode = Session["EmpCode"].ToString();
                string ReqId = hndReqId.Value;
                string additionalComment = HttpUtility.HtmlEncode(txtAdditionalComment.Text.Trim());
                success = obj.ApprovedDocViewRightsRequest(empCode, ReqId, "4", additionalComment, hndLevelId.Value, hndApprovalId.Value,
                    rdlRequestercreated.SelectedValue, rblCompanyOwnedLaptop.SelectedValue, rdlHardeningOfLaptop.SelectedValue, rblViewRightsAllocated.SelectedValue);
                if (success > 0)
                {
                    Subject = "Document View Right Request Document No.:- " + lblDocumentNo.Text;
                    Body = "Your request for Document View Right has been approved by " + Session["EmployeeName"].ToString() + ". Kindly check the same.";
                    Url = "#";
                    Url = "https://intranet.dsgroup.com/OnlineITForms/SpocRequest/ViewDocViewRequest.aspx?ReqId=" + CommonUtility.Encryption(hndReqId.Value) + "&emp_code=" + CommonUtility.Encryption(HttpUtility.UrlEncode(ds.Tables[1].Rows[0]["Emp_Code"].ToString()));
                    if (ds.Tables[3].Rows.Count > 0)
                    {
                        Subject = "Document View Right Request Document No.:- " + lblDocumentNo.Text;
                        Body = "You have received a new Document View Right Request. Kindly review it and take appropriate action.";
                        Url = "#";
                        Url = "https://intranet.dsgroup.com/OnlineITForms/SpocRequest/ViewDocViewRequest.aspx?ReqId=" + CommonUtility.Encryption(hndReqId.Value) + "&emp_code=" + CommonUtility.Encryption(HttpUtility.UrlEncode(ds.Tables[3].Rows[0]["Emp_Code"].ToString()));
                        objm.SendMailForPolicyDoc(Session["EmpEmail"].ToString(), Session["EmployeeName"].ToString(), ds.Tables[3].Rows[0]["Email_Id"].ToString(), ds.Tables[3].Rows[0]["Employee_Name"].ToString(), Subject, Body, HttpUtility.HtmlEncode(txtAdditionalComment.Text.Trim()), Url);
                    }
                    objm.SendMailForPolicyDoc(Session["EmpEmail"].ToString(), Session["EmployeeName"].ToString(), ds.Tables[1].Rows[0]["Email_Id"].ToString(), ds.Tables[1].Rows[0]["Employee_Name"].ToString(), Subject, Body, HttpUtility.HtmlEncode(txtAdditionalComment.Text.Trim()), Url);
                    ScriptManager.RegisterStartupScript(this, GetType(), "Javascript",
                        "javascript:SweetDynamicSuccessRedirect('Document View Right Request', 'Document View Right request is successfully approved.', 'DocViewReqDashBoard.aspx');", true);
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "Javascript", "javascript:SweetWrong('Due to technical or Internet connectivity issue Document View Right Request is not Approved. Please try again later.'); ", true);
                }
            }
        }
        catch(Exception ex)
        {
            throw ex;
        }
    }
    #endregion
}