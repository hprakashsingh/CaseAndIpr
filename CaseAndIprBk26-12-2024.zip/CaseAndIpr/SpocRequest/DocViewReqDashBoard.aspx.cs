﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class PolicyRequest_DocViewReqDashBoard : System.Web.UI.Page
{
    #region VariableDeclare
    PolicyMaker obj = new PolicyMaker();
    protected string MyRequest;
    protected string PendingRequest;
    protected string ApprovedRequest;
    protected string RejectRequest;
    #endregion
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["EmpCode"] != null)
            {
                GetDashboardDetails();
                //obj.updateflag("41");
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "Javascript", "javascript:SweetDynamicWrongRedirect('Oops...','Dear user your session has been expired.Please try again later.','Dashboard.aspx'); ", true);
            }
        }
    }
    #region GetUserDetails
    public void GetUserDetails(string EmpCode)
    {
        try
        {
            DataSet ds = obj.GetUserDetailsForLogin(EmpCode);
            if (ds.Tables[0].Rows.Count > 0)
            {
                Session["EmployeeName"] = ds.Tables[0].Rows[0]["Employee_Name"].ToString();
                Session["EmpCode"] = ds.Tables[0].Rows[0]["Emp_Code"].ToString();
                Session["EmpEmail"] = ds.Tables[0].Rows[0]["Email_ID"].ToString();
                Session["HodName"] = ds.Tables[0].Rows[0]["HodName"].ToString();
                Session["HodCode"] = ds.Tables[0].Rows[0]["Func_Reportg"].ToString();
                Session["HodEmail"] = ds.Tables[0].Rows[0]["HodEmail"].ToString();
                Session["HodDepartment"] = ds.Tables[0].Rows[0]["HodDepartment"].ToString();
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region GetDashboardDetails
    public void GetDashboardDetails()
    {
        try
        {
            if (Session["EmpCode"] != null)
            {
                string empCode = Session["EmpCode"].ToString();
                DataSet ds = obj.GetocViewReqDashBoard(empCode);
                if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    MyRequest = ds.Tables[0].Rows[0]["MyRequest"].ToString();
                    PendingRequest = ds.Tables[0].Rows[1]["MyRequest"].ToString();
                    ApprovedRequest = ds.Tables[0].Rows[2]["MyRequest"].ToString();
                    RejectRequest = ds.Tables[0].Rows[3]["MyRequest"].ToString();
                }
                DataSet ds1 = obj.GetListOfDocViewRequest(empCode, "Pending Request");

                if (ds1.Tables.Count > 0 && ds1.Tables[0].Rows.Count > 0)
                {
                    GrdListOfDocViewRequest.DataSource = ds1.Tables[0];
                    GrdListOfDocViewRequest.DataBind();
                }
                else
                {
                    GrdListOfDocViewRequest.DataSource = null;
                    GrdListOfDocViewRequest.DataBind();
                }
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "Javascript", "javascript:SweetDynamicWrongRedirect('Oops...','Dear user your session has been expired.Please try again later.','https://intranet.dsgroup.com/intranet/home.aspx'); ", true);
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
}