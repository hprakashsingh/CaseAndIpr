﻿using DocumentFormat.OpenXml.Office2010.CustomUI;
using Org.BouncyCastle.Asn1.Cmp;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class SpocRequest_AddUpdateSubProcess : System.Web.UI.Page
{
    #region Variabledeclare
    SegregationForm obj = new SegregationForm();
    #endregion
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["EmpCode"] != null)
            {
                GetMasterData();
                GetSubProcessList();
            }
        }
    }
    #region GetSubProcessList
    private void GetSubProcessList()
    {
        try
        {
            DataSet ds = obj.GetSubProcessList(Session["EmpCode"].ToString());
            if (ds.Tables[0].Rows.Count > 0)
            {
                GrdSubProcess.DataSource = ds.Tables[0];
                GrdSubProcess.DataBind();
            }
            else
            {
                GrdSubProcess.DataSource = ds.Tables[0];
                GrdSubProcess.DataBind();
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region GetMasterData
    private void GetMasterData()
    {
        try
        {
            DataSet ds = obj.GetMasterData(Session["EmpCode"].ToString(), Session["DeptCode"].ToString());
            if (ds.Tables[0].Rows.Count > 0)
            {
                ddlProcess.DataSource = ds.Tables[0];
                ddlProcess.DataTextField = "Process";
                ddlProcess.DataValueField = "ProcessId";
                ddlProcess.DataBind();
                ddlProcess.Items.Insert(0, new ListItem("--Select Process--", ""));
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region Add/UpdateSubProcess
    protected void btnAddSubProcess_Click(object sender, EventArgs e)
    {
        int success = 0;
        try
        {
            success = obj.AddUpdateSubProcess(Session["EmpCode"].ToString(), hndSubProcessId.Value ,ddlProcess.SelectedValue,HttpUtility.HtmlEncode(txtSubProcess.Text.Trim()), ddlStatus.SelectedValue);
            if (success > 0)
            {
                GetSubProcessList();
                if (hndSubProcessId.Value.Equals(""))
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "showSuccessToast", "showToast('success', 'Sub Process is successfully added.', 'Success');", true);
                }
                else if (hndSubProcessId.Value != "")
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "showSuccessToast", "showToast('success', 'Sub Process is successfully updated.', 'Success');", true);
                }
                ClearFormData();
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "showErrorToast", "showToast('error', 'Sub Process is not added. Please try again later.', 'Error');", true);
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region ClearFormData
    private void ClearFormData()
    {
        try
        {
            hndSubProcessId.Value = "";
            txtSubProcess.Text = "";
            ddlStatus.SelectedValue = "";
            ddlProcess.SelectedValue = "";
            btnAddSubProcess.Text = "Add Sub Process";
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region UpdateSubProcess
    protected void GrdSubProcess_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            if (e.CommandName.Equals("EditSubProcess"))
            {
                hndSubProcessId.Value = e.CommandArgument.ToString();
                DataSet ds = obj.GetSubProcessList(Session["EmpCode"].ToString(), hndSubProcessId.Value);
                if (ds.Tables[1].Rows.Count > 0)
                {
                    ddlProcess.SelectedValue = ds.Tables[1].Rows[0]["ProcessId"].ToString();
                    txtSubProcess.Text = HttpUtility.HtmlDecode(ds.Tables[1].Rows[0]["SUB_PROCESS"].ToString());
                    ddlStatus.SelectedValue = HttpUtility.HtmlDecode(ds.Tables[1].Rows[0]["Status"].ToString());
                    btnAddSubProcess.Text = "Update Process";
                    btnAddSubProcess.Focus();
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region ResetPageData
    protected void btnReset_Click(object sender, EventArgs e)
    {
        try
        {
            ClearFormData();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
}