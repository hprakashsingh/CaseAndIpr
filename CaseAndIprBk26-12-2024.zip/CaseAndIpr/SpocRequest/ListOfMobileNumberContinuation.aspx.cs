﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ClosedXML.Excel;

public partial class SpocRequest_ListOfMobileNumberContinuation : System.Web.UI.Page
{
    #region DeclareVariable
    ExternalMailRegister obj = new ExternalMailRegister();
    #endregion
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["EmpCode"] != null)
            {
                GetListOfMobileNumberContinuation();
            }
        }
    }
    #region GetListOfMobileNumberContinuation
    public void GetListOfMobileNumberContinuation()
    {
        try
        {
            DataSet ds = obj.GetListOfMobileNumberContinuation(Session["EmpCode"].ToString());

            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                GrdListOfMobileNumberContinuation.DataSource = ds.Tables[0];
                GrdListOfMobileNumberContinuation.DataBind();
            }
            else
            {
                GrdListOfMobileNumberContinuation.DataSource = ds.Tables[0];
                GrdListOfMobileNumberContinuation.DataBind();
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region ExportDataToExcel
    protected void btnExportToExcel_Click(object sender, EventArgs e)
    {
        // Prepare a DataTable to store GridView data
        DataTable dt = new DataTable("MobileNumberContinuation");

        // Add columns to the DataTable (same as the GridView)
        dt.Columns.Add("View");
        dt.Columns.Add("Row Number");
        dt.Columns.Add("Document No");
        dt.Columns.Add("Mobile No.");
        dt.Columns.Add("Employee Name");
        dt.Columns.Add("Created Date");
        dt.Columns.Add("HOD");
        dt.Columns.Add("HOD Status");
        dt.Columns.Add("HOD Action Date");
        dt.Columns.Add("Administration");
        dt.Columns.Add("Administration Status");
        dt.Columns.Add("Administration Action Date");
        dt.Columns.Add("Status");

        // Populate the DataTable from GridView rows
        foreach (GridViewRow row in GrdListOfMobileNumberContinuation.Rows)
        {
            DataRow dr = dt.NewRow();

            dr["Row Number"] = ((Label)row.FindControl("lblRowNumber")).Text;
            dr["Document No"] = ((Label)row.FindControl("lblDocumentNo")).Text;
            dr["Mobile No."] = ((Label)row.FindControl("lblMobileNo")).Text;
            dr["Employee Name"] = ((Label)row.FindControl("lblCreated_By_Name")).Text;
            dr["Created Date"] = ((Label)row.FindControl("lblCREATED_ON")).Text;
            dr["HOD"] = ((Label)row.FindControl("lblHod_Name")).Text;
            dr["HOD Status"] = ((Label)row.FindControl("lblHOD_STATUS")).Text;
            dr["HOD Action Date"] = ((Label)row.FindControl("lblHOD_APPROVAL_DATE")).Text;
            dr["Administration"] = ((Label)row.FindControl("lblADMINISTRATION")).Text;
            dr["Administration Status"] = ((Label)row.FindControl("lblADMINISTRATION_STATUS")).Text;
            dr["Administration Action Date"] = ((Label)row.FindControl("lblADMINISTRATION_APPROVAL_DATE")).Text;
            dr["Status"] = row.Cells[12].Text; // Adjust index for the "Status" badge column

            dt.Rows.Add(dr);
        }

        // Use ClosedXML to export the DataTable to Excel
        using (XLWorkbook wb = new XLWorkbook())
        {
            wb.Worksheets.Add(dt, "MobileNumbers");

            Response.Clear();
            Response.Buffer = true;
            Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
            Response.AddHeader("content-disposition", "attachment;filename=MobileNumbersContinuation.xlsx");

            using (System.IO.MemoryStream memoryStream = new System.IO.MemoryStream())
            {
                wb.SaveAs(memoryStream);
                memoryStream.WriteTo(Response.OutputStream);
                Response.Flush();
                Response.End();
            }
        }
    }
    #endregion
    #region PageChangeCode
    protected void GrdListOfMobileNumberContinuation_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            GrdListOfMobileNumberContinuation.PageIndex = e.NewPageIndex;
            this.GetListOfMobileNumberContinuation();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
}