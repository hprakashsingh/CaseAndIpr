﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class SpocRequest_ListOfExternalMailOutging : System.Web.UI.Page
{
    #region DeclareVariable
    ExternalMailRegister obj = new ExternalMailRegister();
    #endregion
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["EmpCode"] != null)
            {
                GetExtenalMailRegister();
            }
        }
    }
    #region GetExtenalMailRegister
    public void GetExtenalMailRegister()
    {
        try
        {
            DataSet ds = obj.GetExtenalMailRegister(Session["EmpCode"].ToString(), "Outgoing");

            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                GrdListOfOutgoing.DataSource = ds.Tables[0];
                GrdListOfOutgoing.DataBind();
            }
            else
            {
                GrdListOfOutgoing.DataSource = ds.Tables[0];
                GrdListOfOutgoing.DataBind();
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region PageChangeCode
    protected void GrdListOfOutgoing_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            GrdListOfOutgoing.PageIndex = e.NewPageIndex;
            this.GetExtenalMailRegister();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
}