﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class SpocRequest_ViewSegregationOfDuties : System.Web.UI.Page
{
    #region Variabledeclare
    SegregationForm obj = new SegregationForm();
    MailUtility objm = new MailUtility();
    string Url = "https://webportal.dsgroup.com/ExternalMailRegister/";
    #endregion
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["EmpCode"] != null)
            {
                GetProcessActivity();
                lblDeptName.Text = Session["DeptName"].ToString();
                lblDeptNameHeader.Text = Session["DeptName"].ToString();
            }
        }
    }
    #region GetProcessActivity
    private void GetProcessActivity()
    {
        try
        {
            DataSet ds = obj.GetProcessActivity(Session["EmpCode"].ToString(), Session["DeptCode"].ToString());
            if (ds.Tables[0].Rows.Count > 0)
            {
                GrdProcessActivity.DataSource = ds.Tables[0];
                GrdProcessActivity.DataBind();
                hndCreaterEmailId.Value = ds.Tables[0].Rows[0]["Creater_Email"].ToString();
            }
            else
            {
                GrdProcessActivity.DataSource = ds.Tables[0];
                GrdProcessActivity.DataBind();
            }
            if (ds.Tables[3].Rows.Count > 0)
            {
                if (ds.Tables[3].Rows[0]["HOD_STATUS"].ToString().Equals("Pending") && Session["EmpCode"].ToString().Equals(ds.Tables[3].Rows[0]["HOD_CODE"].ToString()))
                {
                    btnAction.Visible = true;
                }
                else
                {
                    btnAction.Visible = false;
                }
                lblPreparedBy.Text = ds.Tables[3].Rows[0]["CreatedBy"].ToString();
                lblApprovedBy.Text = ds.Tables[3].Rows[0]["ApprovedBy"].ToString();
                lblApproverStatus.Text = ds.Tables[3].Rows[0]["HOD_STATUS"].ToString();
                lblApproverDate.Text = ds.Tables[3].Rows[0]["HOD_APPROVAL_DATE"].ToString();
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region GetSubProcessList
    protected void GrdProcessActivity_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            // Find the child GridView inside the parent GridView's row
            GridView GrdSubProcess = (GridView)e.Row.FindControl("GrdSubProcess");

            // Find the HiddenField control.
            HiddenField hndProcessId = (e.Row.FindControl("hndProcessId") as HiddenField);
            DataSet ds = obj.GetProcessActivity(Session["EmpCode"].ToString(), Session["DeptCode"].ToString(), hndProcessId.Value);
            if (ds.Tables[1].Rows.Count > 0)
            {
                GrdSubProcess.DataSource = ds.Tables[1];
                GrdSubProcess.DataBind();
            }
            else
            {
                GrdSubProcess.DataSource = ds.Tables[1];
                GrdSubProcess.DataBind();
            }
        }
        //if (e.Row.RowType == DataControlRowType.DataRow)
        //{
        //    GridView grdSubProcess = (GridView)e.Row.FindControl("GrdSubProcess");
        //    foreach (GridViewRow subRow in grdSubProcess.Rows)
        //    {
        //        GridView grdActivity = (GridView)subRow.FindControl("GrdActivity");
        //        grdActivity.ShowHeader = false; // Adjust conditionally if needed
        //    }
        //}
    }
    #endregion
    #region SubProcessActivityDataBinding
    protected void GrdSubProcess_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            GridView GrdActivity = e.Row.FindControl("GrdActivity") as GridView;
            HiddenField hndProcessId1 = e.Row.FindControl("hndProcessId1") as HiddenField;
            HiddenField hndSubProcessId = e.Row.FindControl("hndSubProcessId") as HiddenField;

            if (GrdActivity != null && hndProcessId1 != null && hndSubProcessId != null)
            {
                DataSet ds = obj.GetProcessActivity(Session["EmpCode"].ToString(), Session["DeptCode"].ToString(), hndProcessId1.Value, hndSubProcessId.Value);

                // Bind Activity GridView
                GrdActivity.DataSource = ds.Tables[2];
                GrdActivity.DataBind();
            }
        }
    }
    #endregion
    #region ViewActionNotificationBox
    protected void btnAction_Click(object sender, EventArgs e)
    {
        try
        {
            ActionNotificationBox.Show();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region ApproveRequest
    protected void btnApprovedRequest_Click(object sender, EventArgs e)
    {
        try
        {
            int success = ApproveRejectRequest("Approved");

            if (success > 0)
            {
                // Prepare email details
                string subject = "Segregation of Duties.";
                string body = "Your request for Segregation of Duties has been approved by " + Session["EmployeeName"].ToString() + ". Kindly review the details.";
                Url = Url + "SpocRequest/ViewSegregationOfDuties.aspx";

                // Send rejection email
                SendEmail(Session["EmpEmail"].ToString(), Session["EmployeeName"].ToString(),
                          lblPreparedBy.Text,
                          hndCreaterEmailId.Value,
                          subject, body, txtAdditionalComment.Text.Trim(), Url);

                GetProcessActivity();
                // Show success toast 
                ScriptManager.RegisterStartupScript(this, this.GetType(), "showSuccessToast", "showToast('success', 'Segregation of Duties request is successfully approved.', 'Success');", true);
            }
            else
            {
                // Show error toast
                ScriptManager.RegisterStartupScript(this, this.GetType(),
                    "showErrorToast",
                    "showToast('error', 'Segregation of Duties is not rejected. Please try again later!', 'Error');",
                    true);
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region RejectRequest
    protected void btnRejectRequest_Click(object sender, EventArgs e)
    {
        try
        {
            int success = ApproveRejectRequest("Reject");

            if (success > 0)
            {
                // Prepare email details
                string subject = "Segregation of Duties.";
                string body = "Your request for Segregation of Duties has been rejected by " + Session["EmployeeName"].ToString() + ". Kindly review the details.";
                Url = Url + "SpocRequest/ViewSegregationOfDuties.aspx";

                // Send rejection email
                SendEmail(Session["EmpEmail"].ToString(), Session["EmployeeName"].ToString(),
                          lblPreparedBy.Text,
                          hndCreaterEmailId.Value,
                          subject, body, txtAdditionalComment.Text.Trim(), Url);

                GetProcessActivity();
                // Show success toast 
                ScriptManager.RegisterStartupScript(this, this.GetType(), "showSuccessToast", "showToast('success', 'Segregation of Duties request is successfully rejected.', 'Success');", true);
            }
            else
            {
                // Show error toast
                ScriptManager.RegisterStartupScript(this, this.GetType(),
                    "showErrorToast",
                    "showToast('error', 'Segregation of Duties is not rejected. Please try again later!', 'Error');",
                    true);
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region SendEmail
    private void SendEmail(string senderEmail, string senderName, string recipientName, string recipientEmail, string subject, string body, string additionalComments, string url)
    {
        if (!string.IsNullOrWhiteSpace(senderEmail) && !string.IsNullOrWhiteSpace(recipientEmail))
        {
            objm.SendMail(senderEmail, senderName, recipientEmail, recipientName, subject, body, HttpUtility.HtmlEncode(additionalComments), url);
        }
    }
    #endregion
    #region ApproveRejectRequest
    public int ApproveRejectRequest(string Status)
    {
        int success = 0;
        try
        {
            success = obj.ApproveRejectSegregationOfDuties(Session["EmpCode"].ToString(), Session["DeptCode"].ToString(), HttpUtility.HtmlEncode(txtAdditionalComment.Text.Trim()), Status);
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return success;
    }
    #endregion
}