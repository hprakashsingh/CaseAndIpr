﻿using DocumentFormat.OpenXml.InkML;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class SpocRequest_CreateSegregation : System.Web.UI.Page
{
    #region Variabledeclare
    SegregationForm obj = new SegregationForm();
    MailUtility objm = new MailUtility();
    string Url = "https://webportal.dsgroup.com/ExternalMailRegister/";
    #endregion
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["EmpCode"] != null)
            {
                GetMasterData();
                GetProcessActivity();
                lblPreparedBy.Text = Session["EmployeeName"].ToString();
                lblDeptName.Text = Session["DeptName"].ToString();
                lblDeptNameHeader.Text = Session["DeptName"].ToString();
            }
        }
    }
    #region GetMasterData
    private void GetMasterData()
    {
        try
        {
            DataSet ds = obj.GetMasterData(Session["EmpCode"].ToString(), Session["DeptCode"].ToString());
            if (ds.Tables[4].Rows.Count > 0)
            {
                hndApprovedBy.Value = ds.Tables[4].Rows[0]["HodCode"].ToString();
                lblApprovedBy.Text = ds.Tables[4].Rows[0]["HodName"].ToString();
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "showToastAndRedirect", "showToastAndRedirect('error', 'our HOD is not defined in the HRM Portal. Please contact your HR administrator for assistance.', 'Session Expired', 'AddUpdateProcess.aspx','1000');", true);
                return;
            }
            if (ds.Tables[0].Rows.Count > 0)
            {
                ddlProcess.DataSource = ds.Tables[0];
                ddlProcess.DataTextField = "Process";
                ddlProcess.DataValueField = "ProcessId";
                ddlProcess.DataBind();
                ddlProcess.Items.Insert(0, new ListItem("--Select Process--", ""));
            }
            if (ds.Tables[1].Rows.Count > 0)
            {
                ddlTeamLeader.DataSource = ds.Tables[1];
                ddlTeamLeader.DataTextField = "EMPLOYEE_NAME";
                ddlTeamLeader.DataValueField = "EMP_CODE";
                ddlTeamLeader.DataBind();
                ddlTeamLeader.Items.Insert(0, new ListItem("--Select Team Leader--", ""));
            }
            if (ds.Tables[1].Rows.Count > 0)
            {
                ddlMaker.DataSource = ds.Tables[1];
                ddlMaker.DataTextField = "EMPLOYEE_NAME";
                ddlMaker.DataValueField = "EMP_CODE";
                ddlMaker.DataBind();
            }
            //if (ds.Tables[1].Rows.Count > 0)
            //{
            //    ddlChecker.DataSource = ds.Tables[1];
            //    ddlChecker.DataTextField = "EMPLOYEE_NAME";
            //    ddlChecker.DataValueField = "EMP_CODE";
            //    ddlChecker.DataBind();
            //}
            if (ds.Tables[1].Rows.Count > 0)
            {
                ddlApprover.DataSource = ds.Tables[1];
                ddlApprover.DataTextField = "EMPLOYEE_NAME";
                ddlApprover.DataValueField = "EMP_CODE";
                ddlApprover.DataBind();
            }
            if (ds.Tables[1].Rows.Count > 0)
            {
                ddlCustodian.DataSource = ds.Tables[1];
                ddlCustodian.DataTextField = "EMPLOYEE_NAME";
                ddlCustodian.DataValueField = "EMP_CODE";
                ddlCustodian.DataBind();
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region GetSubProcessList
    protected void ddlProcess_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            DataSet ds = obj.GetSubProcess(Session["EmpCode"].ToString(),ddlProcess.SelectedValue);
            if (ds.Tables[0].Rows.Count > 0)
            {
                ddlSubProcess.DataSource = ds.Tables[0];
                ddlSubProcess.DataTextField = "Sub_Process";
                ddlSubProcess.DataValueField = "SubProcessId";
                ddlSubProcess.DataBind();
                ddlSubProcess.Items.Insert(0, new ListItem("--Select Sub Process--", ""));
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region SaveProcess
    protected void btnAddProcess_Click(object sender, EventArgs e)
    {
        try
        {
            var connectionString = ConfigurationManager.ConnectionStrings["ELogBook"].ConnectionString;
            using (var conn = new OracleConnection(connectionString))
            {
                conn.Open();
                using (var transaction = conn.BeginTransaction())
                {
                    try
                    {
                        if (!SaveProcess(conn, transaction) || !SaveSubProcess(conn, transaction))
                        {
                            ShowToast("error", "Due to technical or network connectivity issue. Process is not saved. Please try again later!", "Error");
                            transaction.Rollback();
                            return;
                        }

                        if (SaveActivity(conn, transaction))
                        {
                            ClearFormData();
                            ShowToast("success", "Process is successfully saved.", "success");
                            transaction.Commit();
                            GetProcessActivity();
                        }
                        else
                        {
                            ShowToast("error", "Due to technical or network connectivity issue. Process is not saved. Please try again later!", "Error");
                            transaction.Rollback();
                        }
                    }
                    catch
                    {
                        transaction.Rollback();
                        throw;
                    }
                }
            }
        }
        catch (Exception ex)
        {
            LogError(ex);
            ShowToast("error", "An unexpected error occurred. Please try again later.", "Error");
        }
    }
    #endregion
    #region HelperMethods

    private bool SaveProcess(OracleConnection conn, OracleTransaction transaction)
    {
        var ds = obj.GetMasterData(Session["EmpCode"].ToString(), Session["DeptCode"].ToString(), ddlProcess.SelectedValue);
        if (ds.Tables[2].Rows.Count > 0)
            return true;

        return obj.SaveDeptProcessRequest(Session["EmpCode"].ToString(), Session["DeptCode"].ToString(), ddlProcess.SelectedValue, hndApprovedBy.Value,conn, transaction) > 0;
    }

    private bool SaveSubProcess(OracleConnection conn, OracleTransaction transaction)
    {
        var ds = obj.GetMasterData(Session["EmpCode"].ToString(), Session["DeptCode"].ToString(), ddlProcess.SelectedValue, ddlSubProcess.SelectedValue);
        if (ds.Tables[3].Rows.Count > 0)
            return true;

        return obj.SaveDeptSubProcessRequest(Session["EmpCode"].ToString(), Session["DeptCode"].ToString(), ddlProcess.SelectedValue, ddlSubProcess.SelectedValue, conn, transaction) > 0;
    }

    private bool SaveActivity(OracleConnection conn, OracleTransaction transaction)
    {
        int activityMsg = obj.SaveDeptActivity(Session["EmpCode"].ToString(), Session["DeptCode"].ToString(), ddlProcess.SelectedValue, ddlSubProcess.SelectedValue,
                                               HttpUtility.HtmlEncode(txtActivity.Text.Trim()), ddlTeamLeader.SelectedValue, conn, transaction);
        if (activityMsg <= 0)
            return false;

        var ds = obj.GetActivityMaxId(Session["EmpCode"].ToString(), conn, transaction);
        if (ds.Tables[0].Rows.Count <= 0)
            return false;

        string maxId = ds.Tables[0].Rows[0]["MaxId"].ToString();
        SaveUserList(maxId, ddlMaker, "M", conn, transaction);
        SaveUserList(maxId, ddlChecker, "C", conn, transaction);
        SaveUserList(maxId, ddlApprover, "A", conn, transaction);
        SaveUserList(maxId, ddlCustodian, "CD", conn, transaction);
        return true;
    }

    private void SaveUserList(string maxId, ListControl listControl, string role, OracleConnection conn, OracleTransaction transaction)
    {
        foreach (ListItem item in listControl.Items)
        {
            if (item.Selected)
                obj.SaveUserList(Session["EmpCode"].ToString(), maxId, item.Value, role, conn, transaction);
        }
    }

    private void ShowToast(string type, string message, string title)
    {
        string script = string.Format("showToast('{0}', '{1}', '{2}');", type, message, title);
        ScriptManager.RegisterStartupScript(this, GetType(), "showToast", script, true);
    }

    private void ShowToastAndRedirect(string type, string message, string title, string redirectUrl, string delay)
    {
        string script = string.Format(
                "showToastAndRedirect('{0}', '{1}', '{2}', '{3}', '{4}');",
                type, message, title, redirectUrl, delay);
        ScriptManager.RegisterStartupScript(this, GetType(), "showToastAndRedirect", script, true);
    }

    private void LogError(Exception ex)
    {
        // Implement a logging mechanism to log exceptions.
        // Example: Logger.LogError(ex);
    }

    #endregion
    #region ClearFormData
    private void ClearFormData()
    {
        try
        {
            ddlProcess.SelectedValue = "";
            ddlSubProcess.SelectedValue = "";
            txtActivity.Text = "";
            ddlTeamLeader.SelectedValue = "";
            lblSelectedMaker.Text = "";
            lblSelectedChecker.Text = "";
            lblSelectedApprover.Text = "";
            lblSelectedCustodian.Text = "";
            // Explicitly uncheck all items in the listControl
            foreach (ListItem item in ddlMaker.Items)
            {
                item.Selected = false;
            }
            foreach (ListItem item in ddlChecker.Items)
            {
                item.Selected = false;
            }
            foreach (ListItem item in ddlApprover.Items)
            {
                item.Selected = false;
            }
            foreach (ListItem item in ddlCustodian.Items)
            {
                item.Selected = false;
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region GetProcessActivity
    private void GetProcessActivity()
    {
        try
        {
            DataSet ds = obj.GetProcessActivity(Session["EmpCode"].ToString(), Session["DeptCode"].ToString());
            if (ds.Tables[0].Rows.Count > 0)
            {
                if (ds.Tables[0].Rows[0]["Approved_On"].ToString().Equals(""))
                {
                    btnSentForApproval.Visible = true;
                }
                GrdProcessActivity.DataSource = ds.Tables[0];
                GrdProcessActivity.DataBind();
            }
            else
            {
                btnSentForApproval.Visible = false;
                GrdProcessActivity.DataSource = ds.Tables[0];
                GrdProcessActivity.DataBind();
            }
            if (ds.Tables[3].Rows.Count > 0)
            {
                if (ds.Tables[3].Rows[0]["HOD_STATUS"].ToString().Equals("Pending"))
                {
                    lblMsg.Visible = true;
                    btnAddProcess.Visible = false;
                    btnSentForApproval.Visible = false;
                }
                else
                {
                    lblMsg.Visible = false;
                    btnAddProcess.Visible = true;
                    btnSentForApproval.Visible = true;
                }
                lblApproverStatus.Text = ds.Tables[3].Rows[0]["HOD_STATUS"].ToString();
                lblApproverDate.Text = ds.Tables[3].Rows[0]["HOD_APPROVAL_DATE"].ToString();
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region GetSubProcessList
    protected void GrdProcessActivity_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            // Find the child GridView inside the parent GridView's row
            GridView GrdSubProcess = (GridView)e.Row.FindControl("GrdSubProcess");

            // Find the HiddenField control.
            HiddenField hndProcessId = (e.Row.FindControl("hndProcessId") as HiddenField);
            DataSet ds = obj.GetProcessActivity(Session["EmpCode"].ToString(), Session["DeptCode"].ToString(), hndProcessId.Value);
            if (ds.Tables[1].Rows.Count > 0)
            {
                GrdSubProcess.DataSource = ds.Tables[1];
                GrdSubProcess.DataBind();
            }
            else
            {
                GrdSubProcess.DataSource = ds.Tables[1];
                GrdSubProcess.DataBind();
            }
        }
    }
    #endregion
    #region SubProcessActivityDataBinding
    protected void GrdSubProcess_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            GridView GrdActivity = e.Row.FindControl("GrdActivity") as GridView;
            HiddenField hndProcessId1 = e.Row.FindControl("hndProcessId1") as HiddenField;
            HiddenField hndSubProcessId = e.Row.FindControl("hndSubProcessId") as HiddenField;

            if (GrdActivity != null && hndProcessId1 != null && hndSubProcessId != null)
            {
                DataSet ds = obj.GetProcessActivity(Session["EmpCode"].ToString(), Session["DeptCode"].ToString(), hndProcessId1.Value, hndSubProcessId.Value);

                // Bind Activity GridView
                GrdActivity.DataSource = ds.Tables[2];
                GrdActivity.DataBind();
            }
        }
    }
    #endregion
    #region ShowSelectedMaker
    protected void ddlMaker_SelectedIndexChanged(object sender, EventArgs e)
    {
        string SelectedMaker = string.Empty;
        string Filter = string.Empty;
        try
        {
            lblSelectedChecker.Text = "";
            List <String> checkedList = new List<string>();
            foreach (ListItem item in ddlMaker.Items)
            {
                if (item.Selected)
                {
                    checkedList.Add(item.Text);

                    lblSelectedMaker.Text = String.Join(", ", checkedList);
                }
            }
            if (ddlMaker.SelectedValue != "")
            {
                List<String> checkedList1 = new List<string>();
                foreach (ListItem item in ddlMaker.Items)
                {
                    if (item.Selected)
                    {
                        checkedList1.Add(item.Value);

                        SelectedMaker = String.Join(",", checkedList1);
                    }
                }

                // Assuming ddlMaker.SelectedValue contains a comma-separated list of zone descriptions
                string[] Maker = SelectedMaker.Split(',');
                string formattedZones = "";
                for (int i = 0; i < Maker.Length; i++)
                {
                    if (i != 0)
                    {
                        formattedZones += ",";
                    }
                    formattedZones += "'" + Maker[i].Trim() + "'";
                }
                Filter = " (" + formattedZones + ")";

                DataSet ds = obj.GetCheckerUser(Session["EmpCode"].ToString(), Session["DeptCode"].ToString(), Filter);

                if (ds.Tables[0].Rows.Count > 0)
                {
                    ddlChecker.DataSource = ds.Tables[0];
                    ddlChecker.DataTextField = "EMPLOYEE_NAME";
                    ddlChecker.DataValueField = "EMP_CODE";
                    ddlChecker.DataBind();
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region ShowSelectedChecker
    protected void ddlChecker_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            List<String> checkedList = new List<string>();
            foreach (ListItem item in ddlChecker.Items)
            {
                if (item.Selected)
                {
                    checkedList.Add(item.Text);

                    lblSelectedChecker.Text = String.Join(", ", checkedList);
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region ShowSelectedApprover
    protected void ddlApprover_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            List<String> checkedList = new List<string>();
            foreach (ListItem item in ddlApprover.Items)
            {
                if (item.Selected)
                {
                    checkedList.Add(item.Text);

                    lblSelectedApprover.Text = String.Join(", ", checkedList);
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region ShowSelectedCustodian
    protected void ddlCustodian_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            List<String> checkedList = new List<string>();
            foreach (ListItem item in ddlCustodian.Items)
            {
                if (item.Selected)
                {
                    checkedList.Add(item.Text);

                    lblSelectedCustodian.Text = String.Join(", ", checkedList);
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region SentForApproval
    protected void btnSentForApproval_Click(object sender, EventArgs e)
    {
        int success = 0;
        try
        {
            success = obj.SentSegregationForApproval(Session["EmpCode"].ToString(), Session["DeptCode"].ToString(), hndApprovedBy.Value,"Pending");
            if(success > 0)
            {
                // Prepare email details
                string subject = "Segregation of Duties";
                string body = "You have received a Segregation of Duties Request. Kindly review it and take appropriate action.";
                string baseUrl = Url + "SpocRequest/ViewSegregationOfDuties.aspx";
                // Send user email
                //SendEmail(Session["EmpEmail"].ToString(), Session["EmployeeName"].ToString(),
                //          ds.Tables[0].Rows[0]["EMPLOYEE_NAME"].ToString(),
                //          ds.Tables[0].Rows[0]["Email_Id"].ToString(),
                //          subject, body, txtAdditionalComment.Text.Trim(), userEmailUrl);
                ScriptManager.RegisterStartupScript(this, this.GetType(),
                        "showToastAndRedirect",
                        "showToastAndRedirect('success', 'The approval request for Segregation of Duties has been successfully sent.', 'Success', 'ViewSegregationOfDuties.aspx', '1000');",
                        true);
            }
            else
            {

            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    /// <summary>
    /// Sends an email using the provided parameters.
    /// </summary>
    private void SendEmail(string senderEmail, string senderName, string recipientName, string recipientEmail, string subject, string body, string additionalComments, string url)
    {
        if (!string.IsNullOrWhiteSpace(senderEmail) && !string.IsNullOrWhiteSpace(recipientEmail))
        {
            objm.SendMail(senderEmail, senderName, recipientEmail, recipientName, subject, body, HttpUtility.HtmlEncode(additionalComments), url);
        }
    }
}