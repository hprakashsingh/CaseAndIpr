﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net.NetworkInformation;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class SpocRequest_AddUpdateProcess : System.Web.UI.Page
{
    #region Variabledeclare
    SegregationForm obj = new SegregationForm();
    #endregion
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["EmpCode"] != null)
            {
                GetProcessList();
            }
        }
    }
    #region GetProcessList
    private void GetProcessList()
    {
        try
        {
            DataSet ds = obj.GetProcessList(Session["EmpCode"].ToString());
            if (ds.Tables[0].Rows.Count > 0)
            {
                GrdProcess.DataSource = ds.Tables[0];
                GrdProcess.DataBind();
            }
            else
            {
                GrdProcess.DataSource = ds.Tables[0];
                GrdProcess.DataBind();
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region Add/UpdateProcess
    protected void btnAddProcess_Click(object sender, EventArgs e)
    {
        int success = 0;
        try
        {
            success = obj.AddUpdateProcess(Session["EmpCode"].ToString(),hndProcessId.Value,HttpUtility.HtmlEncode(txtProcessName.Text.Trim()),ddlStatus.SelectedValue);
            if (success > 0)
            {
                GetProcessList();
                if (hndProcessId.Value.Equals(""))
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "showSuccessToast", "showToast('success', 'Process is successfully added.', 'Success');", true);
                }
                else if (hndProcessId.Value != "")
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "showSuccessToast", "showToast('success', 'Process is successfully updated.', 'Success');", true);
                }
                ClearFormData();
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "showErrorToast", "showToast('error', 'Process is not added. Please try again later.', 'Error');", true);
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region ClearFormData
    private void ClearFormData()
    {
        try
        {
            hndProcessId.Value = "";
            txtProcessName.Text = "";
            ddlStatus.SelectedValue = "";
            btnAddProcess.Text = "Add Process";
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region EditProcess
    protected void GrdProcess_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            if (e.CommandName.Equals("EditProcess"))
            {
                hndProcessId.Value = e.CommandArgument.ToString();
                DataSet ds = obj.GetProcessList(Session["EmpCode"].ToString(), hndProcessId.Value);
                if (ds.Tables[1].Rows.Count > 0)
                {
                    txtProcessName.Text = HttpUtility.HtmlDecode(ds.Tables[1].Rows[0]["Process"].ToString());
                    ddlStatus.SelectedValue = HttpUtility.HtmlDecode(ds.Tables[1].Rows[0]["Status"].ToString());
                    btnAddProcess.Text = "Update Process";
                    btnAddProcess.Focus();
                }
            }
        }
        catch(Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region ResetPageData
    protected void btnReset_Click(object sender, EventArgs e)
    {
        try
        {
            ClearFormData();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
}