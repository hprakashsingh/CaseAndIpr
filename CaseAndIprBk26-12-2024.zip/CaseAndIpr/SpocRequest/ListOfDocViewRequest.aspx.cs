﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class PolicyRequest_ListOfDocViewRequest : System.Web.UI.Page
{
    #region VariableDeclare
    PolicyMaker obj = new PolicyMaker();
    #endregion
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (!string.IsNullOrEmpty(Request.QueryString["ReqId"]))
            {
                hndReqtId.Value = CommonUtility.Decryption(HttpUtility.UrlDecode(Request.QueryString["ReqId"].ToString()));
                GetListOfDocViewRequest(hndReqtId.Value);
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "alert('Dear User, You do not have permission to access directly this page.');window.location ='Dashboard.aspx';", true);
            }
        }
    }
    #region GetListOfDocViewRequest
    public void GetListOfDocViewRequest(string documentType)
    {
        try
        {
            if (Session["EmpCode"] != null)
            {
                string empCode = Session["EmpCode"].ToString();
                DataSet ds = obj.GetListOfDocViewRequest(empCode, documentType);

                if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    GrdListOfDocViewRequest.DataSource = ds.Tables[0];
                    GrdListOfDocViewRequest.DataBind();
                }
                else
                {
                    GrdListOfDocViewRequest.DataSource = null;
                    GrdListOfDocViewRequest.DataBind();
                }
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "Javascript", "javascript:SweetDynamicWrongRedirect('Oops...','Dear user your session has been expired.Please try again later.','Dashboard.aspx'); ", true);
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
}