﻿using DocumentFormat.OpenXml.Wordprocessing;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Security.Policy;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml.Linq;

public partial class SpocRequest_ViewMobileNumberContinuation : System.Web.UI.Page
{
    #region DeclareVariable
    ExternalMailRegister obj = new ExternalMailRegister();
    MailUtility objm = new MailUtility();
    string Url = "https://webportal.dsgroup.com/ExternalMailRegister/";
    #endregion
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["EmpCode"] != null)
            {
                if (Request.QueryString["ReqId"] != null)
                {
                    hndReqId.Value = CommonUtility.Decryption(HttpUtility.UrlDecode(Request.QueryString["ReqId"].ToString()));
                    GetMobileRequest();
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "showToastAndRedirect", "showToastAndRedirect('error', 'Dear User, You do not have permission to access directly this page.', 'User Authentication', 'ListOfMobileNumberContinuation.aspx','1000');", true);
                }
            }
        }
    }
    #region GetMobileRequest
    public void GetMobileRequest()
    {
        try
        {
            DataSet ds = obj.GetMobileRequest(Session["EmpCode"].ToString(),hndReqId.Value);
            if (ds.Tables[0].Rows.Count > 0)
            {
                txtNameOfRequestor.Text = ds.Tables[0].Rows[0]["Employee_Name"].ToString();
                txtEmployeeNo.Text = ds.Tables[0].Rows[0]["Emp_Code"].ToString();
                txtDepartment.Text = ds.Tables[0].Rows[0]["Department"].ToString();
                txtPhExtNo.Text = ds.Tables[0].Rows[0]["ExtPhone"].ToString() == "" ? "-" : ds.Tables[0].Rows[0]["ExtPhone"].ToString();
                txtEmployeeloginId.Text = ds.Tables[0].Rows[0]["Email_Id"].ToString();
                lblDesignation.Text = ds.Tables[0].Rows[0]["Desig_NM"].ToString();
                lblCadreBand.Text = ds.Tables[0].Rows[0]["CD_CODE"].ToString();
                lblLocation.Text = ds.Tables[0].Rows[0]["LOC_DESC"].ToString();
                lblMobileNo.Text = ds.Tables[0].Rows[0]["MOBILE_NO"].ToString();
                lblDocumentNo.Text = ds.Tables[0].Rows[0]["DOCUMENT_NO"].ToString();
                txtDate.Text = ds.Tables[0].Rows[0]["CREATED_ON"].ToString();
                lblHodName.Text = ds.Tables[0].Rows[0]["Hod_Name"].ToString();
                lblHodActionDate.Text = ds.Tables[0].Rows[0]["HOD_APPROVAL_DATE"].ToString();
                lblHodStatus.Text = ds.Tables[0].Rows[0]["HOD_STATUS"].ToString();
                hndHodeCode.Value = ds.Tables[0].Rows[0]["HOD"].ToString();
                lblHodRemarks.Text = ds.Tables[0].Rows[0]["HOD_REMARKS"].ToString();
                lblAdministrationName.Text = ds.Tables[0].Rows[0]["Admin_Name"].ToString();
                lblAdministrationActionDate.Text = ds.Tables[0].Rows[0]["ADMINISTRATION_APPROVAL_DATE"].ToString();
                lblAdminStatus.Text = ds.Tables[0].Rows[0]["ADMINISTRATION_STATUS"].ToString();
                lblAdminRemarks.Text = ds.Tables[0].Rows[0]["ADMIN_REMARKS"].ToString();
                if(ds.Tables[0].Rows[0]["HOD_STATUS"].ToString().Equals("Approved"))
                {
                    hndActionUserType.Value = "Admin";
                }
                else
                {
                    hndActionUserType.Value = "Hod";
                }
                //if (Session["EmpCode"].ToString().Equals(ds.Tables[0].Rows[0]["HOD"].ToString()) && ds.Tables[0].Rows[0]["HOD_STATUS"].ToString().Equals("Pending"))
                //{
                //    btnAction.Visible = true;
                //}
                // Ensure the session and dataset objects are not null
                if (Session["EmpCode"] != null && ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    string empCode = Session["EmpCode"].ToString();
                    DataRow row = ds.Tables[0].Rows[0];

                    string hodCode = row["HOD"].ToString();
                    string hodStatus = row["HOD_STATUS"].ToString();
                    string adminCode = row["ADMINISTRATION"].ToString();
                    string adminStatus = row["ADMINISTRATION_STATUS"].ToString();

                    bool isHodPending = empCode.Equals(hodCode) && hodStatus.Equals("Pending", StringComparison.OrdinalIgnoreCase);
                    bool isAdminPending = empCode.Equals(adminCode) && adminStatus.Equals("Pending", StringComparison.OrdinalIgnoreCase);

                    btnAction.Visible = isHodPending || isAdminPending;
                }

            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region OpenAlertBox
    protected void btnAction_Click(object sender, EventArgs e)
    {
        try
        {
            ActionNotificationBox.Show();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region ApprovedRequest
    protected void btnApprovedRequest_Click(object sender, EventArgs e)
    {
        try
        {
            int success = ApproveRejectRequest("Approved");

            if (success > 0)
            {
                DataSet ds = obj.GetMobileRequest(Session["EmpCode"].ToString(), hndReqId.Value);

                if (ds.Tables[0].Rows.Count > 0)
                {
                    // Prepare email details
                    string subject = string.Format("Personal Mobile Number Continuation Request Document No.: {0}", lblDocumentNo.Text);
                    string body = string.Format("Your request for Personal Mobile Number Continuation has been approved by {0}. Kindly check the same.", Session["EmployeeName"]);
                    string adminBody = "You have received a new Mobile Number Continuation Request. Kindly review it and take appropriate action.";

                    string baseUrl = Url + "SpocRequest/ViewDocViewRequest.aspx";
                    string userEmailUrl = string.Format("{0}?ReqId={1}&emp_code={2}",
                        baseUrl,
                        CommonUtility.Encryption(hndReqId.Value),
                        CommonUtility.Encryption(HttpUtility.UrlEncode(ds.Tables[0].Rows[0]["Email_Id"].ToString())));

                    string adminUrl = string.Format("{0}?ReqId={1}&emp_code={2}",
                        baseUrl,
                        CommonUtility.Encryption(hndReqId.Value),
                        CommonUtility.Encryption(HttpUtility.UrlEncode(ds.Tables[0].Rows[0]["ADMINISTRATION"].ToString())));

                    // Send user email
                    SendEmail(Session["EmpEmail"].ToString(), Session["EmployeeName"].ToString(),
                              ds.Tables[0].Rows[0]["EMPLOYEE_NAME"].ToString(),
                              ds.Tables[0].Rows[0]["Email_Id"].ToString(),
                              subject, body, txtAdditionalComment.Text.Trim(), userEmailUrl);

                    // Send admin email
                    SendEmail(Session["EmpEmail"].ToString(), Session["EmployeeName"].ToString(),
                              ds.Tables[0].Rows[0]["ADMIN_NAME"].ToString(),
                              ds.Tables[0].Rows[0]["ADMIN_EMAIL"].ToString(),
                              subject, adminBody, txtAdditionalComment.Text.Trim(), adminUrl);

                    // Show success toast and redirect
                    ScriptManager.RegisterStartupScript(this, this.GetType(),
                        "showToastAndRedirect",
                        "showToastAndRedirect('success', 'Personal Mobile Number Continuation request is successfully approved.', 'Success', 'ListOfMobileNumberContinuation.aspx', '1000');",
                        true);
                }
            }
            else
            {
                // Show error toast
                ScriptManager.RegisterStartupScript(this, this.GetType(),
                    "showErrorToast",
                    "showToast('error', 'Personal Mobile Number Continuation is not approved. Please try again later!', 'Error');",
                    true);
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region RejectRequest
    protected void btnRejectRequest_Click(object sender, EventArgs e)
    {
        try
        {
            int success = ApproveRejectRequest("Reject");

            if (success > 0)
            {
                DataSet ds = obj.GetMobileRequest(Session["EmpCode"].ToString(), hndReqId.Value);

                if (ds.Tables[0].Rows.Count > 0)
                {
                    // Prepare email details
                    string subject = string.Format("Personal Mobile Number Continuation Request Document No.: {0}", lblDocumentNo.Text);
                    string body = string.Format("Your request for Personal Mobile Number Continuation has been rejected by {0}. Kindly review the details.", Session["EmployeeName"]);
                    string url = string.Format("{0}SpocRequest/ViewDocViewRequest.aspx?ReqId={1}&emp_code={2}",
                        Url,
                        CommonUtility.Encryption(hndReqId.Value),
                        CommonUtility.Encryption(HttpUtility.UrlEncode(ds.Tables[0].Rows[0]["Email_Id"].ToString())));

                    // Send rejection email
                    SendEmail(Session["EmpEmail"].ToString(), Session["EmployeeName"].ToString(),
                              ds.Tables[0].Rows[0]["EMPLOYEE_NAME"].ToString(),
                              ds.Tables[0].Rows[0]["Email_Id"].ToString(),
                              subject, body, txtAdditionalComment.Text.Trim(), url);
                }

                // Show success toast and redirect
                ScriptManager.RegisterStartupScript(this, this.GetType(),
                    "showToastAndRedirect",
                    "showToastAndRedirect('success', 'Personal Mobile Number Continuation request is successfully rejected.', 'Success', 'ListOfMobileNumberContinuation.aspx', '1000');",
                    true);
            }
            else
            {
                // Show error toast
                ScriptManager.RegisterStartupScript(this, this.GetType(),
                    "showErrorToast",
                    "showToast('error', 'Personal Mobile Number Continuation is not rejected. Please try again later!', 'Error');",
                    true);
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region SendEmail
    private void SendEmail(string senderEmail, string senderName, string recipientName, string recipientEmail, string subject, string body, string additionalComments, string url)
    {
        if (!string.IsNullOrWhiteSpace(senderEmail) && !string.IsNullOrWhiteSpace(recipientEmail))
        {
            objm.SendMail(senderEmail, senderName, recipientEmail, recipientName,  subject, body, HttpUtility.HtmlEncode(additionalComments), url);
        }
    }
    #endregion
    #region ApproveRejectRequest
    public int ApproveRejectRequest(string Status)
    {
        int success = 0;
        try
        {
            success = obj.ApproveRejectRequest(Session["EmpCode"].ToString(), hndReqId.Value, HttpUtility.HtmlEncode(txtAdditionalComment.Text.Trim()), Status, hndActionUserType.Value);
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return success;
    }
    #endregion
}