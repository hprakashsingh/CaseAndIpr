﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Configuration;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Web.UI;

public partial class ELogBook_ShopifyOrder : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    //#region PushShopifySalesOrder
    //protected void btnUploadShopifyOrder_Click(object sender, EventArgs e)
    //{
    //    try
    //    {
    //        if (!fuShopifyOrder.HasFile)
    //        {
    //            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Please select file.')", true);
    //            return;
    //        }

    //        string fileName = Path.GetFileName(fuShopifyOrder.PostedFile.FileName);
    //        string fileExtension = Path.GetExtension(fileName).ToLower();

    //        if (!(fileExtension.Equals(".xlsx") || fileExtension.Equals(".xls")))
    //        {
    //            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Please Select Excel file (.xls or .xlsx) only.')", true);
    //            return;
    //        }

    //        string tempFilePath = Path.Combine(Server.MapPath("~/WriteReadData"), fileName);
    //        fuShopifyOrder.SaveAs(tempFilePath);

    //        string conString = string.Empty;
    //        switch (fileExtension)
    //        {
    //            case ".xls":
    //                conString = ConfigurationManager.ConnectionStrings["Excel03ConString"].ConnectionString;
    //                break;
    //            case ".xlsx":
    //                conString = ConfigurationManager.ConnectionStrings["Excel07+ConString"].ConnectionString;
    //                break;
    //        }

    //        conString = string.Format(conString, tempFilePath);

    //        using (OleDbConnection excelCon = new OleDbConnection(conString))
    //        {
    //            excelCon.Open();
    //            string sheet1 = excelCon.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null).Rows[0]["TABLE_NAME"].ToString();
    //            DataTable dtExcelData = new DataTable();

    //            dtExcelData.Columns.AddRange(new DataColumn[37] {
    //            new DataColumn("ASO_RECID", typeof(string)),
    //            new DataColumn("ORDERID", typeof(string)),
    //            new DataColumn("ORDERDATE", typeof(string)),
    //            new DataColumn("CUSTOMERID", typeof(string)),
    //            new DataColumn("PRODUCTID", typeof(string)),
    //            new DataColumn("STATUS", typeof(string)),
    //            new DataColumn("QUANTITY", typeof(string)),
    //            new DataColumn("PRICE", typeof(string)),
    //            new DataColumn("COD", typeof(string)),
    //            new DataColumn("COMPANY", typeof(string)),
    //            new DataColumn("INVOICE_TYPE", typeof(string)),
    //            new DataColumn("INVOICE_SERIES", typeof(string)),
    //            new DataColumn("INVOICE_NO", typeof(string)),
    //            new DataColumn("CREATED_ON", typeof(string)),
    //            new DataColumn("SHIPPING_CHARGES", typeof(string)),
    //            new DataColumn("COURIER_FAG", typeof(string)),
    //            new DataColumn("ATTR_CHR10", typeof(string)),
    //            new DataColumn("ATTR_CHR20", typeof(string)),
    //            new DataColumn("ATTR_CHR50", typeof(string)),
    //            new DataColumn("ATTR_DATE", typeof(string)),
    //            new DataColumn("ATTR_DATE1", typeof(string)),
    //            new DataColumn("ATTR_NMB", typeof(string)),
    //            new DataColumn("ATTR_NMB1", typeof(string)),
    //            new DataColumn("POSNR", typeof(string)),
    //            new DataColumn("SAP_UM", typeof(string)),
    //            new DataColumn("PLANT", typeof(string)),
    //            new DataColumn("SAP_INVOICE_NO", typeof(string)),
    //            new DataColumn("INVOICE_DATE", typeof(string)),
    //            new DataColumn("INVOICE_VALUE", typeof(string)),
    //            new DataColumn("DEPOT_CITY", typeof(string)),
    //            new DataColumn("DEPOT_ADDRESS", typeof(string)),
    //            new DataColumn("SYSN_FLAG", typeof(string)),
    //            new DataColumn("AWB", typeof(string)),
    //            new DataColumn("COURIER_PARTNER_NAME", typeof(string)),
    //            new DataColumn("SELLING_PRICE", typeof(string)),
    //            new DataColumn("COUPON", typeof(string)),
    //            new DataColumn("DISCOUNTAMOUNT", typeof(string))
    //            });

    //            using (OleDbDataAdapter oda = new OleDbDataAdapter(@"SELECT ASO_RECID, ORDERID,ORDERDATE,CUSTOMERID,PRODUCTID,STATUS,QUANTITY,PRICE,COD,COMPANY,
    //                    INVOICE_TYPE,INVOICE_SERIES,INVOICE_NO,CREATED_ON,SHIPPING_CHARGES,COURIER_FAG,ATTR_CHR10,ATTR_CHR20,ATTR_CHR50,ATTR_DATE,ATTR_DATE1,
    //                    ATTR_NMB,ATTR_NMB1,POSNR,SAP_UM,PLANT,SAP_INVOICE_NO,INVOICE_DATE,INVOICE_VALUE,DEPOT_CITY,DEPOT_ADDRESS,SYSN_FLAG,AWB,COURIER_PARTNER_NAME,
    //                    SELLING_PRICE,COUPON,DISCOUNTAMOUNT FROM [" + sheet1 + "]", excelCon))
    //            {
    //                oda.Fill(dtExcelData);
    //            }

    //            string consString = ConfigurationManager.ConnectionStrings["ShopifyCon"].ConnectionString;

    //            using (OracleConnection con = new OracleConnection(consString))
    //            {
    //                con.Open();

    //                using (OracleTransaction transaction = con.BeginTransaction())
    //                {
    //                    try
    //                    {
    //                        string DeleteCommandText = "DELETE FROM SHOPIFY_SALE_ORDERS";
    //                        using (OracleCommand DeleteTableCmd = new OracleCommand(DeleteCommandText, con))
    //                        {
    //                            DeleteTableCmd.ExecuteNonQuery();
    //                        }

    //                        string insertCommandText = @"
    //                        INSERT INTO SHOPIFY_SALE_ORDERS (SSO_RECID, ORDERID, ORDERDATE, CUSTOMERID, PRODUCTID, STATUS, QUANTITY, PRICE, COD, COMPANY, 
    //                            INVOICE_TYPE, INVOICE_SERIES, INVOICE_NO, CREATED_ON, SHIPPING_CHARGES, COURIER_FAG, ATTR_CHR10, ATTR_CHR20, ATTR_CHR50, 
    //                            ATTR_DATE, ATTR_DATE1, ATTR_NMB, ATTR_NMB1, SYSN_FLAG, AWB, COURIER_PARTNER_NAME, SELLING_PRICE, COUPON, DISCOUNTAMOUNT)
    //                        VALUES (:SSO_RECID, :ORDERID, :ORDERDATE, :CUSTOMERID, :PRODUCTID, :STATUS, :QUANTITY, :PRICE, :COD, :COMPANY, 
    //                            :INVOICE_TYPE, :INVOICE_SERIES, :INVOICE_NO, :CREATED_ON, :SHIPPING_CHARGES, :COURIER_FAG, :ATTR_CHR10, :ATTR_CHR20, :ATTR_CHR50, 
    //                            :ATTR_DATE, :ATTR_DATE1, :ATTR_NMB, :ATTR_NMB1, :SYSN_FLAG, :AWB, :COURIER_PARTNER_NAME, :SELLING_PRICE, :COUPON, :DISCOUNTAMOUNT)";

    //                        using (OracleCommand insertCmd = new OracleCommand(insertCommandText, con))
    //                        {
    //                            insertCmd.Transaction = transaction;

    //                            // Bind parameters
    //                            insertCmd.Parameters.Add(new OracleParameter("SSO_RECID", OracleDbType.Varchar2, ParameterDirection.Input));
    //                            insertCmd.Parameters.Add(new OracleParameter("ORDERID", OracleDbType.Varchar2, ParameterDirection.Input));
    //                            insertCmd.Parameters.Add(new OracleParameter("ORDERDATE", OracleDbType.Varchar2, ParameterDirection.Input));
    //                            insertCmd.Parameters.Add(new OracleParameter("CUSTOMERID", OracleDbType.Varchar2, ParameterDirection.Input));
    //                            insertCmd.Parameters.Add(new OracleParameter("PRODUCTID", OracleDbType.Varchar2, ParameterDirection.Input));
    //                            insertCmd.Parameters.Add(new OracleParameter("STATUS", OracleDbType.Varchar2, ParameterDirection.Input));
    //                            insertCmd.Parameters.Add(new OracleParameter("QUANTITY", OracleDbType.Varchar2, ParameterDirection.Input));
    //                            insertCmd.Parameters.Add(new OracleParameter("PRICE", OracleDbType.Varchar2, ParameterDirection.Input));
    //                            insertCmd.Parameters.Add(new OracleParameter("COD", OracleDbType.Varchar2, ParameterDirection.Input));
    //                            insertCmd.Parameters.Add(new OracleParameter("COMPANY", OracleDbType.Varchar2, ParameterDirection.Input));
    //                            insertCmd.Parameters.Add(new OracleParameter("INVOICE_TYPE", OracleDbType.Varchar2, ParameterDirection.Input));
    //                            insertCmd.Parameters.Add(new OracleParameter("INVOICE_SERIES", OracleDbType.Varchar2, ParameterDirection.Input));
    //                            insertCmd.Parameters.Add(new OracleParameter("INVOICE_NO", OracleDbType.Varchar2, ParameterDirection.Input));
    //                            insertCmd.Parameters.Add(new OracleParameter("CREATED_ON", OracleDbType.Date, ParameterDirection.Input));
    //                            insertCmd.Parameters.Add(new OracleParameter("SHIPPING_CHARGES", OracleDbType.Varchar2, ParameterDirection.Input));
    //                            insertCmd.Parameters.Add(new OracleParameter("COURIER_FAG", OracleDbType.Varchar2, ParameterDirection.Input));
    //                            insertCmd.Parameters.Add(new OracleParameter("ATTR_CHR10", OracleDbType.Varchar2, ParameterDirection.Input));
    //                            insertCmd.Parameters.Add(new OracleParameter("ATTR_CHR20", OracleDbType.Varchar2, ParameterDirection.Input));
    //                            insertCmd.Parameters.Add(new OracleParameter("ATTR_CHR50", OracleDbType.Varchar2, ParameterDirection.Input));
    //                            insertCmd.Parameters.Add(new OracleParameter("ATTR_DATE", OracleDbType.Varchar2, ParameterDirection.Input));
    //                            insertCmd.Parameters.Add(new OracleParameter("ATTR_DATE1", OracleDbType.Varchar2, ParameterDirection.Input));
    //                            insertCmd.Parameters.Add(new OracleParameter("ATTR_NMB", OracleDbType.Varchar2, ParameterDirection.Input));
    //                            insertCmd.Parameters.Add(new OracleParameter("ATTR_NMB1", OracleDbType.Varchar2, ParameterDirection.Input));
    //                            insertCmd.Parameters.Add(new OracleParameter("SYSN_FLAG", OracleDbType.Varchar2, ParameterDirection.Input));
    //                            insertCmd.Parameters.Add(new OracleParameter("AWB", OracleDbType.Varchar2, ParameterDirection.Input));
    //                            insertCmd.Parameters.Add(new OracleParameter("COURIER_PARTNER_NAME", OracleDbType.Varchar2, ParameterDirection.Input));
    //                            insertCmd.Parameters.Add(new OracleParameter("SELLING_PRICE", OracleDbType.Varchar2, ParameterDirection.Input));
    //                            insertCmd.Parameters.Add(new OracleParameter("COUPON", OracleDbType.Varchar2, ParameterDirection.Input));
    //                            insertCmd.Parameters.Add(new OracleParameter("DISCOUNTAMOUNT", OracleDbType.Varchar2, ParameterDirection.Input));


    //                            // Set the value from DataTable
    //                            foreach (DataRow row in dtExcelData.Rows)
    //                            {
    //                                insertCmd.Parameters["SSO_RECID"].Value = row["ASO_RECID"].ToString();
    //                                insertCmd.Parameters["ORDERID"].Value = row["ORDERID"].ToString();
    //                                insertCmd.Parameters["ORDERDATE"].Value = row["ORDERDATE"].ToString();
    //                                insertCmd.Parameters["CUSTOMERID"].Value = row["CUSTOMERID"].ToString();
    //                                insertCmd.Parameters["PRODUCTID"].Value = row["PRODUCTID"].ToString();
    //                                insertCmd.Parameters["STATUS"].Value = row["STATUS"].ToString();
    //                                insertCmd.Parameters["QUANTITY"].Value = row["QUANTITY"].ToString();
    //                                insertCmd.Parameters["PRICE"].Value = row["PRICE"].ToString();
    //                                insertCmd.Parameters["COD"].Value = row["COD"].ToString();
    //                                insertCmd.Parameters["COMPANY"].Value = row["COMPANY"].ToString();
    //                                insertCmd.Parameters["INVOICE_TYPE"].Value = row["INVOICE_TYPE"].ToString();
    //                                insertCmd.Parameters["INVOICE_SERIES"].Value = row["INVOICE_SERIES"].ToString();
    //                                insertCmd.Parameters["INVOICE_NO"].Value = row["INVOICE_NO"].ToString();
    //                                insertCmd.Parameters["CREATED_ON"].Value = DateTime.Now;
    //                                insertCmd.Parameters["SHIPPING_CHARGES"].Value = row["SHIPPING_CHARGES"].ToString();
    //                                insertCmd.Parameters["COURIER_FAG"].Value = row["COURIER_FAG"].ToString();
    //                                insertCmd.Parameters["ATTR_CHR10"].Value = row["ATTR_CHR10"].ToString();
    //                                insertCmd.Parameters["ATTR_CHR20"].Value = row["ATTR_CHR20"].ToString();
    //                                insertCmd.Parameters["ATTR_CHR50"].Value = row["ATTR_CHR50"].ToString();
    //                                insertCmd.Parameters["ATTR_DATE"].Value = row["ATTR_DATE"].ToString();
    //                                insertCmd.Parameters["ATTR_DATE1"].Value = row["ATTR_DATE1"].ToString();
    //                                insertCmd.Parameters["ATTR_NMB"].Value = row["ATTR_NMB"].ToString();
    //                                insertCmd.Parameters["ATTR_NMB1"].Value = row["ATTR_NMB1"].ToString();
    //                                insertCmd.Parameters["SYSN_FLAG"].Value = row["SYSN_FLAG"].ToString();
    //                                insertCmd.Parameters["AWB"].Value = row["AWB"].ToString();
    //                                insertCmd.Parameters["COURIER_PARTNER_NAME"].Value = row["COURIER_PARTNER_NAME"].ToString();
    //                                insertCmd.Parameters["SELLING_PRICE"].Value = row["SELLING_PRICE"].ToString();
    //                                insertCmd.Parameters["COUPON"].Value = row["COUPON"].ToString();
    //                                insertCmd.Parameters["DISCOUNTAMOUNT"].Value = row["DISCOUNTAMOUNT"].ToString();

    //                                insertCmd.ExecuteNonQuery();
    //                            }

    //                            transaction.Commit();
    //                        }
    //                    }
    //                    catch
    //                    {
    //                        transaction.Rollback();
    //                        throw;
    //                    }
    //                }
    //            }
    //        }

    //        if (File.Exists(tempFilePath))
    //        {
    //            File.Delete(tempFilePath);
    //        }

    //        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Shopify Sales Order inserted successfully.')", true);
    //    }
    //    catch (Exception ex)
    //    {
    //        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('An error occurred: " + ex.Message + "')", true);
    //    }
    //}
    //#endregion
    //#region PushShopifyCustomer
    //protected void btnUploadShopifyCustomer_Click(object sender, EventArgs e)
    //{
    //    string tempFilePath = string.Empty;
    //    try
    //    {
    //        if (!fuShopifyOrder.HasFile)
    //        {
    //            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Please select file.')", true);
    //            return;
    //        }

    //        string fileName = Path.GetFileName(fuShopifyOrder.PostedFile.FileName);
    //        string fileExtension = Path.GetExtension(fileName).ToLower();

    //        if (!(fileExtension.Equals(".xlsx") || fileExtension.Equals(".xls")))
    //        {
    //            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Please Select Excel file (.xls or .xlsx) only.')", true);
    //            return;
    //        }

    //        tempFilePath = Path.Combine(Server.MapPath("~/WriteReadData"), fileName);
    //        fuShopifyOrder.SaveAs(tempFilePath);

    //        string conString = string.Empty;
    //        switch (fileExtension)
    //        {
    //            case ".xls":
    //                conString = ConfigurationManager.ConnectionStrings["Excel03ConString"].ConnectionString;
    //                break;
    //            case ".xlsx":
    //                conString = ConfigurationManager.ConnectionStrings["Excel07+ConString"].ConnectionString;
    //                break;
    //        }

    //        conString = string.Format(conString, tempFilePath);

    //        using (OleDbConnection excelCon = new OleDbConnection(conString))
    //        {
    //            excelCon.Open();
    //            string sheet1 = excelCon.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null).Rows[0]["TABLE_NAME"].ToString();
    //            DataTable dtExcelData = new DataTable();

    //                dtExcelData.Columns.AddRange(new DataColumn[50] {
    //                new DataColumn("AC_RECID", typeof(string)),
    //                new DataColumn("MEMBER_ID", typeof(string)),
    //                new DataColumn("ORDERID", typeof(string)),
    //                new DataColumn("BILL_CUSTOMERNAME", typeof(string)),
    //                new DataColumn("STATUS", typeof(string)),
    //                new DataColumn("BILL_ADDRESS", typeof(string)),
    //                new DataColumn("BILL_LANDMARK", typeof(string)),
    //                new DataColumn("BILL_CITY", typeof(string)),
    //                new DataColumn("BILL_STATE", typeof(string)),
    //                new DataColumn("BILL_COUNTRY", typeof(string)),
    //                new DataColumn("BILL_PINCODE", typeof(string)),
    //                new DataColumn("BILL_PHONENUMBER", typeof(string)),
    //                new DataColumn("BILL_ALTERNATENUMBER", typeof(string)),
    //                new DataColumn("BILL_EMAILID", typeof(string)),
    //                new DataColumn("SHIP_CUSTOMERNAME", typeof(string)),
    //                new DataColumn("SHIP_ADDRESS", typeof(string)),
    //                new DataColumn("SHIP_LANDMARK", typeof(string)),
    //                new DataColumn("SHIP_CITY", typeof(string)),
    //                new DataColumn("SHIP_STATE", typeof(string)),
    //                new DataColumn("SHIP_COUNTRY", typeof(string)),
    //                new DataColumn("SHIP_PINCODE", typeof(string)),
    //                new DataColumn("SHIP_PHONENUMBER", typeof(string)),
    //                new DataColumn("SHIP_ALTERNATENUMBER", typeof(string)),
    //                new DataColumn("SHIP_EMAILID", typeof(string)),
    //                new DataColumn("CREATED_ON", typeof(string)),
    //                new DataColumn("PAYMENT_ID", typeof(string)),
    //                new DataColumn("PAYMENT_METHOD", typeof(string)),
    //                new DataColumn("PAYMENT_AMOUNT", typeof(string)),
    //                new DataColumn("CURRENCY", typeof(string)),
    //                new DataColumn("PAYMENT_EMAIL", typeof(string)),
    //                new DataColumn("PAYMENT_CONTACT_NO", typeof(string)),
    //                new DataColumn("CREATED_AT", typeof(string)),
    //                new DataColumn("AWB", typeof(string)),
    //                new DataColumn("QR_CODE", typeof(string)),
    //                new DataColumn("BILL_STATE_CODE", typeof(string)),
    //                new DataColumn("SHIP_STATE_CODE", typeof(string)),
    //                new DataColumn("COURIER_PARTNER_NAME", typeof(string)),
    //                new DataColumn("SAP_CUSTOMER_ID", typeof(string)),
    //                new DataColumn("TOTAL_AMOUNT", typeof(string)),
    //                new DataColumn("ERROR_MESSAGE", typeof(string)),
    //                new DataColumn("TRANSACTION_ID_POINTS", typeof(string)),
    //                new DataColumn("AMOUNT_PAID_AT_PG", typeof(string)),
    //                new DataColumn("POINTS_FOR_ORDER", typeof(string)),
    //                new DataColumn("TAG_1", typeof(string)),
    //                new DataColumn("TAG_2", typeof(string)),
    //                new DataColumn("TAG_3", typeof(string)),
    //                new DataColumn("TAG_4", typeof(string)),
    //                new DataColumn("TAG_5", typeof(string)),
    //                new DataColumn("POINT_CONVERSION_VALUE", typeof(string)),
    //                new DataColumn("TOTAL_REDEMPTION_VALUE", typeof(string))
    //                });

    //            using (OleDbDataAdapter oda = new OleDbDataAdapter(@"SELECT AC_RECID, MEMBER_ID, ORDERID, BILL_CUSTOMERNAME, STATUS, BILL_ADDRESS, BILL_LANDMARK, BILL_CITY,	
    //                                BILL_STATE, BILL_COUNTRY, BILL_PINCODE, BILL_PHONENUMBER, BILL_ALTERNATENUMBER, BILL_EMAILID, SHIP_CUSTOMERNAME, SHIP_ADDRESS,	
    //                                SHIP_LANDMARK, SHIP_CITY, SHIP_STATE, SHIP_COUNTRY, SHIP_PINCODE, SHIP_PHONENUMBER, SHIP_ALTERNATENUMBER, SHIP_EMAILID,	
    //                                CREATED_ON,	PAYMENT_ID,	PAYMENT_METHOD,	PAYMENT_AMOUNT,	CURRENCY, PAYMENT_EMAIL, PAYMENT_CONTACT_NO, CREATED_AT,	AWB,
    //                                QR_CODE, BILL_STATE_CODE, SHIP_STATE_CODE, COURIER_PARTNER_NAME, SAP_CUSTOMER_ID, TOTAL_AMOUNT, ERROR_MESSAGE,	
    //                                TRANSACTION_ID_POINTS, AMOUNT_PAID_AT_PG, POINTS_FOR_ORDER, TAG_1, TAG_2, TAG_3, TAG_4,	TAG_5, POINT_CONVERSION_VALUE,	
    //                                TOTAL_REDEMPTION_VALUE FROM [" + sheet1 + "]", excelCon))
    //            {
    //                oda.Fill(dtExcelData);
    //            }

    //            string consString = ConfigurationManager.ConnectionStrings["ShopifyCon"].ConnectionString;

    //            using (OracleConnection con = new OracleConnection(consString))
    //            {
    //                con.Open();

    //                using (OracleTransaction transaction = con.BeginTransaction())
    //                {
    //                    try
    //                    {
    //                        string DeleteCommandText = "DELETE FROM SHOPIFY_CUSTOMERS";
    //                        using (OracleCommand DeleteTableCmd = new OracleCommand(DeleteCommandText, con))
    //                        {
    //                            DeleteTableCmd.ExecuteNonQuery();
    //                        }

    //                        string insertCommandText = @"INSERT INTO SHOPIFY_CUSTOMERS
    //                                (SC_RECID, MEMBER_ID, ORDERID, BILL_CUSTOMERNAME, STATUS, BILL_ADDRESS, BILL_LANDMARK, BILL_CITY, BILL_STATE, BILL_COUNTRY, BILL_PINCODE,
    //                                BILL_PHONENUMBER, BILL_ALTERNATENUMBER, BILL_EMAILID, SHIP_CUSTOMERNAME, SHIP_ADDRESS, SHIP_LANDMARK, SHIP_CITY, SHIP_STATE, SHIP_COUNTRY,
    //                                SHIP_PINCODE, SHIP_PHONENUMBER, SHIP_ALTERNATENUMBER, SHIP_EMAILID, CREATED_ON, PAYMENT_ID, PAYMENT_METHOD, PAYMENT_AMOUNT, CURRENCY, 
    //                                PAYMENT_EMAIL, PAYMENT_CONTACT_NO, CREATED_AT, AWB, QR_CODE, BILL_STATE_CODE, SHIP_STATE_CODE, COURIER_PARTNER_NAME, SAP_CUSTOMER_ID, 
    //                                TOTAL_AMOUNT) 

    //                                VALUES (:AC_RECID, :MEMBER_ID, :ORDERID, :BILL_CUSTOMERNAME, :STATUS, :BILL_ADDRESS, :BILL_LANDMARK, :BILL_CITY, :BILL_STATE, :BILL_COUNTRY, 
    //                                :BILL_PINCODE, :BILL_PHONENUMBER, :BILL_ALTERNATENUMBER, :BILL_EMAILID, :SHIP_CUSTOMERNAME, :SHIP_ADDRESS, :SHIP_LANDMARK, :SHIP_CITY, 
    //                                :SHIP_STATE, :SHIP_COUNTRY, :SHIP_PINCODE, :SHIP_PHONENUMBER, :SHIP_ALTERNATENUMBER, :SHIP_EMAILID, :CREATED_ON, :PAYMENT_ID, 
    //                                :PAYMENT_METHOD, :PAYMENT_AMOUNT, :CURRENCY, :PAYMENT_EMAIL, :PAYMENT_CONTACT_NO, :CREATED_AT, :AWB, :QR_CODE, :BILL_STATE_CODE, 
    //                                :SHIP_STATE_CODE, :COURIER_PARTNER_NAME, :SAP_CUSTOMER_ID, :TOTAL_AMOUNT)";


    //                        using (OracleCommand insertCmd = new OracleCommand(insertCommandText, con))
    //                        {
    //                            insertCmd.Transaction = transaction;

    //                            // Bind parameters
    //                            insertCmd.Parameters.Add(new OracleParameter("AC_RECID", OracleDbType.Varchar2, ParameterDirection.Input));
    //                            insertCmd.Parameters.Add(new OracleParameter("MEMBER_ID", OracleDbType.Varchar2, ParameterDirection.Input));
    //                            insertCmd.Parameters.Add(new OracleParameter("ORDERID", OracleDbType.Varchar2, ParameterDirection.Input));
    //                            insertCmd.Parameters.Add(new OracleParameter("BILL_CUSTOMERNAME", OracleDbType.Varchar2, ParameterDirection.Input));
    //                            insertCmd.Parameters.Add(new OracleParameter("STATUS", OracleDbType.Varchar2, ParameterDirection.Input));
    //                            insertCmd.Parameters.Add(new OracleParameter("BILL_ADDRESS", OracleDbType.Varchar2, ParameterDirection.Input));
    //                            insertCmd.Parameters.Add(new OracleParameter("BILL_LANDMARK", OracleDbType.Varchar2, ParameterDirection.Input));
    //                            insertCmd.Parameters.Add(new OracleParameter("BILL_CITY", OracleDbType.Varchar2, ParameterDirection.Input));
    //                            insertCmd.Parameters.Add(new OracleParameter("BILL_STATE", OracleDbType.Varchar2, ParameterDirection.Input));
    //                            insertCmd.Parameters.Add(new OracleParameter("BILL_COUNTRY", OracleDbType.Varchar2, ParameterDirection.Input));
    //                            insertCmd.Parameters.Add(new OracleParameter("BILL_PINCODE", OracleDbType.Varchar2, ParameterDirection.Input));
    //                            insertCmd.Parameters.Add(new OracleParameter("BILL_PHONENUMBER", OracleDbType.Varchar2, ParameterDirection.Input));
    //                            insertCmd.Parameters.Add(new OracleParameter("BILL_ALTERNATENUMBER", OracleDbType.Varchar2, ParameterDirection.Input));
    //                            insertCmd.Parameters.Add(new OracleParameter("BILL_EMAILID", OracleDbType.Varchar2, ParameterDirection.Input));
    //                            insertCmd.Parameters.Add(new OracleParameter("SHIP_CUSTOMERNAME", OracleDbType.Varchar2, ParameterDirection.Input));
    //                            insertCmd.Parameters.Add(new OracleParameter("SHIP_ADDRESS", OracleDbType.Varchar2, ParameterDirection.Input));
    //                            insertCmd.Parameters.Add(new OracleParameter("SHIP_LANDMARK", OracleDbType.Varchar2, ParameterDirection.Input));
    //                            insertCmd.Parameters.Add(new OracleParameter("SHIP_CITY", OracleDbType.Varchar2, ParameterDirection.Input));
    //                            insertCmd.Parameters.Add(new OracleParameter("SHIP_STATE", OracleDbType.Varchar2, ParameterDirection.Input));
    //                            insertCmd.Parameters.Add(new OracleParameter("SHIP_COUNTRY", OracleDbType.Varchar2, ParameterDirection.Input));
    //                            insertCmd.Parameters.Add(new OracleParameter("SHIP_PINCODE", OracleDbType.Varchar2, ParameterDirection.Input));
    //                            insertCmd.Parameters.Add(new OracleParameter("SHIP_PHONENUMBER", OracleDbType.Varchar2, ParameterDirection.Input));
    //                            insertCmd.Parameters.Add(new OracleParameter("SHIP_ALTERNATENUMBER", OracleDbType.Varchar2, ParameterDirection.Input));
    //                            insertCmd.Parameters.Add(new OracleParameter("SHIP_EMAILID", OracleDbType.Varchar2, ParameterDirection.Input));
    //                            insertCmd.Parameters.Add(new OracleParameter("CREATED_ON", OracleDbType.Date, ParameterDirection.Input));
    //                            insertCmd.Parameters.Add(new OracleParameter("PAYMENT_ID", OracleDbType.Varchar2, ParameterDirection.Input));
    //                            insertCmd.Parameters.Add(new OracleParameter("PAYMENT_METHOD", OracleDbType.Varchar2, ParameterDirection.Input));
    //                            insertCmd.Parameters.Add(new OracleParameter("PAYMENT_AMOUNT", OracleDbType.Varchar2, ParameterDirection.Input));
    //                            insertCmd.Parameters.Add(new OracleParameter("CURRENCY", OracleDbType.Varchar2, ParameterDirection.Input));
    //                            insertCmd.Parameters.Add(new OracleParameter("PAYMENT_EMAIL", OracleDbType.Varchar2, ParameterDirection.Input));
    //                            insertCmd.Parameters.Add(new OracleParameter("PAYMENT_CONTACT_NO", OracleDbType.Varchar2, ParameterDirection.Input));
    //                            insertCmd.Parameters.Add(new OracleParameter("CREATED_AT", OracleDbType.Date, ParameterDirection.Input));
    //                            insertCmd.Parameters.Add(new OracleParameter("AWB", OracleDbType.Varchar2, ParameterDirection.Input));
    //                            insertCmd.Parameters.Add(new OracleParameter("QR_CODE", OracleDbType.Varchar2, ParameterDirection.Input));
    //                            insertCmd.Parameters.Add(new OracleParameter("BILL_STATE_CODE", OracleDbType.Varchar2, ParameterDirection.Input));
    //                            insertCmd.Parameters.Add(new OracleParameter("SHIP_STATE_CODE", OracleDbType.Varchar2, ParameterDirection.Input));
    //                            insertCmd.Parameters.Add(new OracleParameter("COURIER_PARTNER_NAME", OracleDbType.Varchar2, ParameterDirection.Input));
    //                            insertCmd.Parameters.Add(new OracleParameter("SAP_CUSTOMER_ID", OracleDbType.Varchar2, ParameterDirection.Input));
    //                            insertCmd.Parameters.Add(new OracleParameter("TOTAL_AMOUNT", OracleDbType.Varchar2, ParameterDirection.Input));

    //                            // Set the value from DataTable
    //                            foreach (DataRow row in dtExcelData.Rows)
    //                            {
    //                                insertCmd.Parameters["AC_RECID"].Value = row["AC_RECID"];
    //                                insertCmd.Parameters["MEMBER_ID"].Value = row["MEMBER_ID"];
    //                                insertCmd.Parameters["ORDERID"].Value = row["ORDERID"];
    //                                insertCmd.Parameters["BILL_CUSTOMERNAME"].Value = row["BILL_CUSTOMERNAME"];
    //                                insertCmd.Parameters["STATUS"].Value = row["STATUS"];
    //                                insertCmd.Parameters["BILL_ADDRESS"].Value = row["BILL_ADDRESS"];
    //                                insertCmd.Parameters["BILL_LANDMARK"].Value = row["BILL_LANDMARK"];
    //                                insertCmd.Parameters["BILL_CITY"].Value = row["BILL_CITY"];
    //                                insertCmd.Parameters["BILL_STATE"].Value = row["BILL_STATE"];
    //                                insertCmd.Parameters["BILL_COUNTRY"].Value = row["BILL_COUNTRY"];
    //                                insertCmd.Parameters["BILL_PINCODE"].Value = row["BILL_PINCODE"];
    //                                insertCmd.Parameters["BILL_PHONENUMBER"].Value = row["BILL_PHONENUMBER"];
    //                                insertCmd.Parameters["BILL_ALTERNATENUMBER"].Value = row["BILL_ALTERNATENUMBER"];
    //                                insertCmd.Parameters["BILL_EMAILID"].Value = row["BILL_EMAILID"];
    //                                insertCmd.Parameters["SHIP_CUSTOMERNAME"].Value = row["SHIP_CUSTOMERNAME"];
    //                                insertCmd.Parameters["SHIP_ADDRESS"].Value = row["SHIP_ADDRESS"];
    //                                insertCmd.Parameters["SHIP_LANDMARK"].Value = row["SHIP_LANDMARK"];
    //                                insertCmd.Parameters["SHIP_CITY"].Value = row["SHIP_CITY"];
    //                                insertCmd.Parameters["SHIP_STATE"].Value = row["SHIP_STATE"];
    //                                insertCmd.Parameters["SHIP_COUNTRY"].Value = row["SHIP_COUNTRY"];
    //                                insertCmd.Parameters["SHIP_PINCODE"].Value = row["SHIP_PINCODE"];
    //                                insertCmd.Parameters["SHIP_PHONENUMBER"].Value = row["SHIP_PHONENUMBER"];
    //                                insertCmd.Parameters["SHIP_ALTERNATENUMBER"].Value = row["SHIP_ALTERNATENUMBER"];
    //                                insertCmd.Parameters["SHIP_EMAILID"].Value = row["SHIP_EMAILID"];
    //                                insertCmd.Parameters["CREATED_ON"].Value = DateTime.Now;
    //                                insertCmd.Parameters["PAYMENT_ID"].Value = row["PAYMENT_ID"];
    //                                insertCmd.Parameters["PAYMENT_METHOD"].Value = row["PAYMENT_METHOD"];
    //                                insertCmd.Parameters["PAYMENT_AMOUNT"].Value = row["PAYMENT_AMOUNT"];
    //                                insertCmd.Parameters["CURRENCY"].Value = row["CURRENCY"];
    //                                insertCmd.Parameters["PAYMENT_EMAIL"].Value = row["PAYMENT_EMAIL"];
    //                                insertCmd.Parameters["PAYMENT_CONTACT_NO"].Value = row["PAYMENT_CONTACT_NO"];
    //                                insertCmd.Parameters["CREATED_AT"].Value = DateTime.Now;
    //                                insertCmd.Parameters["AWB"].Value = row["AWB"];
    //                                insertCmd.Parameters["QR_CODE"].Value = row["QR_CODE"];
    //                                insertCmd.Parameters["BILL_STATE_CODE"].Value = row["BILL_STATE_CODE"];
    //                                insertCmd.Parameters["SHIP_STATE_CODE"].Value = row["SHIP_STATE_CODE"];
    //                                insertCmd.Parameters["COURIER_PARTNER_NAME"].Value = row["COURIER_PARTNER_NAME"];
    //                                insertCmd.Parameters["SAP_CUSTOMER_ID"].Value = row["SAP_CUSTOMER_ID"];
    //                                insertCmd.Parameters["TOTAL_AMOUNT"].Value = row["TOTAL_AMOUNT"];

    //                                // Execute insert
    //                                insertCmd.ExecuteNonQuery();
    //                            }

    //                            transaction.Commit();
    //                        }
    //                    }
    //                    catch
    //                    {
    //                        transaction.Rollback();
    //                        throw;
    //                    }
    //                }
    //            }
    //        }

    //        if (File.Exists(tempFilePath))
    //        {
    //            File.Delete(tempFilePath);
    //        }

    //        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Shopify Customer details inserted successfully.')", true);
    //    }
    //    catch (Exception ex)
    //    {
    //        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('An error occurred: " + ex.Message + "')", true);
    //    }
    //    finally
    //    {
    //        if (!string.IsNullOrEmpty(tempFilePath) && File.Exists(tempFilePath))
    //        {
    //            File.Delete(tempFilePath);
    //        }
    //    }
    //}
    //#endregion
    #region PushShopifySalesOrder
    protected void btnUploadShopifyOrder_Click(object sender, EventArgs e)
    {
        try
        {
            if (!fuShopifyOrder.HasFile)
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Please select a file.')", true);
                return;
            }

            string fileName = Path.GetFileName(fuShopifyOrder.PostedFile.FileName);
            string fileExtension = Path.GetExtension(fileName).ToLower();

            if (!(fileExtension.Equals(".xlsx") || fileExtension.Equals(".xls")))
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Please select an Excel file (.xls or .xlsx) only.')", true);
                return;
            }

            string tempFilePath = Path.Combine(Server.MapPath("~/WriteReadData"), fileName);
            fuShopifyOrder.SaveAs(tempFilePath);

            string conString = string.Empty;
            switch (fileExtension)
            {
                case ".xls":
                    conString = ConfigurationManager.ConnectionStrings["Excel03ConString"].ConnectionString;
                    break;
                case ".xlsx":
                    conString = ConfigurationManager.ConnectionStrings["Excel07+ConString"].ConnectionString;
                    break;
            }

            conString = string.Format(conString, tempFilePath);

            using (OleDbConnection excelCon = new OleDbConnection(conString))
            {
                excelCon.Open();
                string sheet1 = excelCon.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null).Rows[0]["TABLE_NAME"].ToString();
                DataTable dtExcelData = new DataTable();

                using (OleDbDataAdapter oda = new OleDbDataAdapter("SELECT * FROM [" + sheet1 + "]", excelCon))
                {
                    oda.Fill(dtExcelData);
                }

                string consString = ConfigurationManager.ConnectionStrings["ShopifyCon"].ConnectionString;

                using (OracleConnection con = new OracleConnection(consString))
                {
                    con.Open();
                    using (OracleTransaction transaction = con.BeginTransaction())
                    {
                        try
                        {
                            string deleteCommandText = "DELETE FROM SHOPIFY_SALE_ORDERS";
                            using (OracleCommand deleteTableCmd = new OracleCommand(deleteCommandText, con))
                            {
                                deleteTableCmd.ExecuteNonQuery();
                            }

                            string insertCommandText = @"
                        INSERT INTO SHOPIFY_SALE_ORDERS 
                        (SSO_RECID, ORDERID, ORDERDATE, CUSTOMERID, PRODUCTID, STATUS, QUANTITY, PRICE, COD, SHIPPING_CHARGES, AWB, COURIER_PARTNER_NAME, CREATED_ON)
                        VALUES 
                        (SHOPIFY_SEQ.NEXTVAL, :ORDERID, :ORDERDATE, :CUSTOMERID, :PRODUCTID, :STATUS, :QUANTITY, :PRICE, :COD, :SHIPPING_CHARGES, :AWB, :COURIER_PARTNER_NAME, :CREATED_ON)";

                            using (OracleCommand insertCmd = new OracleCommand(insertCommandText, con))
                            {
                                insertCmd.Transaction = transaction;

                                // Bind parameters
                                insertCmd.Parameters.Add(new OracleParameter("ORDERID", OracleDbType.Varchar2));
                                insertCmd.Parameters.Add(new OracleParameter("ORDERDATE", OracleDbType.Date));
                                insertCmd.Parameters.Add(new OracleParameter("CUSTOMERID", OracleDbType.Varchar2));
                                insertCmd.Parameters.Add(new OracleParameter("PRODUCTID", OracleDbType.Varchar2));
                                insertCmd.Parameters.Add(new OracleParameter("STATUS", OracleDbType.Varchar2));
                                insertCmd.Parameters.Add(new OracleParameter("QUANTITY", OracleDbType.Int32));
                                insertCmd.Parameters.Add(new OracleParameter("PRICE", OracleDbType.Decimal));
                                insertCmd.Parameters.Add(new OracleParameter("COD", OracleDbType.Varchar2));
                                insertCmd.Parameters.Add(new OracleParameter("SHIPPING_CHARGES", OracleDbType.Decimal));
                                insertCmd.Parameters.Add(new OracleParameter("AWB", OracleDbType.Varchar2));
                                insertCmd.Parameters.Add(new OracleParameter("COURIER_PARTNER_NAME", OracleDbType.Varchar2));
                                insertCmd.Parameters.Add(new OracleParameter("CREATED_ON", OracleDbType.Date));

                                // Loop through DataTable and insert data
                                foreach (DataRow row in dtExcelData.Rows)
                                {
                                    insertCmd.Parameters["ORDERID"].Value = row[3].ToString();
                                    insertCmd.Parameters["ORDERDATE"].Value = DateTime.Parse(row[12].ToString());
                                    insertCmd.Parameters["CUSTOMERID"].Value = row[14].ToString();
                                    insertCmd.Parameters["PRODUCTID"].Value = row[35].ToString();
                                    insertCmd.Parameters["STATUS"].Value = "A"; // Default status
                                    insertCmd.Parameters["QUANTITY"].Value = Convert.ToInt32(row[36]);
                                    insertCmd.Parameters["PRICE"].Value = Convert.ToDecimal(row[38]);
                                    insertCmd.Parameters["COD"].Value = row[40].ToString();
                                    insertCmd.Parameters["SHIPPING_CHARGES"].Value = Convert.ToDecimal(row[39]);
                                    insertCmd.Parameters["AWB"].Value = row[9].ToString();
                                    insertCmd.Parameters["COURIER_PARTNER_NAME"].Value = row[10].ToString();
                                    insertCmd.Parameters["CREATED_ON"].Value = DateTime.Now;

                                    insertCmd.ExecuteNonQuery();
                                }

                                transaction.Commit();
                            }
                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();
                            // Log exception
                            throw new Exception("An error occurred during the database operation.", ex);
                        }
                    }
                }
            }

            // Clean up file
            if (File.Exists(tempFilePath))
            {
                File.Delete(tempFilePath);
            }

            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Shopify Sales Order inserted successfully.')", true);
        }
        catch (Exception ex)
        {
            // Log the exception (ex) instead of displaying it directly
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('An error occurred during the upload process. Please try again.')", true);
        }
    }
    #endregion
    #region PushShopifyCustomer
    protected void btnUploadShopifyCustomer_Click(object sender, EventArgs e)
    {
        try
        {
            if (!fuShopifyOrder.HasFile)
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Please select a file.')", true);
                return;
            }

            string fileName = Path.GetFileName(fuShopifyOrder.PostedFile.FileName);
            string fileExtension = Path.GetExtension(fileName).ToLower();

            if (!(fileExtension.Equals(".xlsx") || fileExtension.Equals(".xls")))
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Please select an Excel file (.xls or .xlsx) only.')", true);
                return;
            }

            string tempFilePath = Path.Combine(Server.MapPath("~/WriteReadData"), fileName);
            fuShopifyOrder.SaveAs(tempFilePath);

            string conString = string.Empty;
            switch (fileExtension)
            {
                case ".xls":
                    conString = ConfigurationManager.ConnectionStrings["Excel03ConString"].ConnectionString;
                    break;
                case ".xlsx":
                    conString = ConfigurationManager.ConnectionStrings["Excel07+ConString"].ConnectionString;
                    break;
            }

            conString = string.Format(conString, tempFilePath);

            using (OleDbConnection excelCon = new OleDbConnection(conString))
            {
                excelCon.Open();
                string sheet1 = excelCon.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null).Rows[0]["TABLE_NAME"].ToString();
                DataTable dtExcelData = new DataTable();

                using (OleDbDataAdapter oda = new OleDbDataAdapter("SELECT * FROM [" + sheet1 + "]", excelCon))
                {
                    oda.Fill(dtExcelData);
                }

                string consString = ConfigurationManager.ConnectionStrings["ShopifyCon"].ConnectionString;

                using (OracleConnection con = new OracleConnection(consString))
                {
                    con.Open();
                    using (OracleTransaction transaction = con.BeginTransaction())
                    {
                        try
                        {
                            string deleteCommandText = "DELETE FROM SHOPIFY_CUSTOMERS";
                            using (OracleCommand deleteTableCmd = new OracleCommand(deleteCommandText, con))
                            {
                                deleteTableCmd.ExecuteNonQuery();
                            }

                            string insertCommandText = @"
                        INSERT INTO SHOPIFY_CUSTOMERS 
                        (SC_RECID, MEMBER_ID,ORDERID, BILL_CUSTOMERNAME, BILL_ADDRESS, STATUS, BILL_CITY, BILL_STATE, BILL_COUNTRY, 
                        BILL_PINCODE, BILL_PHONENUMBER, BILL_EMAILID,SHIP_CUSTOMERNAME,SHIP_ADDRESS,SHIP_CITY,SHIP_STATE,SHIP_COUNTRY,SHIP_PINCODE,
                        SHIP_PHONENUMBER,PAYMENT_ID,PAYMENT_METHOD,CURRENCY, CREATED_ON)
                        VALUES 
                        (SHOPIFY_SEQ.NEXTVAL, :MEMBER_ID, :ORDERID, :BILL_CUSTOMERNAME, :BILL_ADDRESS, :STATUS, :BILL_CITY, :BILL_STATE, :BILL_COUNTRY, 
                        :BILL_PINCODE, :BILL_PHONENUMBER, :BILL_EMAILID, :SHIP_CUSTOMERNAME, :SHIP_ADDRESS, :SHIP_CITY, :SHIP_STATE, :SHIP_COUNTRY, :SHIP_PINCODE,
                        :SHIP_PHONENUMBER, :PAYMENT_ID, :PAYMENT_METHOD, :CURRENCY, :CREATED_ON)";

                            using (OracleCommand insertCmd = new OracleCommand(insertCommandText, con))
                            {
                                insertCmd.Transaction = transaction;

                                // Bind parameters
                                insertCmd.Parameters.Add(new OracleParameter("MEMBER_ID", OracleDbType.Varchar2));
                                insertCmd.Parameters.Add(new OracleParameter("ORDERID", OracleDbType.Varchar2));
                                insertCmd.Parameters.Add(new OracleParameter("BILL_CUSTOMERNAME", OracleDbType.Varchar2));
                                insertCmd.Parameters.Add(new OracleParameter("BILL_ADDRESS", OracleDbType.Varchar2));
                                insertCmd.Parameters.Add(new OracleParameter("STATUS", OracleDbType.Varchar2));
                                insertCmd.Parameters.Add(new OracleParameter("BILL_CITY", OracleDbType.Varchar2));
                                insertCmd.Parameters.Add(new OracleParameter("BILL_STATE", OracleDbType.Varchar2));
                                insertCmd.Parameters.Add(new OracleParameter("BILL_COUNTRY", OracleDbType.Varchar2));
                                insertCmd.Parameters.Add(new OracleParameter("BILL_PINCODE", OracleDbType.Varchar2));
                                insertCmd.Parameters.Add(new OracleParameter("BILL_PHONENUMBER", OracleDbType.Varchar2));
                                insertCmd.Parameters.Add(new OracleParameter("BILL_EMAILID", OracleDbType.Varchar2));
                                insertCmd.Parameters.Add(new OracleParameter("SHIP_CUSTOMERNAME", OracleDbType.Varchar2));
                                insertCmd.Parameters.Add(new OracleParameter("SHIP_ADDRESS", OracleDbType.Varchar2));
                                insertCmd.Parameters.Add(new OracleParameter("SHIP_CITY", OracleDbType.Varchar2));
                                insertCmd.Parameters.Add(new OracleParameter("SHIP_STATE", OracleDbType.Varchar2));
                                insertCmd.Parameters.Add(new OracleParameter("SHIP_COUNTRY", OracleDbType.Varchar2));
                                insertCmd.Parameters.Add(new OracleParameter("SHIP_PINCODE", OracleDbType.Varchar2));
                                insertCmd.Parameters.Add(new OracleParameter("SHIP_PHONENUMBER", OracleDbType.Varchar2));
                                insertCmd.Parameters.Add(new OracleParameter("PAYMENT_ID", OracleDbType.Varchar2));
                                insertCmd.Parameters.Add(new OracleParameter("PAYMENT_METHOD", OracleDbType.Varchar2));
                                insertCmd.Parameters.Add(new OracleParameter("CURRENCY", OracleDbType.Varchar2));
                                insertCmd.Parameters.Add(new OracleParameter("CREATED_ON", OracleDbType.Date));

                                // Loop through DataTable and insert data
                                foreach (DataRow row in dtExcelData.Rows)
                                {
                                    insertCmd.Parameters["MEMBER_ID"].Value = row[2].ToString();
                                    insertCmd.Parameters["ORDERID"].Value = row[0].ToString();
                                    insertCmd.Parameters["BILL_CUSTOMERNAME"].Value = row[24].ToString();
                                    insertCmd.Parameters["BILL_ADDRESS"].Value = row[26].ToString();
                                    insertCmd.Parameters["STATUS"].Value = "A"; // Default status
                                    insertCmd.Parameters["BILL_CITY"].Value = row[29].ToString();
                                    insertCmd.Parameters["BILL_STATE"].Value = row[76];
                                    insertCmd.Parameters["BILL_COUNTRY"].Value = row[32].ToString();
                                    insertCmd.Parameters["BILL_PINCODE"].Value = row[30].ToString();
                                    insertCmd.Parameters["BILL_PHONENUMBER"].Value = row[33].ToString();
                                    insertCmd.Parameters["BILL_EMAILID"].Value = row[1].ToString();
                                    insertCmd.Parameters["SHIP_CUSTOMERNAME"].Value = row[34].ToString();
                                    insertCmd.Parameters["SHIP_ADDRESS"].Value = row[36].ToString();
                                    insertCmd.Parameters["SHIP_CITY"].Value = row[39].ToString();
                                    insertCmd.Parameters["SHIP_STATE"].Value = row[74].ToString();
                                    insertCmd.Parameters["SHIP_COUNTRY"].Value = row[42].ToString();
                                    insertCmd.Parameters["SHIP_PINCODE"].Value = row[40].ToString();
                                    insertCmd.Parameters["SHIP_PHONENUMBER"].Value = row[43].ToString();
                                    insertCmd.Parameters["PAYMENT_ID"].Value = row[75].ToString();
                                    insertCmd.Parameters["PAYMENT_METHOD"].Value = row[47].ToString();
                                    insertCmd.Parameters["CURRENCY"].Value = row[7].ToString();
                                    insertCmd.Parameters["CREATED_ON"].Value = DateTime.Now;

                                    insertCmd.ExecuteNonQuery();
                                }

                                transaction.Commit();
                            }
                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();
                            // Log exception
                            throw new Exception("An error occurred during the database operation.", ex);
                        }
                    }
                }
            }

            // Clean up file
            if (File.Exists(tempFilePath))
            {
                File.Delete(tempFilePath);
            }

            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Shopify Customer details inserted successfully.')", true);
        }
        catch (Exception ex)
        {
            // Log the exception (ex) instead of displaying it directly
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('An error occurred during the upload process. Please try again.')", true);
        }
    }
    #endregion
    //#region PushShopifyCustomer
    //protected void btnUploadShopifyCustomer_Click(object sender, EventArgs e)
    //{
    //    try
    //    {
    //        if (!fuShopifyOrder.HasFile)
    //        {
    //            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Please select a file.')", true);
    //            return;
    //        }

    //        string fileName = Path.GetFileName(fuShopifyOrder.PostedFile.FileName);
    //        string fileExtension = Path.GetExtension(fileName).ToLower();

    //        if (!(fileExtension.Equals(".xlsx") || fileExtension.Equals(".xls")))
    //        {
    //            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Please select an Excel file (.xls or .xlsx) only.')", true);
    //            return;
    //        }

    //        string tempFilePath = Path.Combine(Server.MapPath("~/WriteReadData"), fileName);
    //        fuShopifyOrder.SaveAs(tempFilePath);

    //        string conString = string.Empty;
    //        switch (fileExtension)
    //        {
    //            case ".xls":
    //                conString = ConfigurationManager.ConnectionStrings["Excel03ConString"].ConnectionString;
    //                break;
    //            case ".xlsx":
    //                conString = ConfigurationManager.ConnectionStrings["Excel07+ConString"].ConnectionString;
    //                break;
    //        }

    //        conString = string.Format(conString, tempFilePath);

    //        using (OleDbConnection excelCon = new OleDbConnection(conString))
    //        {
    //            excelCon.Open();
    //            string sheet1 = excelCon.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null).Rows[0]["TABLE_NAME"].ToString();
    //            DataTable dtExcelData = new DataTable();

    //            using (OleDbDataAdapter oda = new OleDbDataAdapter("SELECT * FROM [" + sheet1 + "]", excelCon))
    //            {
    //                oda.Fill(dtExcelData);
    //            }

    //            string consString = ConfigurationManager.ConnectionStrings["ShopifyCon"].ConnectionString;

    //            using (OracleConnection con = new OracleConnection(consString))
    //            {
    //                con.Open();
    //                using (OracleTransaction transaction = con.BeginTransaction())
    //                {
    //                    try
    //                    {
    //                        string deleteCommandText = "DELETE FROM SHOPIFY_CUSTOMERS";
    //                        using (OracleCommand deleteTableCmd = new OracleCommand(deleteCommandText, con))
    //                        {
    //                            deleteTableCmd.ExecuteNonQuery();
    //                        }

    //                        string insertCommandText = @"
    //                INSERT INTO SHOPIFY_CUSTOMERS 
    //                (SC_RECID, MEMBER_ID, ORDERID, BILL_CUSTOMERNAME, BILL_ADDRESS, STATUS, BILL_CITY, BILL_STATE, BILL_COUNTRY, 
    //                BILL_PINCODE, BILL_PHONENUMBER, BILL_EMAILID, SHIP_CUSTOMERNAME, SHIP_ADDRESS, SHIP_CITY, SHIP_STATE, SHIP_COUNTRY, SHIP_PINCODE,
    //                SHIP_PHONENUMBER, PAYMENT_ID, PAYMENT_METHOD, CURRENCY, CREATED_ON)
    //                VALUES 
    //                (SHOPIFY_SEQ.NEXTVAL, :MEMBER_ID, :ORDERID, :BILL_CUSTOMERNAME, :BILL_ADDRESS, :STATUS, :BILL_CITY, :BILL_STATE, :BILL_COUNTRY, 
    //                :BILL_PINCODE, :BILL_PHONENUMBER, :BILL_EMAILID, :SHIP_CUSTOMERNAME, :SHIP_ADDRESS, :SHIP_CITY, :SHIP_STATE, :SHIP_COUNTRY, :SHIP_PINCODE,
    //                :SHIP_PHONENUMBER, :PAYMENT_ID, :PAYMENT_METHOD, :CURRENCY, :CREATED_ON)";

    //                        using (OracleCommand insertCmd = new OracleCommand(insertCommandText, con))
    //                        {
    //                            insertCmd.Transaction = transaction;

    //                            // Bind parameters
    //                            insertCmd.Parameters.Add(new OracleParameter("MEMBER_ID", OracleDbType.Varchar2));
    //                            insertCmd.Parameters.Add(new OracleParameter("ORDERID", OracleDbType.Varchar2));
    //                            insertCmd.Parameters.Add(new OracleParameter("BILL_CUSTOMERNAME", OracleDbType.Varchar2));
    //                            insertCmd.Parameters.Add(new OracleParameter("BILL_ADDRESS", OracleDbType.Varchar2));  
    //                            insertCmd.Parameters.Add(new OracleParameter("STATUS", OracleDbType.Varchar2));
    //                            insertCmd.Parameters.Add(new OracleParameter("BILL_CITY", OracleDbType.Varchar2));   
    //                            insertCmd.Parameters.Add(new OracleParameter("BILL_STATE", OracleDbType.Varchar2));  
    //                            insertCmd.Parameters.Add(new OracleParameter("BILL_COUNTRY", OracleDbType.Varchar2)); 
    //                            insertCmd.Parameters.Add(new OracleParameter("BILL_PINCODE", OracleDbType.Varchar2));
    //                            insertCmd.Parameters.Add(new OracleParameter("BILL_PHONENUMBER", OracleDbType.Varchar2));
    //                            insertCmd.Parameters.Add(new OracleParameter("BILL_EMAILID", OracleDbType.Varchar2));
    //                            insertCmd.Parameters.Add(new OracleParameter("SHIP_CUSTOMERNAME", OracleDbType.Varchar2));
    //                            insertCmd.Parameters.Add(new OracleParameter("SHIP_ADDRESS", OracleDbType.Varchar2));
    //                            insertCmd.Parameters.Add(new OracleParameter("SHIP_CITY", OracleDbType.Varchar2));
    //                            insertCmd.Parameters.Add(new OracleParameter("SHIP_STATE", OracleDbType.Varchar2));
    //                            insertCmd.Parameters.Add(new OracleParameter("SHIP_COUNTRY", OracleDbType.Varchar2));
    //                            insertCmd.Parameters.Add(new OracleParameter("SHIP_PINCODE", OracleDbType.Varchar2));
    //                            insertCmd.Parameters.Add(new OracleParameter("SHIP_PHONENUMBER", OracleDbType.Varchar2));
    //                            insertCmd.Parameters.Add(new OracleParameter("PAYMENT_ID", OracleDbType.Varchar2));
    //                            insertCmd.Parameters.Add(new OracleParameter("PAYMENT_METHOD", OracleDbType.Varchar2));
    //                            insertCmd.Parameters.Add(new OracleParameter("CURRENCY", OracleDbType.Varchar2));
    //                            insertCmd.Parameters.Add(new OracleParameter("CREATED_ON", OracleDbType.Date));

    //                            // Loop through DataTable and insert data
    //                            foreach (DataRow row in dtExcelData.Rows)
    //                            {
    //                                insertCmd.Parameters["MEMBER_ID"].Value = row[2].ToString();
    //                                insertCmd.Parameters["ORDERID"].Value = row[0].ToString();
    //                                insertCmd.Parameters["BILL_CUSTOMERNAME"].Value = row[24].ToString();
    //                                insertCmd.Parameters["BILL_ADDRESS"].Value = row[26].ToString();
    //                                insertCmd.Parameters["STATUS"].Value = "A"; // Default status
    //                                insertCmd.Parameters["BILL_CITY"].Value = row[29].ToString();
    //                                insertCmd.Parameters["BILL_STATE"].Value = row[76].ToString();
    //                                insertCmd.Parameters["BILL_COUNTRY"].Value = row[32].ToString();
    //                                insertCmd.Parameters["BILL_PINCODE"].Value = row[30].ToString();
    //                                insertCmd.Parameters["BILL_PHONENUMBER"].Value = row[33].ToString();
    //                                insertCmd.Parameters["BILL_EMAILID"].Value = row[1].ToString();
    //                                insertCmd.Parameters["SHIP_CUSTOMERNAME"].Value = row[34].ToString();
    //                                insertCmd.Parameters["SHIP_ADDRESS"].Value = row[36].ToString();
    //                                insertCmd.Parameters["SHIP_CITY"].Value = row[39].ToString();
    //                                insertCmd.Parameters["SHIP_STATE"].Value = row[74].ToString();
    //                                insertCmd.Parameters["SHIP_COUNTRY"].Value = row[42].ToString();
    //                                insertCmd.Parameters["SHIP_PINCODE"].Value = row[40].ToString();
    //                                insertCmd.Parameters["SHIP_PHONENUMBER"].Value = row[43].ToString();
    //                                insertCmd.Parameters["PAYMENT_ID"].Value = row[75].ToString();
    //                                insertCmd.Parameters["PAYMENT_METHOD"].Value = row[47].ToString();
    //                                insertCmd.Parameters["CURRENCY"].Value = row[7].ToString();
    //                                insertCmd.Parameters["CREATED_ON"].Value = DateTime.Now;

    //                                insertCmd.ExecuteNonQuery();
    //                            }

    //                            transaction.Commit();
    //                        }
    //                    }
    //                    catch (Exception ex)
    //                    {
    //                        transaction.Rollback();
    //                        // Log exception
    //                        throw new Exception("An error occurred during the database operation.", ex);
    //                    }
    //                }
    //            }
    //        }

    //        // Clean up file
    //        if (File.Exists(tempFilePath))
    //        {
    //            File.Delete(tempFilePath);
    //        }
    //    }
    //    catch (Exception ex)
    //    {
    //        // Log the exception (ex) instead of displaying it directly
    //        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('An error occurred during the upload process. Please try again.')", true);
    //    }
    //}
    //#endregion
}