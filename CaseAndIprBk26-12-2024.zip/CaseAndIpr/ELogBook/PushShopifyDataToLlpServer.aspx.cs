﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.OleDb;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;

public partial class ELogBook_PushShopifyDataToLlpServer : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    //#region UploadPushShopifyData
    //protected void btnPushShopifyData_Click(object sender, EventArgs e)
    //{
    //    int SalesorderNo = 0;
    //    int CustomerRecordNo = 0;
    //    try
    //    {
    //        // Validate if a file has been selected
    //        if (!fuShopifyOrder.HasFile)
    //        {
    //            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Please select a file.')", true);
    //            return;
    //        }

    //        string fileName = Path.GetFileName(fuShopifyOrder.PostedFile.FileName);
    //        string fileExtension = Path.GetExtension(fileName).ToLower();

    //        // Check if the file is an Excel file
    //        if (!(fileExtension.Equals(".xlsx") || fileExtension.Equals(".xls")))
    //        {
    //            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Please select an Excel file (.xls or .xlsx) only.')", true);
    //            return;
    //        }

    //        // Save the uploaded file temporarily
    //        string tempFilePath = Path.Combine(Server.MapPath("~/WriteReadData"), fileName);
    //        fuShopifyOrder.SaveAs(tempFilePath);

    //        // Define connection string based on file extension
    //        string conString = fileExtension == ".xls"
    //            ? ConfigurationManager.ConnectionStrings["Excel03ConString"].ConnectionString
    //            : ConfigurationManager.ConnectionStrings["Excel07+ConString"].ConnectionString;

    //        conString = string.Format(conString, tempFilePath);

    //        // Read data from the Excel file
    //        DataTable dtExcelData = new DataTable();
    //        using (OleDbConnection excelCon = new OleDbConnection(conString))
    //        {
    //            excelCon.Open();
    //            string sheetName = excelCon.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null).Rows[0]["TABLE_NAME"].ToString();
    //            using (OleDbDataAdapter oda = new OleDbDataAdapter("SELECT * FROM [" + sheetName + "]", excelCon))
    //           // using (OleDbDataAdapter oda = new OleDbDataAdapter("SELECT * FROM {sheetName}", excelCon))
    //            {
    //                oda.Fill(dtExcelData);
    //            }
    //        }

    //        // Process the data and insert it into the database
    //        string consString = ConfigurationManager.ConnectionStrings["ShopifyCon"].ConnectionString;
    //        using (OracleConnection con = new OracleConnection(consString))
    //        {
    //            con.Open();
    //            using (OracleTransaction transaction = con.BeginTransaction())
    //            {
    //                try
    //                {
    //                    // Step 2: Insert Shopify sales orders
    //                    SalesorderNo = InsertShopifySalesOrders(con, transaction, dtExcelData);

    //                    // Step 4: Insert Shopify customers
    //                    CustomerRecordNo = InsertShopifyCustomers(con, transaction, dtExcelData);

    //                    transaction.Commit();
    //                }
    //                catch (Exception ex)
    //                {
    //                    transaction.Rollback();
    //                    // Log the error
    //                    throw new Exception("An error occurred during the database operation.", ex);
    //                }
    //            }
    //        }

    //        // Clean up the uploaded file
    //        if (File.Exists(tempFilePath))
    //        {
    //            File.Delete(tempFilePath);
    //        }
    //        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Total:- " + SalesorderNo + " sales order is inserted and Total:- " + CustomerRecordNo + " customer detail is inserted.')", true);
    //       // ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Shopify data inserted successfully.')", true);
    //    }
    //    catch (Exception ex)
    //    {
    //        // Log the error (ex)
    //        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('An error occurred: " + ex.Message + "')", true);
    //    }
    //}

    //private void ExecuteNonQuery(OracleConnection con, string commandText)
    //{
    //    using (OracleCommand cmd = new OracleCommand(commandText, con))
    //    {
    //        cmd.ExecuteNonQuery();
    //    }
    //}

    //private int InsertShopifySalesOrders(OracleConnection con, OracleTransaction transaction, DataTable dtExcelData)
    //{
    //    int success = 0;
    //    string insertCommandText = @"INSERT INTO SHOPIFY_SALE_ORDERS (SSO_RECID, ORDERID, ORDERDATE, CUSTOMERID, PRODUCTID, STATUS, QUANTITY, PRICE, CREATED_ON)
    //                             VALUES (SHOPIFY_SEQ.NEXTVAL, :ORDERID, :ORDERDATE, :CUSTOMERID, :PRODUCTID, :STATUS, :QUANTITY, :PRICE, :CREATED_ON)";

    //    string checkInvoiceCommandText = @"select count(*)InvoiceCounter from SHOPIFY_SALE_ORDERS where ORDERID = :ORDERID and invoice_no is not null";

    //    string checkExistenceCommandText = @"SELECT COUNT(*) FROM SHOPIFY_SALE_ORDERS WHERE ORDERID = :ORDERID AND PRODUCTID = :PRODUCTID";

    //    using (OracleCommand insertCmd = new OracleCommand(insertCommandText, con))
    //    using (OracleCommand checkInvoiceCmd = new OracleCommand(checkInvoiceCommandText, con))
    //    using (OracleCommand checkCmd = new OracleCommand(checkExistenceCommandText, con))
    //    {
    //        insertCmd.Transaction = transaction;
    //        checkCmd.Transaction = transaction;
    //        checkInvoiceCmd.Transaction = transaction;

    //        // Bind parameters for check invoice command
    //        checkInvoiceCmd.Parameters.Add(new OracleParameter("ORDERID", OracleDbType.Varchar2));

    //        // Bind parameters for existence check command
    //        checkCmd.Parameters.Add(new OracleParameter("ORDERID", OracleDbType.Varchar2));
    //        checkCmd.Parameters.Add(new OracleParameter("PRODUCTID", OracleDbType.Varchar2));

    //        // Bind parameters for insertCmd
    //        insertCmd.Parameters.Add(new OracleParameter("ORDERID", OracleDbType.Varchar2));
    //        insertCmd.Parameters.Add(new OracleParameter("ORDERDATE", OracleDbType.Date));
    //        insertCmd.Parameters.Add(new OracleParameter("CUSTOMERID", OracleDbType.Varchar2));
    //        insertCmd.Parameters.Add(new OracleParameter("PRODUCTID", OracleDbType.Varchar2));
    //        insertCmd.Parameters.Add(new OracleParameter("STATUS", OracleDbType.Varchar2));
    //        insertCmd.Parameters.Add(new OracleParameter("QUANTITY", OracleDbType.Int32));
    //        insertCmd.Parameters.Add(new OracleParameter("PRICE", OracleDbType.Decimal));
    //        insertCmd.Parameters.Add(new OracleParameter("CREATED_ON", OracleDbType.Date));

    //        foreach (DataRow row in dtExcelData.Rows)
    //        {
    //            string orderId = row[0].ToString();
    //            string productId = row[5].ToString();

    //            // Set the parameters for the check query
    //            checkInvoiceCmd.Parameters["ORDERID"].Value = orderId;

    //            // Set the parameters for the check query
    //            checkCmd.Parameters["ORDERID"].Value = orderId;
    //            checkCmd.Parameters["PRODUCTID"].Value = productId;

    //            // Execute the check query
    //            int countInvoice = Convert.ToInt32(checkInvoiceCmd.ExecuteScalar());

    //            // Execute the check query
    //            int count = Convert.ToInt32(checkCmd.ExecuteScalar());

    //            if (countInvoice > 0)
    //            {
    //                // Skip the insertion if the combination exists
    //                continue;
    //            }

    //            if (count > 0)
    //            {
    //                // Skip the insertion if the combination exists
    //                continue;
    //            }

    //            // Set parameters for insertion
    //            insertCmd.Parameters["ORDERID"].Value = row[0].ToString();
    //            insertCmd.Parameters["ORDERDATE"].Value = DateTime.Parse(row[4].ToString());
    //            insertCmd.Parameters["CUSTOMERID"].Value = row[3].ToString();
    //            insertCmd.Parameters["PRODUCTID"].Value = row[5].ToString();
    //            insertCmd.Parameters["STATUS"].Value = "A"; // Default status
    //            insertCmd.Parameters["QUANTITY"].Value = Convert.ToInt32(row[6]);
    //            insertCmd.Parameters["PRICE"].Value = Convert.ToDecimal(row[8]);
    //            insertCmd.Parameters["CREATED_ON"].Value = DateTime.Now;

    //            // Execute the insert query
    //            success += insertCmd.ExecuteNonQuery();
    //        }
    //    }
    //    return success;
    //}

    //private int InsertShopifyCustomers(OracleConnection con, OracleTransaction transaction, DataTable dtExcelData)
    //{
    //    int success = 0;
    //    string insertCommandText = @"INSERT INTO SHOPIFY_CUSTOMERS 
    //                            (SC_RECID, MEMBER_ID, ORDERID, BILL_CUSTOMERNAME, BILL_ADDRESS, STATUS, BILL_CITY, BILL_STATE, BILL_COUNTRY, BILL_PINCODE, 
    //                            BILL_PHONENUMBER, BILL_EMAILID, SHIP_CUSTOMERNAME, SHIP_ADDRESS, SHIP_CITY, SHIP_STATE, SHIP_COUNTRY, SHIP_PINCODE, 
    //                            SHIP_PHONENUMBER, PAYMENT_METHOD, CURRENCY, CREATED_ON)
    //                            VALUES 
    //                            (SHOPIFY_SEQ.NEXTVAL, :MEMBER_ID, :ORDERID, :BILL_CUSTOMERNAME, :BILL_ADDRESS, :STATUS, :BILL_CITY, :BILL_STATE, :BILL_COUNTRY, :BILL_PINCODE, 
    //                            :BILL_PHONENUMBER, :BILL_EMAILID, :SHIP_CUSTOMERNAME, :SHIP_ADDRESS, :SHIP_CITY, :SHIP_STATE, :SHIP_COUNTRY, :SHIP_PINCODE, 
    //                            :SHIP_PHONENUMBER, :PAYMENT_METHOD, :CURRENCY, :CREATED_ON)";

    //    string checkExistenceQuery = @"SELECT COUNT(*) FROM SHOPIFY_CUSTOMERS WHERE MEMBER_ID = :MEMBER_ID AND ORDERID = :ORDERID";

    //    using (OracleCommand insertCmd = new OracleCommand(insertCommandText, con))
    //    using (OracleCommand checkCmd = new OracleCommand(checkExistenceQuery, con))
    //    {
    //        insertCmd.Transaction = transaction;
    //        checkCmd.Transaction = transaction;

    //        // Bind parameters for checkCmd
    //        checkCmd.Parameters.Add(new OracleParameter("MEMBER_ID", OracleDbType.Varchar2));
    //        checkCmd.Parameters.Add(new OracleParameter("ORDERID", OracleDbType.Varchar2));

    //        // Bind parameters for insertCmd
    //        insertCmd.Parameters.Add(new OracleParameter("MEMBER_ID", OracleDbType.Varchar2));
    //        insertCmd.Parameters.Add(new OracleParameter("ORDERID", OracleDbType.Varchar2));
    //        insertCmd.Parameters.Add(new OracleParameter("BILL_CUSTOMERNAME", OracleDbType.Varchar2));
    //        insertCmd.Parameters.Add(new OracleParameter("BILL_ADDRESS", OracleDbType.Varchar2));
    //        insertCmd.Parameters.Add(new OracleParameter("STATUS", OracleDbType.Varchar2));
    //        insertCmd.Parameters.Add(new OracleParameter("BILL_CITY", OracleDbType.Varchar2));
    //        insertCmd.Parameters.Add(new OracleParameter("BILL_STATE", OracleDbType.Varchar2));
    //        insertCmd.Parameters.Add(new OracleParameter("BILL_COUNTRY", OracleDbType.Varchar2));
    //        insertCmd.Parameters.Add(new OracleParameter("BILL_PINCODE", OracleDbType.Varchar2));
    //        insertCmd.Parameters.Add(new OracleParameter("BILL_PHONENUMBER", OracleDbType.Varchar2));
    //        insertCmd.Parameters.Add(new OracleParameter("BILL_EMAILID", OracleDbType.Varchar2));
    //        insertCmd.Parameters.Add(new OracleParameter("SHIP_CUSTOMERNAME", OracleDbType.Varchar2));
    //        insertCmd.Parameters.Add(new OracleParameter("SHIP_ADDRESS", OracleDbType.Varchar2));
    //        insertCmd.Parameters.Add(new OracleParameter("SHIP_CITY", OracleDbType.Varchar2));
    //        insertCmd.Parameters.Add(new OracleParameter("SHIP_STATE", OracleDbType.Varchar2));
    //        insertCmd.Parameters.Add(new OracleParameter("SHIP_COUNTRY", OracleDbType.Varchar2));
    //        insertCmd.Parameters.Add(new OracleParameter("SHIP_PINCODE", OracleDbType.Varchar2));
    //        insertCmd.Parameters.Add(new OracleParameter("SHIP_PHONENUMBER", OracleDbType.Varchar2));
    //        insertCmd.Parameters.Add(new OracleParameter("PAYMENT_METHOD", OracleDbType.Varchar2));
    //        insertCmd.Parameters.Add(new OracleParameter("CURRENCY", OracleDbType.Varchar2));
    //        insertCmd.Parameters.Add(new OracleParameter("CREATED_ON", OracleDbType.Date));

    //        foreach (DataRow row in dtExcelData.Rows)
    //        {
    //            string memberId = row[3].ToString();
    //            string orderId = row[0].ToString();

    //            // Set the parameters for the check query
    //            checkCmd.Parameters["MEMBER_ID"].Value = memberId;
    //            checkCmd.Parameters["ORDERID"].Value = orderId;

    //            // Execute the check query
    //            int count = Convert.ToInt32(checkCmd.ExecuteScalar());

    //            if (count > 0)
    //            {
    //                // Skip the insertion if the combination exists
    //                continue;
    //            }

    //            // Set parameters for insertion
    //            insertCmd.Parameters["MEMBER_ID"].Value = memberId;
    //            insertCmd.Parameters["ORDERID"].Value = orderId;
    //            insertCmd.Parameters["BILL_CUSTOMERNAME"].Value = row[19].ToString();
    //            insertCmd.Parameters["BILL_ADDRESS"].Value = row[21].ToString();
    //            insertCmd.Parameters["STATUS"].Value = "A"; // Default status
    //            insertCmd.Parameters["BILL_CITY"].Value = row[22].ToString();
    //            insertCmd.Parameters["BILL_STATE"].Value = row[24].ToString();
    //            insertCmd.Parameters["BILL_COUNTRY"].Value = row[25].ToString();
    //            insertCmd.Parameters["BILL_PINCODE"].Value = row[23].ToString();
    //            insertCmd.Parameters["BILL_PHONENUMBER"].Value = row[20].ToString();
    //            insertCmd.Parameters["BILL_EMAILID"].Value = row[2].ToString();
    //            insertCmd.Parameters["SHIP_CUSTOMERNAME"].Value = row[12].ToString();
    //            insertCmd.Parameters["SHIP_ADDRESS"].Value = row[14].ToString();
    //            insertCmd.Parameters["SHIP_CITY"].Value = row[15].ToString();
    //            insertCmd.Parameters["SHIP_STATE"].Value = row[17].ToString();
    //            insertCmd.Parameters["SHIP_COUNTRY"].Value = row[18].ToString();
    //            insertCmd.Parameters["SHIP_PINCODE"].Value = row[16].ToString();
    //            insertCmd.Parameters["SHIP_PHONENUMBER"].Value = row[13].ToString();
    //            insertCmd.Parameters["PAYMENT_METHOD"].Value = row[11].ToString();
    //            insertCmd.Parameters["CURRENCY"].Value = row[10].ToString();
    //            insertCmd.Parameters["CREATED_ON"].Value = DateTime.Now;

    //            // Execute the insert query
    //            success += insertCmd.ExecuteNonQuery();
    //        }
    //    }
    //    return success;
    //}
    //#endregion
    #region UploadPushShopifyData
    protected void btnPushShopifyData_Click(object sender, EventArgs e)
    {
        int SalesorderNo = 0;
        int CustomerRecordNo = 0;
        try
        {
            // Path to the CSV file on D: drive
            string filePath = @"D:\Shopify_Order_List.csv";

            // Check if the file exists
            if (!File.Exists(filePath))
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('File not found at D:\\Shopify_Order_List.csv.')", true);
                return;
            }

            // Read data from the CSV file
            DataTable dtCsvData = new DataTable();
            dtCsvData = ReadCsvFile(filePath);

            // Process the data and insert it into the database
            string consString = ConfigurationManager.ConnectionStrings["ShopifyCon"].ConnectionString;
            using (OracleConnection con = new OracleConnection(consString))
            {
                con.Open();
                using (OracleTransaction transaction = con.BeginTransaction())
                {
                    try
                    {
                        // Insert Shopify sales orders
                        SalesorderNo = InsertShopifySalesOrders(con, transaction, dtCsvData);

                        // Insert Shopify customers
                        CustomerRecordNo = InsertShopifyCustomers(con, transaction, dtCsvData);

                        transaction.Commit();
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw new Exception("An error occurred during the database operation.", ex);
                    }
                }
            }

            // Alert success message
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Total:- " + SalesorderNo + " sales order is inserted and Total:- " + CustomerRecordNo + " customer detail is inserted.')", true);
        }
        catch (Exception ex)
        {
            // Log the error and show alert
            if (ex.Message.Equals("Connection request timed out"))
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('VPN is not connected.')", true);
            }
            else
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('An error occurred: " + ex.Message + "')", true);
            }
        }
    }

    private DataTable ReadCsvFile(string filePath)
    {
        DataTable dtCsvData = new DataTable();
        using (StreamReader sr = new StreamReader(filePath))
        {
            // Read the header line
            string[] headers = sr.ReadLine().Split(',');
            foreach (string header in headers)
            {
                dtCsvData.Columns.Add(header);
            }

            // Read the file line by line
            while (!sr.EndOfStream)
            {
                string[] rows = sr.ReadLine().Split(',');
                DataRow dr = dtCsvData.NewRow();
                for (int i = 0; i < headers.Length; i++)
                {
                    dr[i] = rows[i];
                }
                dtCsvData.Rows.Add(dr);
            }
        }
        return dtCsvData;
    }

    private int InsertShopifySalesOrders(OracleConnection con, OracleTransaction transaction, DataTable dtCsvData)
    {
        int success = 0;
        string insertCommandText = @"INSERT INTO SHOPIFY_SALE_ORDERS (SSO_RECID, ORDERID, ORDERDATE, CUSTOMERID, PRODUCTID, STATUS, QUANTITY, PRICE, COD, CREATED_ON)
                             VALUES (SHOPIFY_SEQ.NEXTVAL, :ORDERID, :ORDERDATE, :CUSTOMERID, :PRODUCTID, :STATUS, :QUANTITY, :PRICE, :COD, :CREATED_ON)";

        string checkInvoiceCommandText = @"select count(*) InvoiceCounter from SHOPIFY_SALE_ORDERS where ORDERID = :ORDERID and invoice_no is not null";
        string checkExistenceCommandText = @"SELECT COUNT(*) FROM SHOPIFY_SALE_ORDERS WHERE ORDERID = :ORDERID AND PRODUCTID = :PRODUCTID";

        using (OracleCommand insertCmd = new OracleCommand(insertCommandText, con))
        using (OracleCommand checkInvoiceCmd = new OracleCommand(checkInvoiceCommandText, con))
        using (OracleCommand checkCmd = new OracleCommand(checkExistenceCommandText, con))
        {
            insertCmd.Transaction = transaction;
            checkCmd.Transaction = transaction;
            checkInvoiceCmd.Transaction = transaction;

            // Bind parameters for check invoice command
            checkInvoiceCmd.Parameters.Add(new OracleParameter("ORDERID", OracleDbType.Varchar2));

            // Bind parameters for existence check command
            checkCmd.Parameters.Add(new OracleParameter("ORDERID", OracleDbType.Varchar2));
            checkCmd.Parameters.Add(new OracleParameter("PRODUCTID", OracleDbType.Varchar2));

            // Bind parameters for insertCmd
            insertCmd.Parameters.Add(new OracleParameter("ORDERID", OracleDbType.Varchar2));
            insertCmd.Parameters.Add(new OracleParameter("ORDERDATE", OracleDbType.Varchar2));
            insertCmd.Parameters.Add(new OracleParameter("CUSTOMERID", OracleDbType.Varchar2));
            insertCmd.Parameters.Add(new OracleParameter("PRODUCTID", OracleDbType.Varchar2));
            insertCmd.Parameters.Add(new OracleParameter("STATUS", OracleDbType.Varchar2));
            insertCmd.Parameters.Add(new OracleParameter("QUANTITY", OracleDbType.Int32));
            insertCmd.Parameters.Add(new OracleParameter("PRICE", OracleDbType.Decimal));
            insertCmd.Parameters.Add(new OracleParameter("COD", OracleDbType.Int32));
            insertCmd.Parameters.Add(new OracleParameter("CREATED_ON", OracleDbType.Date));

            foreach (DataRow row in dtCsvData.Rows)
            {
                string orderId = row[0].ToString();
                string productId = row[5].ToString();

                // Set the parameters for the check query
                checkInvoiceCmd.Parameters["ORDERID"].Value = orderId;
                checkCmd.Parameters["ORDERID"].Value = orderId;
                checkCmd.Parameters["PRODUCTID"].Value = productId;

                // Execute the check query
                int countInvoice = Convert.ToInt32(checkInvoiceCmd.ExecuteScalar());
                int count = Convert.ToInt32(checkCmd.ExecuteScalar());

                if (countInvoice > 0 || count > 0)
                {
                    // Skip the insertion if the combination exists
                    continue;
                }

                // Set parameters for insertion
                insertCmd.Parameters["ORDERID"].Value = row[0].ToString();
                insertCmd.Parameters["ORDERDATE"].Value = DateTime.Parse(row[4].ToString()).ToString("yyyy-MM-dd");
                insertCmd.Parameters["CUSTOMERID"].Value = row[3].ToString();
                insertCmd.Parameters["PRODUCTID"].Value = row[5].ToString();
                insertCmd.Parameters["STATUS"].Value = "A"; // Default status
                insertCmd.Parameters["QUANTITY"].Value = Convert.ToInt32(row[6]);
                insertCmd.Parameters["PRICE"].Value = Convert.ToDecimal(row[8]);
                insertCmd.Parameters["COD"].Value = "0";
                insertCmd.Parameters["CREATED_ON"].Value = DateTime.Now;

                // Execute the insert query
                success += insertCmd.ExecuteNonQuery();
            }
        }
        return success;
    }

    private int InsertShopifyCustomers(OracleConnection con, OracleTransaction transaction, DataTable dtCsvData)
    {
        int success = 0;
        string insertCommandText = @"INSERT INTO SHOPIFY_CUSTOMERS 
                                (SC_RECID, MEMBER_ID, ORDERID, BILL_CUSTOMERNAME, BILL_ADDRESS, STATUS, BILL_CITY, BILL_STATE, BILL_COUNTRY, BILL_PINCODE, 
                                BILL_PHONENUMBER, BILL_EMAILID, SHIP_CUSTOMERNAME, SHIP_ADDRESS, SHIP_CITY, SHIP_STATE, SHIP_COUNTRY, SHIP_PINCODE, 
                                SHIP_PHONENUMBER, PAYMENT_METHOD, CURRENCY, CREATED_ON)
                                VALUES 
                                (SHOPIFY_SEQ.NEXTVAL, :MEMBER_ID, :ORDERID, :BILL_CUSTOMERNAME, :BILL_ADDRESS, :STATUS, :BILL_CITY, :BILL_STATE, :BILL_COUNTRY, :BILL_PINCODE, 
                                :BILL_PHONENUMBER, :BILL_EMAILID, :SHIP_CUSTOMERNAME, :SHIP_ADDRESS, :SHIP_CITY, :SHIP_STATE, :SHIP_COUNTRY, :SHIP_PINCODE, 
                                :SHIP_PHONENUMBER, :PAYMENT_METHOD, :CURRENCY, :CREATED_ON)";

        string checkExistenceQuery = @"SELECT COUNT(*) FROM SHOPIFY_CUSTOMERS WHERE MEMBER_ID = :MEMBER_ID AND ORDERID = :ORDERID";

        using (OracleCommand insertCmd = new OracleCommand(insertCommandText, con))
        using (OracleCommand checkCmd = new OracleCommand(checkExistenceQuery, con))
        {
            insertCmd.Transaction = transaction;
            checkCmd.Transaction = transaction;

            // Bind parameters for checkCmd
            checkCmd.Parameters.Add(new OracleParameter("MEMBER_ID", OracleDbType.Varchar2));
            checkCmd.Parameters.Add(new OracleParameter("ORDERID", OracleDbType.Varchar2));

            // Bind parameters for insertCmd
            insertCmd.Parameters.Add(new OracleParameter("MEMBER_ID", OracleDbType.Varchar2));
            insertCmd.Parameters.Add(new OracleParameter("ORDERID", OracleDbType.Varchar2));
            insertCmd.Parameters.Add(new OracleParameter("BILL_CUSTOMERNAME", OracleDbType.Varchar2));
            insertCmd.Parameters.Add(new OracleParameter("BILL_ADDRESS", OracleDbType.Varchar2));
            insertCmd.Parameters.Add(new OracleParameter("STATUS", OracleDbType.Varchar2));
            insertCmd.Parameters.Add(new OracleParameter("BILL_CITY", OracleDbType.Varchar2));
            insertCmd.Parameters.Add(new OracleParameter("BILL_STATE", OracleDbType.Varchar2));
            insertCmd.Parameters.Add(new OracleParameter("BILL_COUNTRY", OracleDbType.Varchar2));
            insertCmd.Parameters.Add(new OracleParameter("BILL_PINCODE", OracleDbType.Varchar2));
            insertCmd.Parameters.Add(new OracleParameter("BILL_PHONENUMBER", OracleDbType.Varchar2));
            insertCmd.Parameters.Add(new OracleParameter("BILL_EMAILID", OracleDbType.Varchar2));
            insertCmd.Parameters.Add(new OracleParameter("SHIP_CUSTOMERNAME", OracleDbType.Varchar2));
            insertCmd.Parameters.Add(new OracleParameter("SHIP_ADDRESS", OracleDbType.Varchar2));
            insertCmd.Parameters.Add(new OracleParameter("SHIP_CITY", OracleDbType.Varchar2));
            insertCmd.Parameters.Add(new OracleParameter("SHIP_STATE", OracleDbType.Varchar2));
            insertCmd.Parameters.Add(new OracleParameter("SHIP_COUNTRY", OracleDbType.Varchar2));
            insertCmd.Parameters.Add(new OracleParameter("SHIP_PINCODE", OracleDbType.Varchar2));
            insertCmd.Parameters.Add(new OracleParameter("SHIP_PHONENUMBER", OracleDbType.Varchar2));
            insertCmd.Parameters.Add(new OracleParameter("PAYMENT_METHOD", OracleDbType.Varchar2));
            insertCmd.Parameters.Add(new OracleParameter("CURRENCY", OracleDbType.Varchar2));
            insertCmd.Parameters.Add(new OracleParameter("CREATED_ON", OracleDbType.Date));

            foreach (DataRow row in dtCsvData.Rows)
            {
                string memberId = row[3].ToString();
                string orderId = row[0].ToString();

                // Set parameters for the check query
                checkCmd.Parameters["MEMBER_ID"].Value = memberId;
                checkCmd.Parameters["ORDERID"].Value = orderId;

                // Execute the check query
                int count = Convert.ToInt32(checkCmd.ExecuteScalar());

                if (count > 0)
                {
                    // Skip the insertion if the combination exists
                    continue;
                }

                // Set parameters for insertion
                insertCmd.Parameters["MEMBER_ID"].Value = memberId;
                insertCmd.Parameters["ORDERID"].Value = orderId;
                insertCmd.Parameters["BILL_CUSTOMERNAME"].Value = row[19].ToString();
                insertCmd.Parameters["BILL_ADDRESS"].Value = row[21].ToString();
                insertCmd.Parameters["STATUS"].Value = "A"; // Default status
                insertCmd.Parameters["BILL_CITY"].Value = row[22].ToString();
                insertCmd.Parameters["BILL_STATE"].Value = row[24].ToString();
                insertCmd.Parameters["BILL_COUNTRY"].Value = row[25].ToString();
                insertCmd.Parameters["BILL_PINCODE"].Value = row[23].ToString();
                insertCmd.Parameters["BILL_PHONENUMBER"].Value = row[20].ToString();
                insertCmd.Parameters["BILL_EMAILID"].Value = row[2].ToString();
                insertCmd.Parameters["SHIP_CUSTOMERNAME"].Value = row[12].ToString();
                insertCmd.Parameters["SHIP_ADDRESS"].Value = row[14].ToString();
                insertCmd.Parameters["SHIP_CITY"].Value = row[15].ToString();
                insertCmd.Parameters["SHIP_STATE"].Value = row[17].ToString();
                insertCmd.Parameters["SHIP_COUNTRY"].Value = row[18].ToString();
                insertCmd.Parameters["SHIP_PINCODE"].Value = row[16].ToString();
                insertCmd.Parameters["SHIP_PHONENUMBER"].Value = row[13].ToString();
                insertCmd.Parameters["PAYMENT_METHOD"].Value = row[11].ToString();
                insertCmd.Parameters["CURRENCY"].Value = row[10].ToString();
                insertCmd.Parameters["CREATED_ON"].Value = DateTime.Now;

                // Execute the insert query
                success += insertCmd.ExecuteNonQuery();
            }
        }
        return success;
    }
    #endregion
}