﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class NewQualityCheck : System.Web.UI.Page
{
    #region DeclareVariable
    ELogBookSystem obj = new ELogBookSystem();
    #endregion
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["EmpCode"] != null)
            {
                //GetProductName();
            }
        }
    }
    #region GetProductName
    public void GetProductName()
    {
        try
        {
            DataSet ds = obj.GetProductName(Session["EmpCode"].ToString());

            if (ds.Tables[0].Rows.Count > 0)
            {
                ddlProductName.DataSource = ds.Tables[0];
                ddlProductName.DataTextField = "ProductName";
                ddlProductName.DataValueField = "ProductName";
                ddlProductName.DataBind();
                ddlProductName.Items.Insert(0, new ListItem("--Select Product--", ""));
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region GetTestParameter
    protected void ddlProductName_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            DataSet ds = obj.GetProductName(Session["EmpCode"].ToString(),ddlProductName.SelectedValue);

            if (ds.Tables[1].Rows.Count > 0)
            {
                btnCalculate.Visible = true;
                GrdTestParameter.DataSource = ds.Tables[1];
                GrdTestParameter.DataBind();
            }
            else
            {
                btnCalculate.Visible = false;
                GrdTestParameter.DataSource = ds.Tables[1];
                GrdTestParameter.DataBind();
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region MergerCell
    protected void GrdTestParameter_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        try
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                // Get the current Test Parameter from the cell directly (cell index 1)
                string currentParameter = ((Label)e.Row.Cells[1].FindControl("lblTestParameter")).Text;

                // Check if this is not the first row
                if (e.Row.RowIndex > 0)
                {
                    // Get the previous row
                    GridViewRow previousRow = GrdTestParameter.Rows[e.Row.RowIndex - 1];

                    // Get the Test Parameter from the previous row
                    string previousParameter = ((Label)previousRow.Cells[1].FindControl("lblTestParameter")).Text;

                    // If current and previous Test Parameters are the same, merge the cells
                    if (currentParameter == previousParameter)
                    {
                        if (previousRow.Cells[1].RowSpan == 0) // If the previous row does not already have a RowSpan
                        {
                            previousRow.Cells[1].RowSpan = 2; // Set RowSpan to 2
                        }
                        else
                        {
                            previousRow.Cells[1].RowSpan += 1; // Increment RowSpan by 1
                        }

                        e.Row.Cells[1].Visible = false; // Hide the current cell
                    }
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
}