﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class LitigationCases_ViewCaseHistory : System.Web.UI.Page
{
    #region DeclareVariable
    LitigationCases obj = new LitigationCases();
    #endregion
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!IsPostBack)
        {
            if (Session["EmpCode"] != null)
            {
                if (!string.IsNullOrEmpty(Request.QueryString["CaseNo"]))
                {
                    hndCaseNo.Value = CommonUtility.Decryption(HttpUtility.UrlDecode(Request.QueryString["CaseNo"].ToString()));
                    GethistoryOfLitigationCases();
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "showToastAndRedirect", "showToastAndRedirect('error', 'Dear User you do not have permission to access this page.', 'User Authentication', 'Dashboard.aspx','2000');", true);
                }
            }
        }
    }
    #region GethistoryOfLitigationCases
    public void GethistoryOfLitigationCases()
    {
        try
        {
            if (Session["EmpCode"] != null)
            {
                DataSet ds = obj.GetLitigationCaseForEdit(Session["EmpCode"].ToString(), "", hndCaseNo.Value);

                if (ds.Tables.Count > 0 && ds.Tables[2].Rows.Count > 0)
                {
                    grdCaseHistory.DataSource = ds.Tables[2];
                    grdCaseHistory.DataBind();
                    btnExcelExport.Visible = true;
                }
                else
                {
                    grdCaseHistory.DataSource = ds.Tables[2];
                    grdCaseHistory.DataBind();
                    btnExcelExport.Visible = false;
                }
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "Javascript", "javascript:SweetDynamicWrongRedirect('Oops...','Dear user your session has been expired.Please try again later.','Dashboard.aspx'); ", true);
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region ExportDataToExcel
    protected void btnExcelExport_Click(object sender, EventArgs e)
    {
        try
        {
            ExportGridViewToExcel();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region ExportGridViewToExcel
    private void ExportGridViewToExcel()
    {
        Response.Clear();
        Response.Buffer = true;
        Response.AddHeader("content-disposition", "attachment;filename=History_Litigation_Cases.xls");
        Response.Charset = "";
        Response.ContentType = "application/vnd.ms-excel";

        using (StringWriter sw = new StringWriter())
        {
            HtmlTextWriter hw = new HtmlTextWriter(sw);

            // To Export all pages
            grdCaseHistory.AllowPaging = false;
            this.GethistoryOfLitigationCases();

            // This is to ensure that the gridview is formatted correctly in Excel
            grdCaseHistory.HeaderRow.BackColor = Color.Green;
            grdCaseHistory.HeaderRow.ForeColor = Color.White;
            foreach (TableCell cell in grdCaseHistory.HeaderRow.Cells)
            {
                cell.BackColor = grdCaseHistory.HeaderStyle.BackColor;
                cell.Font.Size = FontUnit.Point(12);
            }
            foreach (GridViewRow row in grdCaseHistory.Rows)
            {
                row.BackColor = Color.White;
                foreach (TableCell cell in row.Cells)
                {
                    if (row.RowIndex % 2 == 0)
                    {
                        cell.BackColor = Color.White;
                        cell.ForeColor = Color.Black;
                        cell.Font.Size = FontUnit.Point(10);
                    }
                    else
                    {
                        cell.BackColor = Color.White;
                        cell.ForeColor = Color.Black;
                        cell.Font.Size = FontUnit.Point(10);
                    }

                    // Check if the cell belongs to the "Priority" column
                    if (grdCaseHistory.HeaderRow.Cells[6].Text == "Priority")
                    {
                        if (cell.Text == "High")
                        {
                            cell.BackColor = Color.Red;
                        }
                        else if (cell.Text == "Medium")
                        {
                            cell.BackColor = Color.Yellow;
                        }
                        else if (cell.Text == "Low")
                        {
                            cell.BackColor = Color.Green;
                        }
                    }
                    cell.CssClass = "textmode";
                }
            }

            grdCaseHistory.RenderControl(hw);

            // Style to format numbers to text
            string style = @"<style> .textmode { mso-number-format:\@; } </style>";
            Response.Write(style);
            Response.Output.Write(sw.ToString());
            Response.Flush();
            Response.End();
        }
    }
    #endregion
    #region VerifyRenderingInServerForm
    public override void VerifyRenderingInServerForm(Control control)
    {
        // Confirms that an HtmlForm control is rendered for the specified ASP.NET
        // server control at run time. Required for GridView export to Excel
    }
    #endregion
    #region ColorCode
    protected void grdCaseHistory_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        try
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                TableCell priorityCell = e.Row.Cells[6];
                string Priority = priorityCell.Text;

                if (Priority.Equals("High"))
                {
                    priorityCell.BackColor = Color.Red;
                    priorityCell.ForeColor = Color.Black;
                }
                else if (Priority.Equals("Medium"))
                {
                    priorityCell.BackColor = Color.Yellow;
                    priorityCell.ForeColor = Color.Black;
                }
                else if (Priority.Equals("Low"))
                {
                    priorityCell.BackColor = Color.Green;
                    priorityCell.ForeColor = Color.Black;
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
}