﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.IO;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class LitigationCases_UploadLitigationCases : System.Web.UI.Page
{
    #region DeclareVariable
    LitigationCases obj = new LitigationCases();
    #endregion
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    #region ImportExcelDataToGridview
    protected void btnImportExcelData_Click(object sender, EventArgs e)
    {
        try
        {
            ImportLitigationCases();
        }
        catch(Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region ImportLitigationCases
    private void ImportLitigationCases()
    {
        try
        {
            int SkipRows = 0;
            string Err = string.Empty;
            if (!FuPoPDespatchMasterFile.HasFile)
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Please select file.')", true);
                return;
            }
            if (!(Path.GetExtension(FuPoPDespatchMasterFile.FileName).Equals(".xlsx") || Path.GetExtension(FuPoPDespatchMasterFile.FileName).Equals(".xls") || Path.GetExtension(FuPoPDespatchMasterFile.FileName).Equals(".XLSX")))
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Please Select Excel file (.xls or .xlsx) only.')", true);
                return;
            }
            if (ddlRowNumber.SelectedValue == "")
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Please Select Starting Row From Excel.')", true);
                return;
            }
            string folderPath = Server.MapPath(@"~/WriteReadData/");
            string path = Server.MapPath(@"~/WriteReadData/") + FuPoPDespatchMasterFile.FileName;
            //Check whether Directory (Folder) exists.
            if (!Directory.Exists(folderPath))
            {
                //If Directory (Folder) does not exists. Create it.
                Directory.CreateDirectory(folderPath);
            }
            try
            {
                System.IO.File.Delete(path);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            FuPoPDespatchMasterFile.SaveAs(path);

            clsExcelInterface objExcel = new clsExcelInterface();
            List<LitigationCasesDetails> ListRows = new List<LitigationCasesDetails>();
            DataTable dtExcelData = objExcel.getExcelDataTable(path);
            int rowIndex = 0;
            DateTime parsedDate;
            foreach (DataRow dr in dtExcelData.Rows)
            {
                if (SkipRows < int.Parse(ddlRowNumber.SelectedValue) - 1)
                {
                    SkipRows++;
                    continue;
                }
                string Category = dr[0].ToString();
                string LegalPersonHandling = dr[2].ToString();
                if (!string.IsNullOrWhiteSpace(Category.Trim()) && !string.IsNullOrWhiteSpace(LegalPersonHandling.Trim()))
                {
                    LitigationCasesDetails row = new LitigationCasesDetails()
                    {
                        rowIndex = rowIndex.ToString(),
                        Category = dr[0].ToString(),
                        Legal_Person_Handling = dr[2].ToString(),
                        In_House_Req = dr[3].ToString(),
                        Next_Date = DateTime.TryParse(dr[4].ToString(), out parsedDate) ? parsedDate.ToString("dd-MM-yyyy") : dr[4].ToString(),
                        Purpose_Fixed = dr[5].ToString(),
                        Priority = dr[6].ToString(),
                        Case_No = dr[7].ToString(),
                        Case_Title = dr[8].ToString(),
                        For_Against_Ds = dr[9].ToString(),
                        Court = dr[10].ToString(),
                        City = dr[11].ToString(),
                        Product_Property = dr[12].ToString(),
                        Issue_Offence = dr[13].ToString(),
                        Last_Date = DateTime.TryParse(dr[14].ToString(), out parsedDate) ? parsedDate.ToString("dd-MM-yyyy") : dr[14].ToString(),
                        Advocate_Name = dr[15].ToString(),
                    };
                    ListRows.Add(row);
                }
            }
            GrdLitigationCases.DataSource = ListRows;
            GrdLitigationCases.DataBind();
            GrdLitigationCases.Visible = true;
            btnSaveImportExcelData.Visible = true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region LitigationCases
    class LitigationCasesDetails
    {
        public string rowIndex { get; set; }
        public string Category { get; set; }
        public string Legal_Person_Handling { get; set; }
        public string In_House_Req { get; set; }
        public string Next_Date { get; set; }
        public string Purpose_Fixed { get; set; }
        public string Priority { get; set; }
        public string Case_No { get; set; }
        public string Case_Title { get; set; }
        public string For_Against_Ds { get; set; }
        public string Court { get; set; }
        public string City { get; set; }
        public string Product_Property { get; set; }
        public string Issue_Offence { get; set; }
        public string Advocate_Name { get; set; }
        public string Last_Date { get; set; }
    }
    #endregion
    #region SaveLitigationCases
    protected void btnSaveImportExcelData_Click(object sender, EventArgs e)
    {
        int success = 0;
        try
        {
            if (Session["EmpCode"] != null)
            {
                string empCode = Session["EmpCode"].ToString();
                string constr = ConfigurationManager.ConnectionStrings["ELogBook"].ConnectionString;

                using (OracleConnection con = new OracleConnection(constr))
                {
                    con.Open();
                    using (OracleTransaction objTrans = con.BeginTransaction())
                    {
                        using (OracleCommand cmd = con.CreateCommand())
                        {
                            try
                            {
                                foreach (GridViewRow row in GrdLitigationCases.Rows)
                                {
                                    string Case_No = ((Label)row.FindControl("lblCaseNo")).Text.Trim();
                                    if (!string.IsNullOrEmpty(Case_No))
                                    {
                                        cmd.CommandText = "UPDATE Lg_Litigation_Cases SET Status = 'I',UPDATED_BY = :EmpCode,UPDATED_ON = sysdate WHERE CASE_NO = :CaseNo";
                                        cmd.CommandType = CommandType.Text;
                                        cmd.Parameters.Clear();
                                        cmd.Parameters.Add(new OracleParameter("CaseNo", Case_No));
                                        cmd.Parameters.Add(new OracleParameter("EmpCode", empCode));
                                        cmd.ExecuteNonQuery();
                                    }
                                }

                                cmd.CommandText = @"INSERT INTO Lg_Litigation_Cases (
                                                Lg_Cases_Id, Category, Legal_Person_Handling, In_House_Req, Next_Date, Purpose_Fixed,
                                                Priority, Case_No, Case_Title, For_Against_Ds, Court,
                                                City, Product_Property, Issue_Offence, Last_Date, Advocate_Name, Status,
                                                Created_By, Created_On
                                            ) VALUES (
                                                Lg_Cases_ID_Seq.nextval, :Category, :LegalPersonHandling, :InHouseReq, :NextDate, :PurposeFixed,
                                                :Priority, :CaseNo, :CaseTitle, :ForAgainstDs, :Court, 
                                                :City, :ProductProperty, :IssueOffence, :LastDate, :AdvocateName, 'A', 
                                                :EmpCode, sysdate
                                            )";
                                cmd.CommandType = CommandType.Text;

                                foreach (GridViewRow row in GrdLitigationCases.Rows)
                                {
                                    SetCommandParameters(cmd, row, empCode);
                                    success += cmd.ExecuteNonQuery();
                                }

                                objTrans.Commit();
                            }
                            catch (Exception ex)
                            {
                                objTrans.Rollback();
                                LogError(ex); // Implement a method to log the error details
                                ScriptManager.RegisterStartupScript(this, GetType(), "Javascript", "javascript:SweetWrong('An unexpected error occurred. Please try again later!'); ", true);
                            }
                        }
                    }
                }

                if (success > 0)
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "alert('The Litigation Cases is successfully saved.');window.location ='Dashboard.aspx';", true);
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "Javascript", "javascript:SweetWrong('Due to technical or network connectivity issue. The Litigation Cases is not saved. Please try again later!'); ", true);
                }
            }
        }
        catch (Exception ex)
        {
            LogError(ex); // Implement a method to log the error details
            ScriptManager.RegisterStartupScript(this, GetType(), "Javascript", "javascript:SweetWrong('An unexpected error occurred. Please try again later!'); ", true);
        }
    }

    private void SetCommandParameters(OracleCommand cmd, GridViewRow row, string empCode)
    {
        cmd.Parameters.Clear();
        cmd.Parameters.Add(new OracleParameter("Category", ((Label)row.FindControl("lblCategory")).Text.Trim()));
        cmd.Parameters.Add(new OracleParameter("LegalPersonHandling", ((Label)row.FindControl("lblLegalPersonHandling")).Text.Trim()));
        cmd.Parameters.Add(new OracleParameter("InHouseReq", ((Label)row.FindControl("lblInHouseReq")).Text.Trim()));
        cmd.Parameters.Add(new OracleParameter("NextDate", ((TextBox)row.FindControl("lblNextDate")).Text.Trim()));
        cmd.Parameters.Add(new OracleParameter("PurposeFixed", ((Label)row.FindControl("lblPurposeFixed")).Text.Trim()));
        cmd.Parameters.Add(new OracleParameter("Priority", ((Label)row.FindControl("lblPriority")).Text.Trim()));
        cmd.Parameters.Add(new OracleParameter("CaseNo", ((Label)row.FindControl("lblCaseNo")).Text.Trim()));
        cmd.Parameters.Add(new OracleParameter("CaseTitle", ((Label)row.FindControl("lblCaseTitle")).Text.Trim()));
        cmd.Parameters.Add(new OracleParameter("ForAgainstDs", ((Label)row.FindControl("lblForAgainstDs")).Text.Trim()));
        cmd.Parameters.Add(new OracleParameter("Court", ((Label)row.FindControl("lblCourt")).Text.Trim()));
        cmd.Parameters.Add(new OracleParameter("City", ((Label)row.FindControl("lblCity")).Text.Trim()));
        cmd.Parameters.Add(new OracleParameter("ProductProperty", ((Label)row.FindControl("lblProductProperty")).Text.Trim()));
        cmd.Parameters.Add(new OracleParameter("IssueOffence", ((Label)row.FindControl("lblIssueOffence")).Text.Trim()));
        cmd.Parameters.Add(new OracleParameter("LastDate", ((TextBox)row.FindControl("lblLastDate")).Text.Trim()));
        cmd.Parameters.Add(new OracleParameter("AdvocateName", ((Label)row.FindControl("lblAdvocateName")).Text.Trim()));
        cmd.Parameters.Add(new OracleParameter("EmpCode", empCode));
    }

    private void LogError(Exception ex)
    {
        throw ex;
    }
    #endregion
    #region ColorCode
    protected void GrdLitigationCases_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        try
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                TableCell priorityCell = e.Row.Cells[7];
                string Priority = priorityCell.Text;

                if (Priority.Equals("High"))
                {
                    priorityCell.BackColor = Color.Red;
                    priorityCell.ForeColor = Color.Black;
                }
                else if (Priority.Equals("Medium"))
                {
                    priorityCell.BackColor = Color.Yellow;
                    priorityCell.ForeColor = Color.Black;
                }
                else if (Priority.Equals("Low"))
                {
                    priorityCell.BackColor = Color.Green;
                    priorityCell.ForeColor = Color.Black;
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
}