﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection.Emit;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class LitigationCases_Dashboard : System.Web.UI.Page
{
    #region DeclareVariable
    LitigationCases obj = new LitigationCases();
    protected string TotalCases = string.Empty;
    protected string LowPriorityCases = string.Empty;
    protected string MediumPriorityCases = string.Empty;
    protected string HighPriorityCases = string.Empty;
    #endregion
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["EmpCode"] != null)
            {
                GetDashboardCounter();
            }
        }
    }
    #region GetDashboardCounter
    private void GetDashboardCounter()
    {
        try
        {
            DataSet ds = obj.GetLitigationCases(Session["EmpCode"].ToString());

            if (ds.Tables.Count > 0 && ds.Tables[3].Rows.Count > 0)
            {
                TotalCases = ds.Tables[3].Rows[0]["TotalCases"].ToString();
                LowPriorityCases = ds.Tables[3].Rows[1]["TotalCases"].ToString();
                MediumPriorityCases = ds.Tables[3].Rows[2]["TotalCases"].ToString();
                HighPriorityCases = ds.Tables[3].Rows[3]["TotalCases"].ToString();
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
}