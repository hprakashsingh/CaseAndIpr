﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Drawing;

public partial class LitigationCases_ListOfIPR : System.Web.UI.Page
{
    #region DeclareVariable
    IprRenewalRegis obj = new IprRenewalRegis();
    #endregion
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["EmpCode"] != null)
            {
                GetIprList();
            }
        }
    }
    #region GetIprList
    public void GetIprList()
    {
        try
        {
            DataSet ds = obj.GetIprList(Session["EmpCode"].ToString());

            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                GrdIprList.DataSource = ds.Tables[0];
                GrdIprList.DataBind();
                btnExcelExport.Visible = true;
            }
            else
            {
                GrdIprList.DataSource = ds.Tables[0];
                GrdIprList.DataBind();
                btnExcelExport.Visible = false;
            }
            if (ds.Tables.Count > 0 && ds.Tables[1].Rows.Count > 0)
            {
                GrdExpireIprList.DataSource = ds.Tables[1];
                GrdExpireIprList.DataBind();
                btnExpireIprExport.Visible = true;
            }
            else
            {
                GrdExpireIprList.DataSource = ds.Tables[1];
                GrdExpireIprList.DataBind();
                btnExpireIprExport.Visible = false;
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region ExportDataToExcel
    protected void btnExcelExport_Click(object sender, EventArgs e)
    {
        try
        {
            ExportGridViewToExcel();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region ExportGridViewToExcel
    private void ExportGridViewToExcel()
    {
        Response.Clear();
        Response.Buffer = true;
        Response.AddHeader("content-disposition", "attachment;filename=IPR_Registration_Renewal.xls");
        Response.Charset = "";
        Response.ContentType = "application/vnd.ms-excel";

        using (StringWriter sw = new StringWriter())
        {
            HtmlTextWriter hw = new HtmlTextWriter(sw);

            // To Export all pages
            GrdIprList.AllowPaging = false;
            this.GetIprList();

            // This is to ensure that the gridview is formatted correctly in Excel
            GrdIprList.HeaderRow.BackColor = Color.Green;
            GrdIprList.HeaderRow.ForeColor = Color.White;
            GrdIprList.Columns[8].Visible = false;
            GrdIprList.Columns[9].Visible = false;
            foreach (TableCell cell in GrdIprList.HeaderRow.Cells)
            {
                cell.BackColor = GrdIprList.HeaderStyle.BackColor;
                cell.Font.Size = FontUnit.Point(12);
            }
            foreach (GridViewRow row in GrdIprList.Rows)
            {
                row.BackColor = Color.White;
                foreach (TableCell cell in row.Cells)
                {
                    if (row.RowIndex % 2 == 0)
                    {
                        cell.BackColor = Color.White;
                        cell.ForeColor = Color.Black;
                        cell.Font.Size = FontUnit.Point(10);
                    }
                    else
                    {
                        cell.BackColor = System.Drawing.Color.White;
                        cell.ForeColor = Color.Black;
                        cell.Font.Size = FontUnit.Point(10);
                    }
                    cell.CssClass = "textmode";
                }
            }

            GrdIprList.RenderControl(hw);

            // Style to format numbers to text
            string style = @"<style> .textmode { mso-number-format:\@; } </style>";
            Response.Write(style);
            Response.Output.Write(sw.ToString());
            Response.Flush();
            Response.End();
        }
    }
    #endregion
    #region ExportExpireIpr
    protected void btnExpireIprExport_Click(object sender, EventArgs e)
    {
        try
        {
            ExportExpireIprToExcel();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region ExportExpireIprToExcel
    private void ExportExpireIprToExcel()
    {
        Response.Clear();
        Response.Buffer = true;
        Response.AddHeader("content-disposition", "attachment;filename=Expire_IPR_List.xls");
        Response.Charset = "";
        Response.ContentType = "application/vnd.ms-excel";

        using (StringWriter sw = new StringWriter())
        {
            HtmlTextWriter hw = new HtmlTextWriter(sw);

            // To Export all pages
            GrdExpireIprList.AllowPaging = false;
            this.GetIprList();

            // This is to ensure that the gridview is formatted correctly in Excel
            GrdExpireIprList.HeaderRow.BackColor = Color.Green;
            GrdExpireIprList.HeaderRow.ForeColor = Color.White;
            foreach (TableCell cell in GrdExpireIprList.HeaderRow.Cells)
            {
                cell.BackColor = GrdExpireIprList.HeaderStyle.BackColor;
                cell.Font.Size = FontUnit.Point(12);
            }
            foreach (GridViewRow row in GrdExpireIprList.Rows)
            {
                row.BackColor = Color.White;
                foreach (TableCell cell in row.Cells)
                {
                    if (row.RowIndex % 2 == 0)
                    {
                        cell.BackColor = Color.White;
                        cell.ForeColor = Color.Black;
                        cell.Font.Size = FontUnit.Point(10);
                    }
                    else
                    {
                        cell.BackColor = System.Drawing.Color.White;
                        cell.ForeColor = Color.Black;
                        cell.Font.Size = FontUnit.Point(10);
                    }
                    cell.CssClass = "textmode";
                }
            }

            GrdExpireIprList.RenderControl(hw);

            // Style to format numbers to text
            string style = @"<style> .textmode { mso-number-format:\@; } </style>";
            Response.Write(style);
            Response.Output.Write(sw.ToString());
            Response.Flush();
            Response.End();
        }
    }
    #endregion
    #region VerifyRenderingInServerForm
    public override void VerifyRenderingInServerForm(Control control)
    {
        // Confirms that an HtmlForm control is rendered for the specified ASP.NET
        // server control at run time. Required for GridView export to Excel
    }
    #endregion
}