﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Drawing;

public partial class LitigationCases_IprRegistrationRenewal : System.Web.UI.Page
{
    #region DeclareVariable
    IprRenewalRegis obj = new IprRenewalRegis();
    #endregion
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!IsPostBack)
        {
            txtEntryDate.Attributes["min"] = DateTime.Now.ToString("yyyy-MM-dd");
            txtRenewalDate.Attributes["min"] = DateTime.Now.ToString("yyyy-MM-dd");
            if (Session["EmpCode"] != null)
            {
                GetIprList();
            }
        }
    }
    #region ResetFormData
    protected void btnClearFormData_Click(object sender, EventArgs e)
    {
        try
        {
            ClearFormData();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region AddUpdateIprDetails
    protected void btnSaveIprDetails_Click(object sender, EventArgs e)
    {
        int success = 0;
        string DocumentNo = string.Empty;
        string TradeFileName = string.Empty;
        string TradeFolderPath = string.Empty;
        string BrandFileName = string.Empty;
        string BrandFolderPath = string.Empty;
        try
        {
            // Get Document No for IPR
            DataSet IprDocNo = obj.GetDocumentNo(Session["EmpCode"].ToString());

            if (IprDocNo.Tables[0].Rows.Count > 0)
            {
                DocumentNo = IprDocNo.Tables[0].Rows[0]["ENTITY_CODE"].ToString() + "/" + IprDocNo.Tables[0].Rows[0]["BUSS_CODE"].ToString() + "/" +
                    IprDocNo.Tables[0].Rows[0]["UNIT_CODE"].ToString() + "/" + IprDocNo.Tables[0].Rows[0]["FYEAR"].ToString() + "/" +
                    IprDocNo.Tables[0].Rows[0]["MAX_NO"].ToString();

                // code for upload Trade Image of IPR
                if (fuTradeImage.HasFile)
                {
                    string FileExt = Path.GetExtension(fuTradeImage.FileName);
                    decimal FileSize = Math.Round(((decimal)fuTradeImage.PostedFile.ContentLength / (decimal)1024), 2);
                    if (FileExt.Equals(".jpeg") || FileExt.Equals(".jpg") || FileExt.Equals(".png"))
                    {
                        if (FileSize <= 5000)
                        {
                            TradeFolderPath = Server.MapPath(WebConfigurationManager.AppSettings["TradeImage"]);
                            TradeFileName = Path.GetFileNameWithoutExtension(fuTradeImage.PostedFile.FileName) + "_" + DateTime.Now.ToString("yyyy-dd-M--HH-mm-ss") + FileExt;
                            if (!Directory.Exists(TradeFolderPath))
                            {
                                Directory.CreateDirectory(TradeFolderPath);
                            }
                        }
                        else
                        {
                            ScriptManager.RegisterStartupScript(this, this.GetType(), "showErrorToast", "showToast('error', 'The file size exceeds 5 MB. Kindly resubmit the document with a file size not exceeding 5 MB', 'Error');", true);
                            return;
                        }
                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "showErrorToast", "showToast('error', 'we need you to upload documents in either jpeg,jpg and png file formats only', 'Error');", true);
                        return;
                    }
                }

                // code for upload Brand Image of IPR
                if (fuBrandImage.HasFile)
                {
                    string FileExt = Path.GetExtension(fuBrandImage.FileName);
                    decimal FileSize = Math.Round(((decimal)fuBrandImage.PostedFile.ContentLength / (decimal)1024), 2);
                    if (FileExt.Equals(".jpeg") || FileExt.Equals(".jpg") || FileExt.Equals(".png"))
                    {
                        if (FileSize <= 5000)
                        {
                            BrandFolderPath = Server.MapPath(WebConfigurationManager.AppSettings["BrandImage"]);
                            BrandFileName = Path.GetFileNameWithoutExtension(fuBrandImage.PostedFile.FileName) + "_" + DateTime.Now.ToString("yyyy-dd-M--HH-mm-ss") + FileExt;
                            if (!Directory.Exists(BrandFolderPath))
                            {
                                Directory.CreateDirectory(BrandFolderPath);
                            }
                        }
                        else
                        {
                            ScriptManager.RegisterStartupScript(this, this.GetType(), "showErrorToast", "showToast('error', 'The file size exceeds 5 MB. Kindly resubmit the document with a file size not exceeding 5 MB', 'Error');", true);
                            return;
                        }
                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "showErrorToast", "showToast('error', 'we need you to upload documents in either jpeg,jpg and png file formats only', 'Error');", true);
                        return;
                    }
                }
                string EntryDate = ConvertDateToFormat(HttpUtility.HtmlEncode(txtEntryDate.Text.Trim()));
                string RenewalDate = HttpUtility.HtmlEncode(txtRenewalDate.Text.Trim()) != "" ? ConvertDateToFormat(HttpUtility.HtmlEncode(txtRenewalDate.Text.Trim())) : "";

                success = obj.AddUpdateIprDetails(Session["EmpCode"].ToString(), hndIRR_RECID.Value, DocumentNo, HttpUtility.HtmlEncode(txtCategory.Text.Trim()),
                    HttpUtility.HtmlEncode(txtRegistrationNo.Text.Trim()), EntryDate, RenewalDate,
                    HttpUtility.HtmlEncode(txtMark.Text.Trim()), TradeFileName, BrandFileName);

                if (success > 0)
                {
                    if (TradeFileName.Length > 5)
                    {
                        fuTradeImage.PostedFile.SaveAs(TradeFolderPath + "\\" + TradeFileName);
                    }
                    if (BrandFileName.Length > 5)
                    {
                        fuBrandImage.PostedFile.SaveAs(BrandFolderPath + "\\" + BrandFileName);
                    }
                    if (hndIRR_RECID.Value == "")
                    {
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "showToastAndRedirect", "showToastAndRedirect('success', 'IPR Registration Renewal details is successfully saved.', 'Success', 'IprRegistrationRenewal.aspx','1000');", true);

                       // ScriptManager.RegisterStartupScript(this, this.GetType(), "showSuccessToast", "showToast('success', 'IPR Registration Renewal details is successfully saved.', 'Success');", true);
                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "showSuccessToast", "showToast('success', 'IPR Registration Renewal details is successfully updated.', 'Success');", true);
                    }
                    GetIprList();
                    ClearFormData();
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "showErrorToast", "showToast('error', 'Due to technical or network connectivity issue.The IPR Registration Renewal details is is not saved. Please try again later!', 'Error');", true);
                }
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "showErrorToast", "showToast('error', 'Document No is not generated. Please try again later!', 'Error');", true);
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region ClearFormData
    private void ClearFormData() 
    {
        try
        {
            hndIRR_RECID.Value = "";
            txtCategory.Text = "";
            txtRegistrationNo.Text = "";
            txtEntryDate.Text = "";
            txtRenewalDate.Text = "";
            txtMark.Text = "";
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region ConvertDateToFormat
    public string ConvertDateToFormat(string dateInput)
    {
        // Declare a DateTime variable to hold the parsed date.
        DateTime dateValue;

        // Try to parse the input string into a DateTime object.
        if (DateTime.TryParse(dateInput, out dateValue))
        {
            // Convert the DateTime object to the desired format and return it.
            return dateValue.ToString("dd-MM-yyyy");
        }
        else
        {
            // Return an error message if the input is not a valid date.
            return "Invalid Date";
        }
    }
    #endregion
    #region GetIprList
    public void GetIprList()
    {
        try
        {
            DataSet ds = obj.GetIprList(Session["EmpCode"].ToString());

            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                GrdIprList.DataSource = ds.Tables[0];
                GrdIprList.DataBind();
                btnExcelExport.Visible = true;
            }
            else
            {
                GrdIprList.DataSource = ds.Tables[0];
                GrdIprList.DataBind();
                btnExcelExport.Visible = false;
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region ExportDataToExcel
    protected void btnExcelExport_Click(object sender, EventArgs e)
    {
        try
        {
            ExportGridViewToExcel();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region ExportGridViewToExcel
    private void ExportGridViewToExcel()
    {
        Response.Clear();
        Response.Buffer = true;
        Response.AddHeader("content-disposition", "attachment;filename=IPR_Registration_Renewal.xls");
        Response.Charset = "";
        Response.ContentType = "application/vnd.ms-excel";

        using (StringWriter sw = new StringWriter())
        {
            HtmlTextWriter hw = new HtmlTextWriter(sw);

            // To Export all pages
            GrdIprList.AllowPaging = false;
            this.GetIprList();

            // This is to ensure that the gridview is formatted correctly in Excel
            GrdIprList.HeaderRow.BackColor = Color.Green;
            GrdIprList.HeaderRow.ForeColor = Color.White;
            GrdIprList.Columns[8].Visible = false;
            GrdIprList.Columns[9].Visible = false;
            foreach (TableCell cell in GrdIprList.HeaderRow.Cells)
            {
                cell.BackColor = GrdIprList.HeaderStyle.BackColor;
                cell.Font.Size = FontUnit.Point(12);
            }
            foreach (GridViewRow row in GrdIprList.Rows)
            {
                row.BackColor = Color.White;
                foreach (TableCell cell in row.Cells)
                {
                    if (row.RowIndex % 2 == 0)
                    {
                        cell.BackColor = Color.White;
                        cell.ForeColor = Color.Black;
                        cell.Font.Size = FontUnit.Point(10);
                    }
                    else
                    {
                        cell.BackColor = System.Drawing.Color.White;
                        cell.ForeColor = Color.Black;
                        cell.Font.Size = FontUnit.Point(10);
                    }
                    cell.CssClass = "textmode";
                }
            }

            GrdIprList.RenderControl(hw);

            // Style to format numbers to text
            string style = @"<style> .textmode { mso-number-format:\@; } </style>";
            Response.Write(style);
            Response.Output.Write(sw.ToString());
            Response.Flush();
            Response.End();
        }
    }
    #endregion
    #region VerifyRenderingInServerForm
    public override void VerifyRenderingInServerForm(Control control)
    {
        // Confirms that an HtmlForm control is rendered for the specified ASP.NET
        // server control at run time. Required for GridView export to Excel
    }
    #endregion
}