﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Drawing;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class LitigationCases_CreateNewCases : System.Web.UI.Page
{
    #region DeclareVariable
    LitigationCases obj = new LitigationCases();
    #endregion
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["EmpCode"] != null)
            {
                if (!string.IsNullOrEmpty(Request.QueryString["ReportType"]))
                {
                    hndReportType.Value = CommonUtility.Decryption(HttpUtility.UrlDecode(Request.QueryString["ReportType"].ToString()));
                    hndWhereCondition.Value = hndWhereCondition.Value + " and Priority = '" + hndReportType.Value + "'";
                }
                GetLitigationCases(hndWhereCondition.Value);
            }
        }
    }
    #region GetLitigationCases
    public void GetLitigationCases(string WhereCondition = "")
    {
        try
        {
            if (Session["EmpCode"] != null)
            {
                string empCode = Session["EmpCode"].ToString();
                DataSet ds = obj.GetLitigationCases(empCode, "", WhereCondition);

                if (ds.Tables.Count > 0 && ds.Tables[1].Rows.Count > 0)
                {
                    GrdLitigationCases.DataSource = ds.Tables[1];
                    GrdLitigationCases.DataBind();
                    btnExcelExport.Visible = true;
                }
                else
                {
                    GrdLitigationCases.DataSource = ds.Tables[1];
                    GrdLitigationCases.DataBind();
                    btnExcelExport.Visible = false;
                }
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "Javascript", "javascript:SweetDynamicWrongRedirect('Oops...','Dear user your session has been expired.Please try again later.','Dashboard.aspx'); ", true);
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region ExportDataToExcel
    protected void btnExcelExport_Click(object sender, EventArgs e)
    {
        try
        {
            ExportGridViewToExcel();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region ExportGridViewToExcel
    private void ExportGridViewToExcel()
    {
        Response.Clear();
        Response.Buffer = true;
        Response.AddHeader("content-disposition", "attachment;filename=UpComing_Litigation_Cases.xls");
        Response.Charset = "";
        Response.ContentType = "application/vnd.ms-excel";

        using (StringWriter sw = new StringWriter())
        {
            HtmlTextWriter hw = new HtmlTextWriter(sw);

            // To Export all pages
            GrdLitigationCases.AllowPaging = false;
            this.GetLitigationCases();

            // This is to ensure that the gridview is formatted correctly in Excel
            GrdLitigationCases.HeaderRow.BackColor = Color.Green;
            GrdLitigationCases.HeaderRow.ForeColor = Color.White;
            GrdLitigationCases.Columns[0].Visible = false;
            foreach (TableCell cell in GrdLitigationCases.HeaderRow.Cells)
            {
                cell.BackColor = GrdLitigationCases.HeaderStyle.BackColor;
                cell.Font.Size = FontUnit.Point(12);
            }
            foreach (GridViewRow row in GrdLitigationCases.Rows)
            {
                row.BackColor = Color.White;
                foreach (TableCell cell in row.Cells)
                {
                    if (row.RowIndex % 2 == 0)
                    {
                        cell.BackColor = Color.White;
                        cell.ForeColor = Color.Black;
                        cell.Font.Size = FontUnit.Point(10);
                    }
                    else
                    {
                        cell.BackColor = Color.White;
                        cell.ForeColor = Color.Black;
                        cell.Font.Size = FontUnit.Point(10);
                    }

                    // Check if the cell belongs to the "Priority" column
                    if (GrdLitigationCases.HeaderRow.Cells[7].Text == "Priority")
                    {
                        if (cell.Text == "High")
                        {
                            cell.BackColor = Color.Red;
                        }
                        else if (cell.Text == "Medium")
                        {
                            cell.BackColor = Color.Yellow;
                        }
                        else if (cell.Text == "Low")
                        {
                            cell.BackColor = Color.Green;
                        }
                    }
                    cell.CssClass = "textmode";
                }
            }

            GrdLitigationCases.RenderControl(hw);

            // Style to format numbers to text
            string style = @"<style> .textmode { mso-number-format:\@; } </style>";
            Response.Write(style);
            Response.Output.Write(sw.ToString());
            Response.Flush();
            Response.End();
        }
    }
    #endregion
    #region VerifyRenderingInServerForm
    public override void VerifyRenderingInServerForm(Control control)
    {
        // Confirms that an HtmlForm control is rendered for the specified ASP.NET
        // server control at run time. Required for GridView export to Excel
    }
    #endregion
    #region ColorCode
    protected void GrdLitigationCases_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        try
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                TableCell priorityCell = e.Row.Cells[7];
                string Priority = priorityCell.Text;

                if (Priority.Equals("High"))
                {
                    priorityCell.BackColor = Color.Red;
                    priorityCell.ForeColor = Color.Black;
                }
                else if (Priority.Equals("Medium"))
                {
                    priorityCell.BackColor = Color.Yellow;
                    priorityCell.ForeColor = Color.Black;
                }
                else if (Priority.Equals("Low"))
                {
                    priorityCell.BackColor = Color.Green;
                    priorityCell.ForeColor = Color.Black;
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region EditRecord
    protected void GrdLitigationCases_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            if (e.CommandName.Equals("EditCase"))
            {
                hndLgCasesId.Value = e.CommandArgument.ToString();
                DataSet ds = obj.GetLitigationCaseForEdit(Session["EmpCode"].ToString(),hndLgCasesId.Value);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    txtCaseNo.Text = HttpUtility.HtmlDecode(ds.Tables[0].Rows[0]["Case_No"].ToString());
                    ddlCategory.SelectedValue = HttpUtility.HtmlDecode(ds.Tables[0].Rows[0]["Category"].ToString());
                    txtLegalPersonHandling.Text = HttpUtility.HtmlDecode(ds.Tables[0].Rows[0]["Legal_Person_Handling"].ToString());
                    ddlInHouseAttend.SelectedValue = HttpUtility.HtmlDecode(ds.Tables[0].Rows[0]["In_House_Req"].ToString());
                    txtPurposeFixedFor.Text = HttpUtility.HtmlDecode(ds.Tables[0].Rows[0]["Purpose_Fixed"].ToString());
                    txtNextDate.Text = HttpUtility.HtmlDecode(ds.Tables[0].Rows[0]["Next_Date"].ToString());
                    ddlPriority.SelectedValue = HttpUtility.HtmlDecode(ds.Tables[0].Rows[0]["Priority"].ToString());
                    txtCaseTitle.Text = HttpUtility.HtmlDecode(ds.Tables[0].Rows[0]["Case_Title"].ToString());
                    ddlForAgainstDs.SelectedValue = HttpUtility.HtmlDecode(ds.Tables[0].Rows[0]["For_Against_Ds"].ToString());
                    txtCourt.Text = HttpUtility.HtmlDecode(ds.Tables[0].Rows[0]["Court"].ToString());
                    txtCity.Text = HttpUtility.HtmlDecode(ds.Tables[0].Rows[0]["City"].ToString());
                    txtProductProperty.Text = HttpUtility.HtmlDecode(ds.Tables[0].Rows[0]["Product_Property"].ToString());
                    txtIssueOffence.Text = HttpUtility.HtmlDecode(ds.Tables[0].Rows[0]["Issue_Offence"].ToString());
                    txtAdvocateName.Text = HttpUtility.HtmlDecode(ds.Tables[0].Rows[0]["Advocate_Name"].ToString());
                    txtLastDate.Text = HttpUtility.HtmlDecode(ds.Tables[0].Rows[0]["Last_Date"].ToString());
                    btnAddUpdateCase.Text = "Update Cases";
                    btnAddUpdateCase.ToolTip = "Click here to update selected Cases";
                    btnAddUpdateCase.Focus();
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region ClearFormData
    private void ClearFormData()
    {
        try
        {
            hndLgCasesId.Value = "";
            //txtCaseNo.Text = "";
            ddlCategory.SelectedValue = "";
            txtLegalPersonHandling.Text = "";
            ddlInHouseAttend.SelectedValue = "";
            txtPurposeFixedFor.Text = "";
            txtNextDate.Text = "";
            ddlPriority.SelectedValue = "";
            txtCaseTitle.Text = "";
            ddlForAgainstDs.SelectedValue = "";
            txtCourt.Text = "";
            txtCity.Text = "";
            txtProductProperty.Text = "";
            txtIssueOffence.Text = "";
            txtAdvocateName.Text = "";
            txtLastDate.Text = "";
            btnAddUpdateCase.Text = "Save Cases";
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region ResetFormData
    protected void btnClearFormData_Click(object sender, EventArgs e)
    {
        try
        {
            ClearFormData();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region AddUpdateCase
    protected void btnAddUpdateCase_Click(object sender, EventArgs e)
    {
        int success = 0;
        try
        {
            success = obj.AddUpdateCases(Session["EmpCode"].ToString(), hndLgCasesId.Value, HttpUtility.HtmlEncode(txtCaseNo.Text.Trim()), ddlCategory.SelectedValue,
                HttpUtility.HtmlEncode(txtLegalPersonHandling.Text.Trim()), ddlInHouseAttend.SelectedValue, HttpUtility.HtmlEncode(txtPurposeFixedFor.Text.Trim()),
                HttpUtility.HtmlEncode(txtNextDate.Text.Trim()), ddlPriority.SelectedValue, HttpUtility.HtmlEncode(txtCaseTitle.Text.Trim()), ddlForAgainstDs.SelectedValue,
                HttpUtility.HtmlEncode(txtCourt.Text.Trim()), HttpUtility.HtmlEncode(txtCity.Text.Trim()), HttpUtility.HtmlEncode(txtProductProperty.Text.Trim()),
                HttpUtility.HtmlEncode(txtIssueOffence.Text.Trim()), HttpUtility.HtmlEncode(txtAdvocateName.Text.Trim()), HttpUtility.HtmlEncode(txtLastDate.Text.Trim()));
            if (success > 0) 
            {
                if (hndLgCasesId.Value == "")
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "showSuccessToast", "showToast('success', 'Cases details is successfully saved.', 'Success');", true);
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "showSuccessToast", "showToast('success', 'Cases details is successfully updated.', 'Success');", true);
                }
                ClearFormData();
                GetLitigationCases(hndWhereCondition.Value);
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "showErrorToast", "showToast('error', 'Due to technical or network connectivity issue.The Cases details is not saved. Please try again later!', 'Error');", true);
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region GetExistingCaseDetails
    protected void txtCaseNo_TextChanged(object sender, EventArgs e)
    {
        try
        {
            DataSet ds = obj.GetLitigationCaseForEdit(Session["EmpCode"].ToString(),"0" ,txtCaseNo.Text.Trim());
            if (ds.Tables[1].Rows.Count > 0)
            {
                hndLgCasesId.Value = HttpUtility.HtmlDecode(ds.Tables[1].Rows[0]["Lg_Cases_Id"].ToString());
                txtCaseNo.Text = HttpUtility.HtmlDecode(ds.Tables[1].Rows[0]["Case_No"].ToString());
                ddlCategory.SelectedValue = HttpUtility.HtmlDecode(ds.Tables[1].Rows[0]["Category"].ToString());
                txtLegalPersonHandling.Text = HttpUtility.HtmlDecode(ds.Tables[1].Rows[0]["Legal_Person_Handling"].ToString());
                ddlInHouseAttend.SelectedValue = HttpUtility.HtmlDecode(ds.Tables[1].Rows[0]["In_House_Req"].ToString());
                txtPurposeFixedFor.Text = HttpUtility.HtmlDecode(ds.Tables[1].Rows[0]["Purpose_Fixed"].ToString());
                txtNextDate.Text = HttpUtility.HtmlDecode(ds.Tables[1].Rows[0]["Next_Date"].ToString());
                ddlPriority.SelectedValue = HttpUtility.HtmlDecode(ds.Tables[1].Rows[0]["Priority"].ToString());
                txtCaseTitle.Text = HttpUtility.HtmlDecode(ds.Tables[1].Rows[0]["Case_Title"].ToString());
                ddlForAgainstDs.SelectedValue = HttpUtility.HtmlDecode(ds.Tables[1].Rows[0]["For_Against_Ds"].ToString());
                txtCourt.Text = HttpUtility.HtmlDecode(ds.Tables[1].Rows[0]["Court"].ToString());
                txtCity.Text = HttpUtility.HtmlDecode(ds.Tables[1].Rows[0]["City"].ToString());
                txtProductProperty.Text = HttpUtility.HtmlDecode(ds.Tables[1].Rows[0]["Product_Property"].ToString());
                txtIssueOffence.Text = HttpUtility.HtmlDecode(ds.Tables[1].Rows[0]["Issue_Offence"].ToString());
                txtAdvocateName.Text = HttpUtility.HtmlDecode(ds.Tables[1].Rows[0]["Advocate_Name"].ToString());
                txtLastDate.Text = HttpUtility.HtmlDecode(ds.Tables[1].Rows[0]["Last_Date"].ToString());
                btnAddUpdateCase.Text = "Update Cases";
                btnAddUpdateCase.ToolTip = "Click here to update selected Cases";
                btnAddUpdateCase.Focus();
            }
            else
            {
                ClearFormData();
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
}