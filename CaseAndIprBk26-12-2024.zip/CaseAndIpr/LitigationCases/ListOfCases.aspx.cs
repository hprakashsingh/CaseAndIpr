﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class LitigationCases_ListOfCases : System.Web.UI.Page
{
    #region DeclareVariable
    LitigationCases obj = new LitigationCases();
    #endregion
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["EmpCode"] != null)
            {
                if (!string.IsNullOrEmpty(Request.QueryString["ReportType"]))
                {
                    hndReportType.Value = CommonUtility.Decryption(HttpUtility.UrlDecode(Request.QueryString["ReportType"].ToString()));
                    hndWhereCondition.Value = hndWhereCondition.Value + " and Priority = '" + hndReportType.Value + "'";
                }
                GetLitigationCases(hndWhereCondition.Value);
            }
        }
    }
    #region GetLitigationCases
    public void GetLitigationCases(string WhereCondition = "")
    {
        try
        {
            if (Session["EmpCode"] != null)
            {
                string empCode = Session["EmpCode"].ToString();
                DataSet ds = obj.GetLitigationCases(empCode, "", WhereCondition);

                if (ds.Tables.Count > 0 && ds.Tables[1].Rows.Count > 0)
                {
                    GrdLitigationCases.DataSource = ds.Tables[1];
                    GrdLitigationCases.DataBind();
                    btnExcelExport.Visible = true;
                }
                else
                {
                    GrdLitigationCases.DataSource = ds.Tables[1];
                    GrdLitigationCases.DataBind();
                    btnExcelExport.Visible = false;
                }
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "Javascript", "javascript:SweetDynamicWrongRedirect('Oops...','Dear user your session has been expired.Please try again later.','Dashboard.aspx'); ", true);
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region ExportDataToExcel
    protected void btnExcelExport_Click(object sender, EventArgs e)
    {
        try
        {
            ExportGridViewToExcel();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region ExportGridViewToExcel
    private void ExportGridViewToExcel()
    {
        Response.Clear();
        Response.Buffer = true;
        Response.AddHeader("content-disposition", "attachment;filename=Litigation_Cases.xls");
        Response.Charset = "";
        Response.ContentType = "application/vnd.ms-excel";

        using (StringWriter sw = new StringWriter())
        {
            HtmlTextWriter hw = new HtmlTextWriter(sw);

            // To Export all pages
            GrdLitigationCases.AllowPaging = false;
            this.GetLitigationCases();

            // This is to ensure that the gridview is formatted correctly in Excel
            GrdLitigationCases.HeaderRow.BackColor = Color.Green;
            GrdLitigationCases.HeaderRow.ForeColor = Color.White;
            GrdLitigationCases.Columns[0].Visible = false;
            foreach (TableCell cell in GrdLitigationCases.HeaderRow.Cells)
            {
                cell.BackColor = GrdLitigationCases.HeaderStyle.BackColor;
                cell.Font.Size = FontUnit.Point(12);
            }
            foreach (GridViewRow row in GrdLitigationCases.Rows)
            {
                row.BackColor = Color.White;
                foreach (TableCell cell in row.Cells)
                {
                    if (row.RowIndex % 2 == 0)
                    {
                        cell.BackColor = Color.White;
                        cell.ForeColor = Color.Black;
                        cell.Font.Size = FontUnit.Point(10);
                    }
                    else
                    {
                        cell.BackColor = System.Drawing.Color.White;
                        cell.ForeColor = Color.Black;
                        cell.Font.Size = FontUnit.Point(10);
                    }

                    // Check if the cell belongs to the "Priority" column
                    if (GrdLitigationCases.HeaderRow.Cells[7].Text == "Priority")
                    {
                        if (cell.Text == "High")
                        {
                            cell.BackColor = Color.Red;
                        }
                        else if (cell.Text == "Medium")
                        {
                            cell.BackColor = Color.Yellow;
                        }
                        else if (cell.Text == "Low")
                        {
                            cell.BackColor = Color.Green;
                        }
                    }
                    cell.CssClass = "textmode";
                }
            }

            GrdLitigationCases.RenderControl(hw);

            // Style to format numbers to text
            string style = @"<style> .textmode { mso-number-format:\@; } </style>";
            Response.Write(style);
            Response.Output.Write(sw.ToString());
            Response.Flush();
            Response.End();
        }
    }
    #endregion
    #region VerifyRenderingInServerForm
    public override void VerifyRenderingInServerForm(Control control)
    {
        // Confirms that an HtmlForm control is rendered for the specified ASP.NET
        // server control at run time. Required for GridView export to Excel
    }
    #endregion
    #region ColorCode
    protected void GrdLitigationCases_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        try
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                TableCell priorityCell = e.Row.Cells[7];
                string Priority = priorityCell.Text;

                if (Priority.Equals("High"))
                {
                    priorityCell.BackColor = Color.Red;
                    priorityCell.ForeColor = Color.Black;
                }
                else if (Priority.Equals("Medium"))
                {
                    priorityCell.BackColor = Color.Yellow;
                    priorityCell.ForeColor = Color.Black;
                }
                else if (Priority.Equals("Low"))
                {
                    priorityCell.BackColor = Color.Green;
                    priorityCell.ForeColor = Color.Black;
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region ClearFilter
    protected void btnViewAll_Click(object sender, EventArgs e)
    {
        try
        {
            txtCaseNo.Text = "";
            ddlCategory.SelectedValue = "";
            ddlPriority.SelectedValue = "";
            hndWhereCondition.Value = "";
            if (Session["EmpCode"] != null)
            {
                GetLitigationCases(hndWhereCondition.Value);
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region SearchCases
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        try
        {
            hndWhereCondition.Value = "";
            if (txtCaseNo.Text.Trim() != "")
            {
                hndWhereCondition.Value = hndWhereCondition.Value + " and lc.Case_No = '" + txtCaseNo.Text.Trim() + "'";
            }
            if (ddlCategory.SelectedValue != "")
            {
                hndWhereCondition.Value = hndWhereCondition.Value + " and Category = '" + ddlCategory.SelectedValue + "'";
            }
            if (ddlPriority.SelectedValue != "")
            {
                hndWhereCondition.Value = hndWhereCondition.Value + " and Priority = '" + ddlPriority.SelectedValue + "'";
            }
            GetLitigationCases(hndWhereCondition.Value);
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
}