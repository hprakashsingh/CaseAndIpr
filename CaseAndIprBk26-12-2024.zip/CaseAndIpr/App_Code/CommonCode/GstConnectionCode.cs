﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Configuration;
using System.Data;
/// <summary>
/// Summary description for GstConnectionCode
/// </summary>
internal class GstConnectionCode
{
    public string strCon;
    public GstConnectionCode()
    {
        strCon = ConfigurationManager.ConnectionStrings["GstDbConnect"].ConnectionString;
    }
    public OracleConnection getConnection()
    {
        OracleConnection dbCon = null;
        try
        {
            dbCon = new OracleConnection(strCon);
            dbCon.Open();
        }
        catch (Exception ex)
        {
            if (dbCon.State != ConnectionState.Open)
            {
                throw new Exception("ConOpenFail");
            }
            throw ex;
        }
        return dbCon;
    }

    /// <summary>
    /// Close DataBase Connection
    /// </summary>
    /// <param name="con">An SqlConnection object</param>
    /// <returns>True, if connection is closed; False, if connection is not closed</returns>
    public bool returnConnection(OracleConnection con)
    {
        if (con != null)
        {
            if (con.State != ConnectionState.Closed)
                con.Close();
            if (con.State == ConnectionState.Closed)
            {
                con = null;
                return true;
            }
            else
                return false;
        }
        else
            return true;
    }
    public void CloseConnection(OracleConnection con)
    {
        if (con != null)
        {
            if (con.State != ConnectionState.Closed)
                con.Close();
            if (con.State == ConnectionState.Closed)
            {
                con = null;
            }
        }
    }
}