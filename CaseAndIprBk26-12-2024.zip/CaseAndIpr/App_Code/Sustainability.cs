﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Sustainability
/// </summary>
public class Sustainability
{
    #region Variable Declaration
    OracleConnection con;
    ConnectionCode sCon;
    OracleCommand cmd;
    #endregion
    #region GetUserDetails
    public DataSet GetUserDetails(string EmpCode)
    {
        DataSet ds = new DataSet();
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    // Query 1 with parameter
                    string query1 = @"select e.BUSS_CODE,e.BD_CODE,e.BUSS_CODE,e.CD_CODE,e.UNIT_CODE,e.LOC_CODE,LOC_DESC,e.Emp_Code,case when e.EXTENSION_NO is null then e.Off_Mobile_No else e.EXTENSION_NO end ExtPhone,
                                    e.Off_Mobile_No,e.Email_Id,INITCAP(e.Employee_Name)Employee_Name,INITcap(hris_get.dept_code(hcf_pkg.dept_code(e.Company,e.Emp_Code)))as Department,
                                    INITCAP(Desig_NM)Desig_NM,
                                    COALESCE(e.CO_REVIEWER, e.Reviewer) AS Hod_Code,INITCAP(e2.Employee_Name) AS Hod_Name, e2.Email_Id AS Hod_Email,
                                    e.FUNC_REPORTG,e.ADMIN_REPORTG,INITCAP(e3.Employee_Name)Functional_Reporting,INITCAP(e4.Employee_Name)Operational_Reporting
                                    from hrm_employee e
                                    LEFT JOIN hrm_employee e2 ON e2.Emp_Code = COALESCE(e.CO_REVIEWER, e.Reviewer)
                                    LEFT JOIN hrm_employee e3 ON e3.Emp_Code = e.FUNC_REPORTG
                                    LEFT JOIN hrm_employee e4 ON e4.Emp_Code = e.ADMIN_REPORTG
                                    left join hrm_Designation deg on deg.Desig_Code = e.Desig_Code
                                    left join hrm_location loc on loc.LOC_CODE = e.LOC_CODE where e.Emp_Code =  '" + EmpCode + "'";
                    OracleDataAdapter adapter1 = new OracleDataAdapter(query1, con);
                    adapter1.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Varchar2).Value = EmpCode;
                    DataTable dataTable1 = new DataTable("Table1");
                    adapter1.Fill(dataTable1);
                    ds.Tables.Add(dataTable1);

                    //// Query 2 with parameter
                    //string query2 = @"SELECT COALESCE(e1.CO_REVIEWER, e1.Reviewer) AS Emp_Code,INITCAP(e2.Employee_Name) AS Employee_Name, e2.Email_Id AS Hod_Email
                    //                FROM hrm_employee e1
                    //                LEFT JOIN hrm_employee e2 ON e2.Emp_Code = COALESCE(e1.CO_REVIEWER, e1.Reviewer)
                    //                WHERE e1.Emp_Code = '" + EmpCode + "'";
                    //OracleDataAdapter adapter2 = new OracleDataAdapter(query2, con);
                    //adapter2.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Varchar2).Value = EmpCode;
                    //DataTable dataTable2 = new DataTable("Table2");
                    //adapter2.Fill(dataTable2);
                    //ds.Tables.Add(dataTable2);

                    //// Query 3 with parameter
                    //string query3 = @"select * from Personel_Mob_Continuation where MOBILE_NO = '" + EmpCode + "'";
                    //OracleDataAdapter adapter3 = new OracleDataAdapter(query3, con);
                    //adapter3.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Varchar2).Value = EmpCode;
                    //DataTable dataTable3 = new DataTable("Table3");
                    //adapter3.Fill(dataTable3);
                    //ds.Tables.Add(dataTable3);
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
}