﻿using Oracle.ManagedDataAccess.Client;
using Oracle.ManagedDataAccess.Types;
using System;
using System.Data;
/// <summary>
/// Summary description for SegregationForm
/// </summary>
public class SegregationForm
{
    #region Variable Declaration
    OracleConnection con;
    ConnectionCode sCon;
    OracleCommand cmd;
    #endregion
    #region AddUpdateProcess
    public int AddUpdateProcess(string EmpCode, string ProcessId, string ProcessName, string Status)
    {
        int success = 0;
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    if (ProcessId == "")
                    {
                        cmd.CommandText = "INSERT INTO Process (ProcessId, Process,Status,Created_By,Created_On)" +
                        " VALUES (Process_ID_Seq.nextval, '" + ProcessName + "', '" + Status + "', '" + EmpCode + "', sysdate)";
                    }
                    else if (ProcessId != "")
                    {
                        cmd.CommandText = @"update Process set Process = '" + ProcessName + "',Status = '" + Status + "',UPDATED_BY = '" + EmpCode + "',UPDATED_ON = sysdate where ProcessId = '" + ProcessId + "'";
                    }
                    cmd.CommandType = CommandType.Text;
                    success = cmd.ExecuteNonQuery();
                    objTrans.Commit();
                }
            }
        }
        catch (Exception ex)
        {
            objTrans.Rollback();
            throw ex;
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return success;
    }
    #endregion
    #region GetProcessList
    public DataSet GetProcessList(string EmpCode, string ProcessId = "0")
    {
        DataSet ds = new DataSet();
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    // Query 1 with parameter
                    string query1 = @"select ProcessId, Process,p.Status,initcap(e.employee_name)CreatedByName,p.Created_By,p.Created_On,p.Updated_On,
                                        initcap(e1.employee_name)UpdatedByName
                                        from Process p left join hrm_employee e on p.Created_By = e.Emp_Code 
                                        left join hrm_employee e1 on p.UPDATED_BY = e1.Emp_Code 
                                        where p.Created_By = '" + EmpCode + "' order by Process";
                    OracleDataAdapter adapter1 = new OracleDataAdapter(query1, con);
                    adapter1.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Varchar2).Value = EmpCode;
                    DataTable dataTable1 = new DataTable("Table1");
                    adapter1.Fill(dataTable1);
                    ds.Tables.Add(dataTable1);

                    //Query 2 with parameter
                    string query2 = @"select ProcessId, Process,Status from Process where ProcessId = '" + ProcessId + "'";
                    OracleDataAdapter adapter2 = new OracleDataAdapter(query2, con);
                    adapter2.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Varchar2).Value = EmpCode;
                    DataTable dataTable2 = new DataTable("Table2");
                    adapter2.Fill(dataTable2);
                    ds.Tables.Add(dataTable2);
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
    #region AddUpdateSubProcess
    public int AddUpdateSubProcess(string EmpCode, string SubProcessId, string ProcessId, string SubProcessName, string Status)
    {
        int success = 0;
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    if (SubProcessId == "")
                    {
                        cmd.CommandText = "INSERT INTO Sub_Process (SubProcessId,ProcessId, Sub_Process,Status,Created_By,Created_On)" +
                        " VALUES (Process_ID_Seq.nextval, '" + ProcessId + "' ,'" + SubProcessName + "', '" + Status + "', '" + EmpCode + "', sysdate)";
                    }
                    else if (SubProcessId != "")
                    {
                        cmd.CommandText = @"update Sub_Process set Sub_Process = '" + SubProcessName + "', ProcessId = '" + ProcessId + "',Status = '" + Status + "',UPDATED_BY = '" + EmpCode + "',UPDATED_ON = sysdate where SubProcessId = '" + SubProcessId + "'";
                    }
                    cmd.CommandType = CommandType.Text;
                    success = cmd.ExecuteNonQuery();
                    objTrans.Commit();
                }
            }
        }
        catch (Exception ex)
        {
            objTrans.Rollback();
            throw ex;
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return success;
    }
    #endregion
    #region GetSubProcessList
    public DataSet GetSubProcessList(string EmpCode, string SubProcessId = "0")
    {
        DataSet ds = new DataSet();
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    // Query 1 with parameter
                    string query1 = @"select SubProcessId,Process,sp.ProcessId, Sub_Process,sp.Status,initcap(e.employee_name)CreatedByName,sp.Created_On,sp.Updated_On,
                                        initcap(e1.employee_name)UpdatedByName
                                        from Sub_Process sp left join Process p on p.ProcessId = sp.ProcessId
                                        left join hrm_employee e on sp.Created_By = e.Emp_Code 
                                        left join hrm_employee e1 on p.UPDATED_BY = e1.Emp_Code 
                                        where sp.Created_By = '" + EmpCode + "' order by Sub_Process";
                    OracleDataAdapter adapter1 = new OracleDataAdapter(query1, con);
                    adapter1.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Varchar2).Value = EmpCode;
                    DataTable dataTable1 = new DataTable("Table1");
                    adapter1.Fill(dataTable1);
                    ds.Tables.Add(dataTable1);

                    //Query 2 with parameter
                    string query2 = @"select SUBPROCESSID,ProcessId,SUB_PROCESS,Status from Sub_Process where SubProcessId = '" + SubProcessId + "'";
                    OracleDataAdapter adapter2 = new OracleDataAdapter(query2, con);
                    adapter2.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Varchar2).Value = EmpCode;
                    DataTable dataTable2 = new DataTable("Table2");
                    adapter2.Fill(dataTable2);
                    ds.Tables.Add(dataTable2);
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
    #region GetMasterData
    public DataSet GetMasterData(string EmpCode, string DeptCode, string ProcessId = "0", string SubProcessId = "0")
    {
        DataSet ds = new DataSet();
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    // Query 1 with parameter
                    string query1 = @"select ProcessId,Process from Process where Status = 'A' and Created_By = '" + EmpCode + "' order by Process";
                    OracleDataAdapter adapter1 = new OracleDataAdapter(query1, con);
                    adapter1.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Varchar2).Value = EmpCode;
                    DataTable dataTable1 = new DataTable("Table1");
                    adapter1.Fill(dataTable1);
                    ds.Tables.Add(dataTable1);

                    //Query 2 with parameter
                    string query2 = @"select EMP_CODE,initcap(EMPLOYEE_NAME || ' (' || Dept_Code || ')')EMPLOYEE_NAME from Hrm_Employee where STATUS in ('C','P','N') and Dept_Code = '" + DeptCode + "' order by EMPLOYEE_NAME";
                    OracleDataAdapter adapter2 = new OracleDataAdapter(query2, con);
                    adapter2.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Varchar2).Value = EmpCode;
                    DataTable dataTable2 = new DataTable("Table2");
                    adapter2.Fill(dataTable2);
                    ds.Tables.Add(dataTable2);

                    //Query 3 with parameter
                    string query3 = @"select * from process_request where PROCESSID = '" + ProcessId + "' and DEPT_CODE = '" + DeptCode + "'";
                    OracleDataAdapter adapter3 = new OracleDataAdapter(query3, con);
                    adapter3.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Varchar2).Value = EmpCode;
                    DataTable dataTable3 = new DataTable("Table3");
                    adapter3.Fill(dataTable3);
                    ds.Tables.Add(dataTable3);

                    //Query 4 with parameter
                    string query4 = @"select * from Sub_process_request where PROCESSID = '" + ProcessId + "' and SUBPROCESSID = '" + SubProcessId + "' and DEPT_CODE = '" + DeptCode + "'";
                    OracleDataAdapter adapter4 = new OracleDataAdapter(query4, con);
                    adapter4.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Varchar2).Value = EmpCode;
                    DataTable dataTable4 = new DataTable("Table4");
                    adapter4.Fill(dataTable4);
                    ds.Tables.Add(dataTable4);

                    //Query 5 with parameter
                    string query5 = @"select case when CO_REVIEWER is null then REVIEWER else Reviewer end as HodCode,
                                    INITCAP((select Employee_Name from hrm_employee where Emp_Code = (SELECT case when CO_REVIEWER is null then REVIEWER end FROM hrm_employee WHERE Emp_Code = '" + EmpCode + "')))HodName from hrm_employee" +
                                    " where emp_code = '" + EmpCode + "'";
                    OracleDataAdapter adapter5 = new OracleDataAdapter(query5, con);
                    adapter5.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Varchar2).Value = EmpCode;
                    DataTable dataTable5 = new DataTable("Table5");
                    adapter5.Fill(dataTable5);
                    ds.Tables.Add(dataTable5);
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
    #region GetCheckerUser
    public DataSet GetCheckerUser(string EmpCode, string DeptCode, string Filter)
    {
        DataSet ds = new DataSet();
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    // Query 1 with parameter
                    string query1 = @"select EMP_CODE,initcap(EMPLOYEE_NAME || ' (' || Dept_Code || ')')EMPLOYEE_NAME from Hrm_Employee 
                                    where STATUS in ('C','P','N') and Dept_Code = '" + DeptCode + "' and EMP_CODE not in " + Filter + " order by EMPLOYEE_NAME";
                    OracleDataAdapter adapter1 = new OracleDataAdapter(query1, con);
                    adapter1.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Varchar2).Value = EmpCode;
                    DataTable dataTable1 = new DataTable("Table1");
                    adapter1.Fill(dataTable1);
                    ds.Tables.Add(dataTable1);
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
    #region GetSubProcess
    public DataSet GetSubProcess(string EmpCode,string ProcessId)
    {
        DataSet ds = new DataSet();
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    // Query 1 with parameter
                    string query1 = @"select SubProcessId,Sub_Process from Sub_Process where Status = 'A' and Created_By = '" + EmpCode + "' " +
                        "and ProcessId = '" + ProcessId + "' order by Sub_Process";
                    OracleDataAdapter adapter1 = new OracleDataAdapter(query1, con);
                    adapter1.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Varchar2).Value = EmpCode;
                    DataTable dataTable1 = new DataTable("Table1");
                    adapter1.Fill(dataTable1);
                    ds.Tables.Add(dataTable1);

                    // Query 2 with parameter
                    //string query2 = @"select case when CO_REVIEWER is not null then CO_REVIEWER else Reviewer end as Emp_Code,
                    //                    INITCAP((select Employee_Name from hrm_employee where Emp_Code = (SELECT case when e1.CO_REVIEWER is not null then e1.CO_REVIEWER else e1.Reviewer
                    //                    end FROM hrm_employee e1 WHERE e1.Emp_Code = '" + EmpCode + "')))Employee_Name from hrm_employee where Emp_Code = '" + EmpCode + "'";
                    //OracleDataAdapter adapter2 = new OracleDataAdapter(query2, con);
                    //adapter2.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Varchar2).Value = EmpCode;
                    //DataTable dataTable2 = new DataTable("Table2");
                    //adapter2.Fill(dataTable2);
                    //ds.Tables.Add(dataTable2);
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
    #region SaveDeptProcessRequest
    public int SaveDeptProcessRequest(string EmpCode, string DeptCode, string ProcessId, string ApprovedBy, OracleConnection con = null, OracleTransaction objTrans = null)
    {
        int success = 0;
        OracleCommand cmd = null;
        try
        {
            using (cmd = con.CreateCommand())
            {
                // Associate the command with the transaction
                cmd.Transaction = objTrans;

                cmd.CommandText = @"INSERT INTO Process_Request (RECID,ProcessId,Dept_Code,Approved_By,Approved_On,STATUS,CREATED_BY,CREATED_ON)
                                             values (Process_ID_Seq.nextval,'" + ProcessId + "','" + DeptCode + "', '" + ApprovedBy + "','','A','" + EmpCode + "',sysdate)";

                cmd.CommandType = CommandType.Text;
                success = cmd.ExecuteNonQuery();
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return success;
    }
    #endregion
    #region SaveDeptSubProcessRequest
    public int SaveDeptSubProcessRequest(string EmpCode, string DeptCode, string ProcessId, string SubProcessId, OracleConnection con = null, OracleTransaction objTrans = null)
    {
        int success = 0;
        OracleCommand cmd = null;
        try
        {
            using (cmd = con.CreateCommand())
            {
                // Associate the command with the transaction
                cmd.Transaction = objTrans;

                cmd.CommandText = @"INSERT INTO Sub_Process_Request (RECID,ProcessId,SubProcessId,Dept_Code,STATUS,CREATED_BY,CREATED_ON)
                                             values (Process_ID_Seq.nextval,'" + ProcessId + "','" + SubProcessId + "','" + DeptCode + "','A','" + EmpCode + "',sysdate)";

                cmd.CommandType = CommandType.Text;
                success = cmd.ExecuteNonQuery();
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return success;
    }
    #endregion
    #region SaveDeptActivity
    public int SaveDeptActivity(string EmpCode, string DeptCode, string ProcessId, string SubProcessId, string Activity, string TeamLeader, OracleConnection con = null, OracleTransaction objTrans = null)
    {
        int success = 0;
        OracleCommand cmd = null;
        try
        {
            using (cmd = con.CreateCommand())
            {
                // Associate the command with the transaction
                cmd.Transaction = objTrans;

                cmd.CommandText = @"INSERT INTO Activity_List (RECID,ProcessId,SubProcessId,Activity,Team_Leader,Dept_Code,STATUS,CREATED_BY,CREATED_ON)
                                             values (Process_ID_Seq.nextval,'" + ProcessId + "','" + SubProcessId + "','" + Activity + "','" + TeamLeader + "'," +
                                                         "'" + DeptCode + "','A','" + EmpCode + "',sysdate)";

                cmd.CommandType = CommandType.Text;
                success = cmd.ExecuteNonQuery();
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return success;
    }
    #endregion
    //#region SaveDeptActivity
    //public int SaveDeptActivity(string EmpCode, string DeptCode, string ProcessId, string SubProcessId, string Activity, string TeamLeader)
    //{
    //    int success = 0;
    //    OracleTransaction objTrans = null;
    //    try
    //    {
    //        sCon = new ConnectionCode();
    //        con = new OracleConnection();
    //        cmd = new OracleCommand();
    //        using (con = sCon.getConnection())
    //        {
    //            objTrans = con.BeginTransaction();
    //            using (cmd = con.CreateCommand())
    //            {
    //                using (cmd = con.CreateCommand())
    //                {
    //                    cmd.CommandText = @"INSERT INTO Activity_List (RECID,ProcessId,SubProcessId,Activity,Team_Leader,Dept_Code,STATUS,CREATED_BY,CREATED_ON)
    //                                         values (Process_ID_Seq.nextval,'" + ProcessId + "','" + SubProcessId + "','" + Activity + "','" + TeamLeader + "'," +
    //                                         "'" + DeptCode + "','A','" + EmpCode + "',sysdate)";

    //                    cmd.CommandType = CommandType.Text;
    //                    success = cmd.ExecuteNonQuery();
    //                    objTrans.Commit();
    //                }
    //            }
    //        }
    //    }
    //    catch (Exception)
    //    {
    //        objTrans.Rollback();
    //    }
    //    finally
    //    {
    //        cmd.Dispose();
    //        sCon = null;
    //    }
    //    return success;
    //}
    //#endregion
    #region GetProcessActivity
    public DataSet GetProcessActivity(string EmpCode,string DepCode, string ProcessId = "0",string SubProcessId = "0")
    {
        DataSet ds = new DataSet();
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    // Query 1 with parameter
                    string query1 = @"select pr.PROCESSID,PROCESS,pr.DEPT_CODE,pr.Approved_By,pr.Approved_On,(e.Email_Id)Creater_Email,initcap(e.Employee_Name)CreatedBy,initcap(e1.Employee_Name)ApprovedBy
                                    from Process_Request pr 
                                    left join Process p on pr.PROCESSID = p.PROCESSID 
                                    left join hrm_employee e on e.Emp_Code = pr.CREATED_BY
                                    left join hrm_employee e1 on e1.Emp_Code = pr.Approved_By 
                                    where (pr.CREATED_BY = '" + EmpCode + "' and pr.DEPT_CODE = '" + DepCode + "') or pr.Approved_By = '"+EmpCode+"'";
                    OracleDataAdapter adapter1 = new OracleDataAdapter(query1, con);
                    adapter1.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Varchar2).Value = EmpCode;
                    DataTable dataTable1 = new DataTable("Table1");
                    adapter1.Fill(dataTable1);
                    ds.Tables.Add(dataTable1);

                    // Query 2 with parameter
                    string query2 = @"select distinct spr.PROCESSID,spr.SUBPROCESSID,SUB_PROCESS from Sub_Process_Request spr
                                    left join Sub_Process sp on spr.SUBPROCESSID = sp.SUBPROCESSID 
                                    where spr.DEPT_CODE = '" + DepCode + "' and spr.PROCESSID = '" + ProcessId + "' order by SUB_PROCESS";
                    OracleDataAdapter adapter2 = new OracleDataAdapter(query2, con);
                    adapter2.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Varchar2).Value = EmpCode;
                    DataTable dataTable2 = new DataTable("Table2");
                    adapter2.Fill(dataTable2);
                    ds.Tables.Add(dataTable2);

                    // Query 3 with parameter
                    string query3 = @"select RECID,ACTIVITY,a.DEPT_CODE,initcap(e.Employee_Name)TEAM_LEADER_Name,
                                    (select LISTAGG(INITCAP(HRIS_GET.EMP_CODE(EMP_CODE)), ', ') WITHIN GROUP (ORDER BY EMP_CODE) from User_List where RECID = a.RECID  and USER_CODE =  'M')MAKER_Name,
                                    (select LISTAGG(INITCAP(HRIS_GET.EMP_CODE(EMP_CODE)), ', ') WITHIN GROUP (ORDER BY EMP_CODE) from User_List where RECID = a.RECID  and USER_CODE =  'C')CHECKER_Name,
                                    (select LISTAGG(INITCAP(HRIS_GET.EMP_CODE(EMP_CODE)), ', ') WITHIN GROUP (ORDER BY EMP_CODE) from User_List where RECID = a.RECID  and USER_CODE =  'A')APPROVER_Name,
                                    (select LISTAGG(INITCAP(HRIS_GET.EMP_CODE(EMP_CODE)), ', ') WITHIN GROUP (ORDER BY EMP_CODE) from User_List where RECID = a.RECID  and USER_CODE =  'CD')CUSTODIAN_Name 
                                    from Activity_List a
                                    left join hrm_employee e on e.Emp_Code = a.TEAM_LEADER
                                    where a.DEPT_CODE = '" + DepCode + "' and a.PROCESSID = '" + ProcessId + "' and a.SUBPROCESSID = '" + SubProcessId + "' order by ACTIVITY";
                    OracleDataAdapter adapter3 = new OracleDataAdapter(query3, con);
                    adapter3.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Varchar2).Value = EmpCode;
                    DataTable dataTable3 = new DataTable("Table3");
                    adapter3.Fill(dataTable3);
                    ds.Tables.Add(dataTable3);

                    // Query 4 with parameter
                    string query4 = @"SELECT APPROVAL_ID,ha.DEPT_CODE,HOD_STATUS,HOD_CODE,HOD_APPROVAL_DATE,initcap(e.Employee_Name)ApprovedBy,initcap(e1.Employee_Name)CreatedBy
                                    FROM Hod_Approval_SEGREGATION ha
                                    left join hrm_employee e on e.Emp_Code = ha.HOD_CODE
                                    left join hrm_employee e1 on e1.Emp_Code = ha.CREATED_BY
                                    WHERE ha.DEPT_CODE = '" + DepCode + "' AND " +
                                    "APPROVAL_ID = (SELECT MAX(APPROVAL_ID) FROM Hod_Approval_SEGREGATION WHERE DEPT_CODE = '" + DepCode + "')";
                    OracleDataAdapter adapter4 = new OracleDataAdapter(query4, con);
                    adapter4.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Varchar2).Value = EmpCode;
                    DataTable dataTable4 = new DataTable("Table4");
                    adapter4.Fill(dataTable4);
                    ds.Tables.Add(dataTable4);
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
    #region GetActivityMaxId
    public DataSet GetActivityMaxId(string EmpCode, OracleConnection con, OracleTransaction objTrans)
    {
        DataSet ds = new DataSet();
        OracleCommand cmd = null;
        try
        {
            using (cmd = con.CreateCommand())
            {
                // Associate the command with the transaction
                cmd.Transaction = objTrans;

                // Query 0 with parameter
                string query1 = @"select max(RecId)MaxId from Activity_List";
                OracleDataAdapter adapter1 = new OracleDataAdapter(query1, con);
                adapter1.SelectCommand.Transaction = objTrans;
                DataTable dataTable1 = new DataTable("Table1");
                adapter1.Fill(dataTable1);
                ds.Tables.Add(dataTable1);
            }
        }
        catch (Exception ex)
        {
            // Handle exception
            throw ex;
        }
        finally
        {
            cmd.Dispose();
        }
        return ds;
    }
    #endregion
    #region SaveUserList
    public int SaveUserList(string EmpCode, string RecId, string UserCode, string Flag,OracleConnection con = null, OracleTransaction objTrans = null)
    {
        int success = 0;
        OracleCommand cmd = null;
        try
        {
            using (cmd = con.CreateCommand())
            {
                // Associate the command with the transaction
                cmd.Transaction = objTrans;

                cmd.CommandText = @"INSERT INTO User_List (USER_ID,RECID,USER_CODE,EMP_CODE)
                                             values (Process_ID_Seq.nextval,'" + RecId + "','" + Flag + "','" + UserCode + "')";

                cmd.CommandType = CommandType.Text;
                success = cmd.ExecuteNonQuery();
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return success;
    }
    #endregion
    #region GetSegregationActivityList
    public DataSet GetSegregationActivityList(string EmpCode,string RecId)
    {
        DataSet ds = new DataSet();
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    cmd.CommandText = @"select RECID,ACTIVITY,a.DEPT_CODE,a.PROCESSID,PROCESS,a.SUBPROCESSID,SUB_PROCESS,a.TEAM_LEADER,initcap(e.Employee_Name)TEAM_LEADER_Name,
                                    (select LISTAGG(INITCAP(HRIS_GET.EMP_CODE(EMP_CODE)), ', ') WITHIN GROUP (ORDER BY EMP_CODE) from User_List where RECID = a.RECID  and USER_CODE =  'M')MAKER_Name,
                                    (select LISTAGG(INITCAP(HRIS_GET.EMP_CODE(EMP_CODE)), ', ') WITHIN GROUP (ORDER BY EMP_CODE) from User_List where RECID = a.RECID  and USER_CODE =  'C')CHECKER_Name,
                                    (select LISTAGG(INITCAP(HRIS_GET.EMP_CODE(EMP_CODE)), ', ') WITHIN GROUP (ORDER BY EMP_CODE) from User_List where RECID = a.RECID  and USER_CODE =  'A')APPROVER_Name,
                                    (select LISTAGG(INITCAP(HRIS_GET.EMP_CODE(EMP_CODE)), ', ') WITHIN GROUP (ORDER BY EMP_CODE) from User_List where RECID = a.RECID  and USER_CODE =  'CD')CUSTODIAN_Name
                                    from Activity_List a
                                    left join hrm_employee e on e.Emp_Code = a.TEAM_LEADER
                                    left join Process p on p.PROCESSID = a.PROCESSID
                                    left join Sub_Process Sp on sp.SUBPROCESSID = a.SUBPROCESSID where RECID = '" + RecId + "'";
                    cmd.CommandType = CommandType.Text;
                    using (OracleDataAdapter da = new OracleDataAdapter(cmd))
                    {
                        da.Fill(ds);
                        objTrans.Commit();
                    }
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
    #region GetSelectedUserList
    public DataSet GetSelectedUserList(string EmpCode, string Dept, string RecId, string Flag)
    {
        DataSet ds = new DataSet();
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    cmd.CommandText = @"select USER_ID,RECID,USER_CODE,u.EMP_CODE,initcap(Employee_Name)Employee_Name from User_List u
                                        left join hrm_employee e on e.Emp_Code = u.Emp_Code where RECID = '" + RecId + "' and USER_CODE = '" + Flag + "' and u.STATUS = 'A' ";
                    cmd.CommandType = CommandType.Text;
                    using (OracleDataAdapter da = new OracleDataAdapter(cmd))
                    {
                        da.Fill(ds);
                        objTrans.Commit();
                    }
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
    #region UpdateProcessActivity
    public int UpdateProcessActivity(string EmpCode, string RecId, string Activity, string TeamLeader)
    {
        int success = 0;
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    using (cmd = con.CreateCommand())
                    {
                        cmd.CommandText = @"update Activity_List set ACTIVITY = '" + Activity + "', TEAM_LEADER = '" + TeamLeader + "' where RECID = '" + RecId + "' ";

                        cmd.CommandType = CommandType.Text;
                        success = cmd.ExecuteNonQuery();
                        objTrans.Commit();
                    }
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return success;
    }
    #endregion
    #region DeleteProcessId
    public int DeleteProcessId(string EmpCode, string RecId)
    {
        int success = 0;
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    using (cmd = con.CreateCommand())
                    {
                        cmd.CommandText = @"delete User_List where RECID = '" + RecId + "' ";

                        cmd.CommandType = CommandType.Text;
                        success = cmd.ExecuteNonQuery();
                        objTrans.Commit();
                    }
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return success;
    }
    #endregion
    #region SentSegregationForApproval
    public int SentSegregationForApproval(string EmpCode, string DeptCode, string HodCode, string Status)
    {
        int success = 0;
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    cmd.CommandText = "INSERT INTO Hod_Approval_SEGREGATION (Approval_Id, Dept_Code,Hod_Code,HOD_STATUS,Created_By,Created_On)" +
                        " VALUES (Process_ID_Seq.nextval, '" + DeptCode + "', '" + HodCode + "' ,'" + Status + "', '" + EmpCode + "', sysdate)";
                    cmd.CommandType = CommandType.Text;
                    success = cmd.ExecuteNonQuery();
                    objTrans.Commit();
                }
            }
        }
        catch (Exception ex)
        {
            objTrans.Rollback();
            throw ex;
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return success;
    }
    #endregion
    #region ApproveRejectSegregationOfDuties
    public int ApproveRejectSegregationOfDuties(string EmpCode, string DeptCode, string Remarks, string Status)
    {
        int success = 0;
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    using (cmd = con.CreateCommand())
                    {
                        cmd.CommandText = @"update Hod_Approval_SEGREGATION set Hod_Status = '" + Status + "',Hod_Approval_Date = sysdate," +
                            "Hod_Remarks = '" + Remarks + "' where Dept_Code = '" + DeptCode + "' and Hod_Status = 'Pending'";
                        cmd.CommandType = CommandType.Text;
                        success = cmd.ExecuteNonQuery();
                        objTrans.Commit();
                    }
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
            //throw e;
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return success;
    }
    #endregion
}