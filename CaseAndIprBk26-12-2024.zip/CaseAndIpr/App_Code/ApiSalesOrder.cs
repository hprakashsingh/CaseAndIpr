﻿using DocumentFormat.OpenXml.Bibliography;
using DocumentFormat.OpenXml.Spreadsheet;
using Oracle.ManagedDataAccess.Client;
using Org.BouncyCastle.Asn1.Ocsp;
using System;
using System.Data;
using System.IdentityModel.Protocols.WSTrust;

/// <summary>
/// Summary description for ApiSalesOrder
/// </summary>
public class ApiSalesOrder
{
    #region Variable Declaration
    OracleConnection con;
    GstConnectionCode sCon;
    OracleCommand cmd;
    #endregion
    #region GetSalesOrderData
    public DataSet GetSalesOrderData(string EmpCode,string WhereCondition)
    {
        DataSet ds = new DataSet();
        OracleTransaction objTrans = null;
        try
        {
            sCon = new GstConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    // Query 0 with parameter
                    string query1 = @"SELECT ASO_RECID,SAP_INVOICE_NO,(SELECT BILL_CUSTOMERNAME FROM API_CUSTOMERS WHERE ORDERID =  A.ORDERID)CUSTOMER_NAME,
                                    (SELECT BILL_PHONENUMBER FROM API_CUSTOMERS WHERE ORDERID =  A.ORDERID) MOBILE_NO, ORDERID, ORDERDATE, CUSTOMERID,
                                    (POSNR)SEQ_NO, PRODUCTID, QUANTITY, PRICE, COD, CREATED_ON, SHIPPING_CHARGES FROM API_SALE_ORDERS A
                                    WHERE INVOICE_NO IS NULL
                                    " + WhereCondition + " ORDER BY ORDERID,POSNR";
                    OracleDataAdapter adapter1 = new OracleDataAdapter(query1, con);
                    adapter1.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Int32).Value = EmpCode;
                    DataTable dataTable1 = new DataTable("Table1");
                    adapter1.Fill(dataTable1);
                    ds.Tables.Add(dataTable1);
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
    #region UpdateSalesOrderStatus
    public int UpdateSalesOrderStatus(string EmpCode, string ASO_RECID, string Status, OracleConnection con, OracleTransaction objTrans)
    {
        int success = 0;
        OracleCommand cmd = null;
        try
        {
            using (cmd = con.CreateCommand())
            {
                // Associate the command with the transaction
                cmd.Transaction = objTrans;

                cmd.CommandText = @"update API_SALE_ORDERS set SAP_INVOICE_NO = '" + Status + "',LAST_UPD_BY = '" + EmpCode + "',LAST_UPD_ON = sysdate" +
                        " where ASO_RECID = '" + ASO_RECID + "'";
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.Add(new OracleParameter { ParameterName = "EmpCode", DbType = DbType.String, Value = EmpCode });
                cmd.Parameters.Add(new OracleParameter { ParameterName = "ASO_RECID", DbType = DbType.String, Value = ASO_RECID });
                cmd.Parameters.Add(new OracleParameter { ParameterName = "Status", DbType = DbType.String, Value = Status });
                success = cmd.ExecuteNonQuery();
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return success;
    }
    #endregion
    #region GetDashboardData
    public DataSet GetDashboardData(string EmpCode)
    {
        DataSet ds = new DataSet();
        OracleTransaction objTrans = null;
        try
        {
            sCon = new GstConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    // Query 0 with parameter
                    string query1 = @"select count(*)TotalOrder from API_SALE_ORDERS
                                    union all
                                    select count(*)TotalActiveOrder from API_SALE_ORDERS WHERE SAP_INVOICE_NO IS  NULL AND INVOICE_NO IS NULL
                                    union all
                                    select count(*)TotalInActiveOrder from API_SALE_ORDERS WHERE SAP_INVOICE_NO ='INACTIVE'";
                    OracleDataAdapter adapter1 = new OracleDataAdapter(query1, con);
                    adapter1.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Int32).Value = EmpCode;
                    DataTable dataTable1 = new DataTable("Table1");
                    adapter1.Fill(dataTable1);
                    ds.Tables.Add(dataTable1);
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
}