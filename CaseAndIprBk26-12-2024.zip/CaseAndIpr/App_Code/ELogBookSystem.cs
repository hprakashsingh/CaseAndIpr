﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for ELogBookSystem
/// </summary>
public class ELogBookSystem
{
    #region VariableDeclaration
    OracleConnection con;
    ConnectionCode sCon;
    OracleCommand cmd;
    #endregion
    #region GetProductName
    public DataSet GetProductName(string EmpCode, string ProductName = "")
    {
        DataSet ds = new DataSet();
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    // Query 0 with parameter
                    string query1 = @"select distinct(PRODUCT_NAME)ProductName from eLogBook_Master_Data order by PRODUCT_NAME ";
                    OracleDataAdapter adapter1 = new OracleDataAdapter(query1, con);
                    //adapter1.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Int32).Value = EmpCode;
                    DataTable dataTable1 = new DataTable("Table1");
                    adapter1.Fill(dataTable1);
                    ds.Tables.Add(dataTable1);

                    // Query 1 with parameter
                    string query2 = @"select ID,PRODUCT_NAME,TEST_PARAMETER,RAW_DATA,STATUS,SEQ_NO,CREATED_ON,UPDATED_BY,UPDATED_ON 
                                    from eLogBook_Master_Data where PRODUCT_NAME = '" + ProductName + "' order by ID ";
                    OracleDataAdapter adapter2 = new OracleDataAdapter(query2, con);
                    //adapter1.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Int32).Value = EmpCode;
                    DataTable dataTable2 = new DataTable("Table2");
                    adapter2.Fill(dataTable2);
                    ds.Tables.Add(dataTable2);

                    //// Query 2 with parameter
                    //string query3 = @"select Lg_Cases_Id,Category,Legal_Person_Handling,In_House_Req,Next_Date,Purpose_Fixed,Priority,Case_Title,For_Against_Ds,Court,City,
                    //                Product_Property,Issue_Offence,Advocate_Name,lc.Status,lc.Created_By,lc.Created_On,Case_No,Last_Date,lc.Updated_By,lc.Updated_On,
                    //                initcap(e.Employee_Name)CreatedByName,
                    //                initcap(e1.Employee_Name)UpdatedByName
                    //                from Lg_Litigation_Cases lc
                    //                left join Hrm_Employee e on e.Emp_Code = lc.Created_By
                    //                left join Hrm_Employee e1 on e1.Emp_Code = lc.Updated_By where Case_No = '" + CaseNo + "' order by 1 desc";
                    //OracleDataAdapter adapter3 = new OracleDataAdapter(query3, con);
                    ////adapter1.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Int32).Value = EmpCode;
                    //DataTable dataTable3 = new DataTable("Table3");
                    //adapter3.Fill(dataTable3);
                    //ds.Tables.Add(dataTable3);
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
            // throw e;
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
}