﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Data;

/// <summary>
/// Summary description for LitigationCases
/// </summary>
public class LitigationCases
{
    #region VariableDeclaration
    OracleConnection con;
    ConnectionCode sCon;
    OracleCommand cmd;
    #endregion
    #region GetLitigationCases
    public DataSet GetLitigationCases(string EmpCode,string CurrentDate = "",string WhereCondition = "")
    {
        DataSet ds = new DataSet();
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    // Query 0 with parameter
                    string query1 = @"select (TRUNC(SYSDATE) - INTERVAL '4' DAY)MinDays,(TRUNC(SYSDATE) + INTERVAL '3' DAY)MaxDays,Lg_Cases_Id,Category,Legal_Person_Handling,In_House_Req,Next_Date,Purpose_Fixed,Priority,Case_Title,For_Against_Ds,Court,City,
                                    Product_Property,Issue_Offence,Advocate_Name,lc.Status,lc.Created_By,lc.Created_On,Case_No,Last_Date,lc.Updated_By,lc.Updated_On,
                                    initcap(e.Employee_Name)CreatedByName,
                                    initcap(e1.Employee_Name)UpdatedByName
                                    from Lg_Litigation_Cases lc
                                    left join Hrm_Employee e on e.Emp_Code = lc.Created_By
                                    left join Hrm_Employee e1 on e1.Emp_Code = lc.Updated_By where lc.STATUS = 'A'
                                    AND TO_DATE(Next_Date, 'DD-MM-YYYY') BETWEEN TRUNC(SYSDATE) - INTERVAL '4' DAY AND
                                    TRUNC(SYSDATE) + INTERVAL '3' DAY
                                    order by 1";
                    OracleDataAdapter adapter1 = new OracleDataAdapter(query1, con);
                    //adapter1.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Int32).Value = EmpCode;
                    DataTable dataTable1 = new DataTable("Table1");
                    adapter1.Fill(dataTable1);
                    ds.Tables.Add(dataTable1);

                    // Query 1 with parameter
                    string query2 = @"WITH CaseCount AS (
                                    SELECT
                                        Case_No,
                                        COUNT(*) AS Case_Count
                                    FROM
                                        Lg_Litigation_Cases

                                    GROUP BY
                                        Case_No

                                )
                                SELECT
                                    lc.Lg_Cases_Id,lc.Category,lc.Legal_Person_Handling,lc.In_House_Req,lc.Next_Date,lc.Purpose_Fixed,lc.Priority,lc.Case_Title,lc.For_Against_Ds, lc.Court, lc.City,
                                    lc.Product_Property,lc.Issue_Offence,lc.Advocate_Name,lc.Status,lc.Created_By,lc.Created_On,lc.Case_No,lc.Last_Date,lc.Updated_By,lc.Updated_On,
                                    initcap(e.Employee_Name) AS CreatedByName,initcap(e1.Employee_Name) AS UpdatedByName,nvl(cc.Case_Count,0)Case_Count
                                FROM
                                    Lg_Litigation_Cases lc
                                LEFT JOIN
                                    Hrm_Employee e ON e.Emp_Code = lc.Created_By
                                LEFT JOIN
                                    Hrm_Employee e1 ON e1.Emp_Code = lc.Updated_By
                                LEFT JOIN
                                    CaseCount cc ON lc.Case_No = cc.Case_No
                                WHERE
                                    lc.STATUS = 'A'
                                    " + WhereCondition + " ORDER BY 1 desc"; ;
                    OracleDataAdapter adapter2 = new OracleDataAdapter(query2, con);
                    //adapter1.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Int32).Value = EmpCode;
                    DataTable dataTable2 = new DataTable("Table2");
                    adapter2.Fill(dataTable2);
                    ds.Tables.Add(dataTable2);

                    // Query 2 with parameter
                    string query3 = @"select count(*)Counter from Lg_Mail_Log where trunc(CREATED_ON) = to_date('" + CurrentDate + "','dd/MM/yyyy') ";
                    OracleDataAdapter adapter3 = new OracleDataAdapter(query3, con);
                    //adapter1.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Int32).Value = EmpCode;
                    DataTable dataTable3 = new DataTable("Table3");
                    adapter3.Fill(dataTable3);
                    ds.Tables.Add(dataTable3);

                    // Query 3 with parameter
                    string query4 = @"select count(*)TotalCases from Lg_Litigation_Cases where STATUS = 'A'
                                    union all
                                    select count(*)LowPriorityCases from Lg_Litigation_Cases where STATUS = 'A' and upper(PRIORITY) = 'LOW'
                                    union all
                                    select count(*)MediumPriorityCases from Lg_Litigation_Cases where STATUS = 'A' and upper(PRIORITY) = 'MEDIUM'
                                    union all
                                    select count(*)HighPriorityCases from Lg_Litigation_Cases where STATUS = 'A' and upper(PRIORITY) = 'HIGH'";
                    OracleDataAdapter adapter4 = new OracleDataAdapter(query4, con);
                    //adapter1.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Int32).Value = EmpCode;
                    DataTable dataTable4 = new DataTable("Table4");
                    adapter4.Fill(dataTable4);
                    ds.Tables.Add(dataTable4);
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
            // throw e;
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
    #region GetLitigationCaseForEdit
    public DataSet GetLitigationCaseForEdit(string EmpCode, string LgCasesId,string CaseNo = "")
    {
        DataSet ds = new DataSet();
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    // Query 0 with parameter
                    string query1 = @"select Lg_Cases_Id,Category,Legal_Person_Handling,In_House_Req,Next_Date,Purpose_Fixed,Priority,Case_Title,For_Against_Ds,Court,City,
                                    Product_Property,Issue_Offence,Advocate_Name,lc.Status,lc.Created_By,lc.Created_On,Case_No,Last_Date,lc.Updated_By,lc.Updated_On,
                                    initcap(e.Employee_Name)CreatedByName,
                                    initcap(e1.Employee_Name)UpdatedByName
                                    from Lg_Litigation_Cases lc
                                    left join Hrm_Employee e on e.Emp_Code = lc.Created_By
                                    left join Hrm_Employee e1 on e1.Emp_Code = lc.Updated_By where lc.STATUS = 'A'
                                    AND LG_CASES_ID = '" + LgCasesId + "'";
                    OracleDataAdapter adapter1 = new OracleDataAdapter(query1, con);
                    //adapter1.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Int32).Value = EmpCode;
                    DataTable dataTable1 = new DataTable("Table1");
                    adapter1.Fill(dataTable1);
                    ds.Tables.Add(dataTable1);

                    // Query 1 with parameter
                    string query2 = @"select Lg_Cases_Id,Category,Legal_Person_Handling,In_House_Req,Next_Date,Purpose_Fixed,Priority,Case_Title,For_Against_Ds,Court,City,
                                    Product_Property,Issue_Offence,Advocate_Name,lc.Status,lc.Created_By,lc.Created_On,Case_No,Last_Date,lc.Updated_By,lc.Updated_On,
                                    initcap(e.Employee_Name)CreatedByName,
                                    initcap(e1.Employee_Name)UpdatedByName
                                    from Lg_Litigation_Cases lc
                                    left join Hrm_Employee e on e.Emp_Code = lc.Created_By
                                    left join Hrm_Employee e1 on e1.Emp_Code = lc.Updated_By where lc.STATUS = 'A'
                                    AND Case_No = '" + CaseNo + "'";
                    OracleDataAdapter adapter2 = new OracleDataAdapter(query2, con);
                    //adapter1.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Int32).Value = EmpCode;
                    DataTable dataTable2 = new DataTable("Table2");
                    adapter2.Fill(dataTable2);
                    ds.Tables.Add(dataTable2);

                    // Query 2 with parameter
                    string query3 = @"select Lg_Cases_Id,Category,Legal_Person_Handling,In_House_Req,Next_Date,Purpose_Fixed,Priority,Case_Title,For_Against_Ds,Court,City,
                                    Product_Property,Issue_Offence,Advocate_Name,lc.Status,lc.Created_By,lc.Created_On,Case_No,Last_Date,lc.Updated_By,lc.Updated_On,
                                    initcap(e.Employee_Name)CreatedByName,
                                    initcap(e1.Employee_Name)UpdatedByName
                                    from Lg_Litigation_Cases lc
                                    left join Hrm_Employee e on e.Emp_Code = lc.Created_By
                                    left join Hrm_Employee e1 on e1.Emp_Code = lc.Updated_By where Case_No = '" + CaseNo + "' order by 1 desc";
                    OracleDataAdapter adapter3 = new OracleDataAdapter(query3, con);
                    //adapter1.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Int32).Value = EmpCode;
                    DataTable dataTable3 = new DataTable("Table3");
                    adapter3.Fill(dataTable3);
                    ds.Tables.Add(dataTable3);
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
            // throw e;
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
    #region SaveMailLog
    public int SaveMailLog(string EmpCode, string FromEmail, string ToEmail, string CcEmail, string Alert_Type)
    {
        int success = 0;

        try
        {
            using (OracleConnection con = new ConnectionCode().getConnection())
            {
                using (OracleCommand cmd = con.CreateCommand())
                {
                    cmd.CommandText = "INSERT INTO Lg_Mail_Log (MAIL_LOG_ID, FROM_EMAIL, TO_MAIL, CC_MAIL, ALERT_TYPE, CREATED_BY, CREATED_ON)" +
                        " VALUES (Lg_Cases_ID_Seq.nextval, '" + FromEmail + "', '" + ToEmail + "', '" + CcEmail + "', '" + Alert_Type + "', '" + EmpCode + "', sysdate)";

                    cmd.Parameters.Add(new OracleParameter { ParameterName = "EmpCode", DbType = DbType.String, Value = EmpCode });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "FromEmail", DbType = DbType.String, Value = FromEmail });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "ToEmail", DbType = DbType.String, Value = ToEmail });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "CcEmail", DbType = DbType.String, Value = CcEmail });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "Alert_Type", DbType = DbType.String, Value = Alert_Type });

                    success = cmd.ExecuteNonQuery();
                }
            }
        }
        catch (Exception ex)
        {
            // Log the exception or handle it appropriately
            throw;
        }

        return success;
    }

    #endregion
    #region AddUpdateCases
    public int AddUpdateCases(string empCode, string LgCasesId, string CaseNo, string Category, string LegalPersonHandling, string InHouseAttend,
        string PurposeFixedFor, string NextDate, string Priority, string CaseTitle, string ForAgainstDs, string Court, string City, string ProductProperty,
        string IssueOffence, string AdvocateName, string LastDate)
    {
        int success = 0;
        OracleTransaction objTrans = null;
        try
        {
            using (OracleConnection con = new ConnectionCode().getConnection())
            {
                objTrans = con.BeginTransaction();

                if (CaseNo != "" && LgCasesId != "")
                {
                    // Update the first table
                    using (OracleCommand cmd = con.CreateCommand())
                    {
                        cmd.CommandText = @"UPDATE Lg_Litigation_Cases SET Status = 'I', UPDATED_BY = '" + empCode + "', UPDATED_ON = sysdate " +
                                            "WHERE CASE_NO = '" + CaseNo + "' and LG_CASES_ID = '" + LgCasesId + "' ";

                        // Use distinct parameter names to avoid conflicts
                        cmd.Parameters.Add(new OracleParameter { ParameterName = "empCode", DbType = DbType.String, Value = empCode });

                        success = cmd.ExecuteNonQuery();
                    }
                }
                // Update the second table
                using (OracleCommand cmd2 = con.CreateCommand())
                {
                    cmd2.Transaction = objTrans;
                    cmd2.CommandText = @"INSERT INTO Lg_Litigation_Cases (
                                                Lg_Cases_Id, Category, Legal_Person_Handling, In_House_Req, Next_Date, Purpose_Fixed,
                                                Priority, Case_No, Case_Title, For_Against_Ds, Court,
                                                City, Product_Property, Issue_Offence, Last_Date, Advocate_Name, Status,
                                                Created_By, Created_On
                                            ) VALUES  (Lg_Cases_ID_Seq.nextval, '" + Category + "', '" + LegalPersonHandling + "', '" + InHouseAttend + "', " +
                                            "'" + NextDate + "', '" + PurposeFixedFor + "', '" + Priority + "', '" + CaseNo + "', '" + CaseTitle + "', '" + ForAgainstDs + "'," +
                                            " '" + Court + "', '" + City + "', '" + ProductProperty + "', '" + IssueOffence + "', '" + LastDate + "', '" + AdvocateName + "'," +
                                            " 'A', '" + empCode + "', sysdate)";

                    // Add parameters for the second command if needed
                    cmd2.Parameters.Add(new OracleParameter { ParameterName = "empCode", DbType = DbType.String, Value = empCode });

                    success += cmd2.ExecuteNonQuery();
                }
                objTrans.Commit();
            }
        }
        catch (Exception ex)
        {
            objTrans.Rollback();
        }

        return success;
    }
    #endregion
}