﻿using DocumentFormat.OpenXml;
using Oracle.ManagedDataAccess.Client;
using Oracle.ManagedDataAccess.Types;
using System;
using System.Data;

/// <summary>
/// Summary description for ExternalMailRegister
/// </summary>
public class ExternalMailRegister
{
    #region Variable Declaration
    OracleConnection con;
    ConnectionCode sCon;
    OracleCommand cmd;
    #endregion
    #region GetDocumentNo
    public DataSet GetDocumentNo(string EmpCode)
    {
        DataSet ds = new DataSet();
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    // Query 0 with parameter
                    string query1 = @"select EMP_CODE,UNIT_CODE, hris_get.func_code(e.func_code) func_code_desc,CD_CODE,ADMIN_REPORTG,FUNC_REPORTG,MOBILE_NO,
                                    (select SBU_CODE from  oc_sbu_mapping where ou_code=E.company and rownum=1)  BUSS_CODE,
                                    (select ENTITY_CODE from  oc_sbu_mapping where ou_code=E.company and rownum=1) ENTITY_CODE,
                                    FUNC_CODE, EUIN_CODE,(select max(FISCAL_YEAR) from fiscal_years  where company = '55' and status= 'O') FYEAR,
                                     (select lpad(nvl(max(substr(Document_No,length(Document_No)-2,length(Document_No))) +1,1),4,'0') from Extenal_Mail_Register) MAX_NO
                                     from hrm_employee E where emp_code='" + EmpCode + "' and status in ('C','P','N')";
                    OracleDataAdapter adapter1 = new OracleDataAdapter(query1, con);
                    //adapter1.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Int32).Value = EmpCode;
                    DataTable dataTable1 = new DataTable("Table1");
                    adapter1.Fill(dataTable1);
                    ds.Tables.Add(dataTable1);
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
            // throw e;
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
    #region GetSenderName
    public DataSet GetSenderName(string EmpCode)
    {
        DataSet ds = new DataSet();
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    cmd.CommandText = @"select EMP_CODE,initcap(EMPLOYEE_NAME || ' (' || Emp_Code || ')')EMPLOYEE_NAME from Hrm_Employee where STATUS in ('C','P','N') order by EMPLOYEE_NAME";
                    cmd.CommandType = CommandType.Text;
                    using (OracleDataAdapter da = new OracleDataAdapter(cmd))
                    {
                        da.Fill(ds);
                        objTrans.Commit();
                    }
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
            // throw e;
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
    #region GetDepartment
    public DataSet GetDepartment(string EmpCode, string SelectedEmployeeCode = "0")
    {
        DataSet ds = new DataSet();
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    // Query 1 with parameter
                    string query1 = @"select distinct DESCRIPTION from hrm_Department where Status = 'A'  order by DESCRIPTION";
                    OracleDataAdapter adapter1 = new OracleDataAdapter(query1, con);
                    adapter1.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Varchar2).Value = EmpCode;
                    DataTable dataTable1 = new DataTable("Table1");
                    adapter1.Fill(dataTable1);
                    ds.Tables.Add(dataTable1);

                    //Query 2 with parameter
                    string query2 = @"select distinct DESCRIPTION from hrm_Department where DEPT_CODE in (select DEPT_CODE from hrm_employee where Emp_Code = '" + SelectedEmployeeCode + "')";
                    OracleDataAdapter adapter2 = new OracleDataAdapter(query2, con);
                    adapter2.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Varchar2).Value = EmpCode;
                    DataTable dataTable2 = new DataTable("Table2");
                    adapter2.Fill(dataTable2);
                    ds.Tables.Add(dataTable2);

                    ////Query 3 with parameter
                    //string query3 = @"select * from process_request where PROCESSID = '" + ProcessId + "' and DEPT_CODE = '" + DeptCode + "'";
                    //OracleDataAdapter adapter3 = new OracleDataAdapter(query3, con);
                    //adapter3.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Varchar2).Value = EmpCode;
                    //DataTable dataTable3 = new DataTable("Table3");
                    //adapter3.Fill(dataTable3);
                    //ds.Tables.Add(dataTable3);

                    ////Query 4 with parameter
                    //string query4 = @"select * from Sub_process_request where PROCESSID = '" + ProcessId + "' and SUBPROCESSID = '" + SubProcessId + "' and DEPT_CODE = '" + DeptCode + "'";
                    //OracleDataAdapter adapter4 = new OracleDataAdapter(query4, con);
                    //adapter4.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Varchar2).Value = EmpCode;
                    //DataTable dataTable4 = new DataTable("Table4");
                    //adapter4.Fill(dataTable4);
                    //ds.Tables.Add(dataTable4);
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
    #region GetExtenalMailRegister
    public DataSet GetExtenalMailRegister(string EmpCode,string RequestType)
    {
        DataSet ds = new DataSet();
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    cmd.CommandText = @"select Document_No,REC_ID,REQUEST_TYPE,DATES,initcap(em.EMPLOYEE_NAME)EMPLOYEE_NAME,DEPARTMENT,RECEIVER_NAME,DESTINATION,COURIER_POST,RECEIPT_NUMBER,TIME_IN,TIME_OUT,DOCUMENT_PARCEL,
                                        WEIGHT,em.STATUS,REMARKS,Amount,em.CREATED_BY,(initcap(e.EMPLOYEE_NAME))CreatedByName,em.CREATED_ON
                                        from Extenal_Mail_Register em
                                        left join hrm_Employee e on e.Emp_Code = em.CREATED_BY where REQUEST_TYPE = '" + RequestType + "' order by Rec_Id Desc";
                    cmd.CommandType = CommandType.Text;
                    using (OracleDataAdapter da = new OracleDataAdapter(cmd))
                    {
                        da.Fill(ds);
                        objTrans.Commit();
                    }
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
            // throw e;
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
    #region SaveExternalMailRegister
    public int SaveExternalMailRegister(
        string EmpCode, string DocumentNo, string dateValue, string EmployeeName, string Department,
        string ReceiverName, string Destination, string CourierPost, string ReceiptNo,
        string TimeIn, string TimeOut, string DocumentParcel, string Weight, string Amount,
        string Remarks, string RequestType, string Status)
    {
        int success = 0;

        try
        {
            sCon = new ConnectionCode();
            using (OracleConnection con = sCon.getConnection())
            using (OracleTransaction objTrans = con.BeginTransaction())
            using (OracleCommand cmd = con.CreateCommand())
            {
                cmd.CommandText = @"INSERT INTO Extenal_Mail_Register 
            (REC_ID, Document_No, REQUEST_TYPE, DATES, EMPLOYEE_NAME, DEPARTMENT, RECEIVER_NAME, DESTINATION, 
             COURIER_POST, RECEIPT_NUMBER, TIME_IN, TIME_OUT, DOCUMENT_PARCEL, WEIGHT, STATUS, AMOUNT, REMARKS, 
             CREATED_BY, CREATED_ON) 
            VALUES 
            (External_Mail_ID_Seq.NEXTVAL, :DocumentNo, :RequestType, :DateValue, :EmployeeName, :Department, 
             :ReceiverName, :Destination, :CourierPost, :ReceiptNo, :TimeIn, :TimeOut, :DocumentParcel, 
             :Weight, :Status, :AmountValue, :Remarks, :EmpCode, SYSDATE)";
                cmd.CommandType = CommandType.Text;
                cmd.Transaction = objTrans;

                // Adding parameters with explicit types
                cmd.Parameters.Add(new OracleParameter("DocumentNo", OracleDbType.Varchar2) { Value = DocumentNo });
                cmd.Parameters.Add(new OracleParameter("RequestType", OracleDbType.Varchar2) { Value = RequestType });
                cmd.Parameters.Add(new OracleParameter("DateValue", OracleDbType.Varchar2) { Value = dateValue });
                cmd.Parameters.Add(new OracleParameter("EmployeeName", OracleDbType.Varchar2) { Value = EmployeeName });
                cmd.Parameters.Add(new OracleParameter("Department", OracleDbType.Varchar2) { Value = Department });
                cmd.Parameters.Add(new OracleParameter("ReceiverName", OracleDbType.Varchar2) { Value = ReceiverName });
                cmd.Parameters.Add(new OracleParameter("Destination", OracleDbType.Varchar2) { Value = Destination });
                cmd.Parameters.Add(new OracleParameter("CourierPost", OracleDbType.Varchar2) { Value = CourierPost });
                cmd.Parameters.Add(new OracleParameter("ReceiptNo", OracleDbType.Varchar2) { Value = ReceiptNo });
                cmd.Parameters.Add(new OracleParameter("TimeIn", OracleDbType.Varchar2) { Value = TimeIn });
                cmd.Parameters.Add(new OracleParameter("TimeOut", OracleDbType.Varchar2) { Value = TimeOut });
                cmd.Parameters.Add(new OracleParameter("DocumentParcel", OracleDbType.Varchar2) { Value = DocumentParcel });
                cmd.Parameters.Add(new OracleParameter("Weight", OracleDbType.Varchar2) { Value = Weight });
                cmd.Parameters.Add(new OracleParameter("Status", OracleDbType.Varchar2) { Value = Status });
                cmd.Parameters.Add(new OracleParameter("AmountValue", OracleDbType.Varchar2) { Value = Amount });
                cmd.Parameters.Add(new OracleParameter("Remarks", OracleDbType.Varchar2) { Value = Remarks });
                cmd.Parameters.Add(new OracleParameter("EmpCode", OracleDbType.Varchar2) { Value = EmpCode });

                // Execute command
                success = cmd.ExecuteNonQuery();
                objTrans.Commit();
            }
        }
        catch (Exception ex)
        {
            // Log the exception (replace with your logging mechanism)
            throw new Exception("Error while saving external mail register", ex);
        }

        return success;
    }
    #endregion
    #region GetUserDetails
    public DataSet GetUserDetails(string EmpCode)
    {
        DataSet ds = new DataSet();
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    // Query 1 with parameter
                    string query1 = @"select BUSS_CODE,CD_CODE,UNIT_CODE,e.LOC_CODE,LOC_DESC,Emp_Code,case when EXTENSION_NO is null then Off_Mobile_No else EXTENSION_NO end ExtPhone,
                                    Off_Mobile_No,Email_Id,INITCAP(Employee_Name)Employee_Name,INITcap(hris_get.dept_code(hcf_pkg.dept_code(e.Company,e.Emp_Code)))as Department,
                                    INITCAP(Desig_NM)Desig_NM from hrm_employee e
                                    inner join hrm_Designation deg on deg.Desig_Code = e.Desig_Code
                                    inner join hrm_location loc on loc.LOC_CODE = e.LOC_CODE where e.Emp_Code =  '" + EmpCode + "'";
                    OracleDataAdapter adapter1 = new OracleDataAdapter(query1, con);
                    adapter1.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Varchar2).Value = EmpCode;
                    DataTable dataTable1 = new DataTable("Table1");
                    adapter1.Fill(dataTable1);
                    ds.Tables.Add(dataTable1);

                    // Query 2 with parameter
                    string query2 = @"SELECT COALESCE(e1.CO_REVIEWER, e1.Reviewer) AS Emp_Code,INITCAP(e2.Employee_Name) AS Employee_Name, e2.Email_Id AS Hod_Email
                                    FROM hrm_employee e1
                                    LEFT JOIN hrm_employee e2 ON e2.Emp_Code = COALESCE(e1.CO_REVIEWER, e1.Reviewer)
                                    WHERE e1.Emp_Code = '" + EmpCode + "'";
                    OracleDataAdapter adapter2 = new OracleDataAdapter(query2, con);
                    adapter2.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Varchar2).Value = EmpCode;
                    DataTable dataTable2 = new DataTable("Table2");
                    adapter2.Fill(dataTable2);
                    ds.Tables.Add(dataTable2);

                    // Query 3 with parameter
                    string query3 = @"select * from Personel_Mob_Continuation where MOBILE_NO = '" + EmpCode + "'";
                    OracleDataAdapter adapter3 = new OracleDataAdapter(query3, con);
                    adapter3.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Varchar2).Value = EmpCode;
                    DataTable dataTable3 = new DataTable("Table3");
                    adapter3.Fill(dataTable3);
                    ds.Tables.Add(dataTable3);
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
    #region GetDsDocumnetNo
    public DataSet GetDsDocumnetNo(string EmpCode)
    {
        DataSet ds = new DataSet();
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    cmd.CommandText = "select EMP_CODE,UNIT_CODE, hris_get.func_code(e.func_code) func_code_desc,CD_CODE,ADMIN_REPORTG,FUNC_REPORTG,MOBILE_NO,(select SBU_CODE from  oc_sbu_mapping where ou_code=E.company and rownum=1)  BUSS_CODE,(select ENTITY_CODE from  oc_sbu_mapping where ou_code=E.company and rownum=1) ENTITY_CODE,FUNC_CODE, EUIN_CODE,(select max(FISCAL_YEAR) from fiscal_years  where company = '55' and status= 'O') FYEAR, (select lpad(nvl(max(substr(DOCUMENT_NO,length(DOCUMENT_NO)-2,length(DOCUMENT_NO))) +1,1),3,'0') from Pl_InternetAccess) MAX_NO from hrm_employee E where emp_code='" + EmpCode + "' and status in ('C','P','N')";
                    cmd.CommandType = CommandType.Text;
                    using (OracleDataAdapter da = new OracleDataAdapter(cmd))
                    {
                        da.Fill(ds);
                        objTrans.Commit();
                    }
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
            // throw e;
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
    #region GetMobileDocumnetNo
    public DataSet GetMobileDocumnetNo(string EmpCode)
    {
        DataSet ds = new DataSet();
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    cmd.CommandText = @"select EMP_CODE,UNIT_CODE, hris_get.func_code(e.func_code) func_code_desc,CD_CODE,ADMIN_REPORTG,FUNC_REPORTG,MOBILE_NO,
                                        (select SBU_CODE from  oc_sbu_mapping where ou_code=E.company and rownum=1)  BUSS_CODE,
                                        (select ENTITY_CODE from  oc_sbu_mapping where ou_code=E.company and rownum=1) ENTITY_CODE,FUNC_CODE, EUIN_CODE,
                                        (select max(FISCAL_YEAR) from fiscal_years  where company = '55' and status= 'O') FYEAR, 
                                        (select lpad(nvl(max(substr(DOCUMENT_NO,length(DOCUMENT_NO)-2,length(DOCUMENT_NO))) +1,1),3,'0') from Personel_Mob_Continuation) MAX_NO 
                                        from hrm_employee E where emp_code='" + EmpCode + "' and status in ('C','P','N')";
                    cmd.CommandType = CommandType.Text;
                    using (OracleDataAdapter da = new OracleDataAdapter(cmd))
                    {
                        da.Fill(ds);
                        objTrans.Commit();
                    }
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
            // throw e;
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
    #region SaveMobileNoContinuation
    public int SaveMobileNoContinuation(string EmpCode, string DocumentNo, string HodeCode, string AdministarationCode, string MobileNo)
    {
        int success = 0;
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    using (cmd = con.CreateCommand())
                    {
                        cmd.CommandText = @"insert into Personel_Mob_Continuation(ID,DOCUMENT_NO,EMP_CODE,MOBILE_NO,STATUS,HOD,HOD_STATUS,ADMINISTRATION,ADMINISTRATION_STATUS,CREATED_BY,CREATED_ON)
                        values (Mob_Continuation_ID_Seq.NEXTVAL, '" + DocumentNo + "', '" + EmpCode + "', '" + MobileNo + "','Submitted', '" + HodeCode + "', " +
                        "'Pending', '" + AdministarationCode + "', '-' ,'" + EmpCode + "',sysdate)";
                        cmd.CommandType = CommandType.Text;
                        success = cmd.ExecuteNonQuery();
                        objTrans.Commit();
                    }
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
            //throw e;
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return success;
    }
    #endregion
    #region GetListOfMobileNumberContinuation
    public DataSet GetListOfMobileNumberContinuation(string EmpCode, string ID = "0")
    {
        DataSet ds = new DataSet();
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    cmd.CommandText = @"select ID,DOCUMENT_NO,pmc.EMP_CODE,pmc.MOBILE_NO,pmc.STATUS,pmc.HOD,(initcap(e1.Employee_Name))Hod_Name,HOD_STATUS,HOD_APPROVAL_DATE,
                                        ADMINISTRATION,(initcap(e2.Employee_Name))ADMINISTRATION_Name,ADMINISTRATION_STATUS,ADMINISTRATION_APPROVAL_DATE,
                                        pmc.CREATED_BY,(initcap(e.Employee_Name))Created_By_Name,pmc.CREATED_ON,pmc.UPDATED_BY,pmc.UPDATED_ON
                                        from Personel_Mob_Continuation pmc
                                        left join hrm_Employee e on e.Emp_Code = pmc.CREATED_BY
                                        left join hrm_Employee e1 on e1.Emp_Code = pmc.HOD
                                        left join hrm_Employee e2 on e2.Emp_Code = pmc.ADMINISTRATION 
                                        where (pmc.EMP_CODE = '" + EmpCode + "' or  pmc.HOD = '" + EmpCode + "' or pmc.ADMINISTRATION = '" + EmpCode + "') order by ID desc";
                    cmd.CommandType = CommandType.Text;
                    using (OracleDataAdapter da = new OracleDataAdapter(cmd))
                    {
                        da.Fill(ds);
                        objTrans.Commit();
                    }
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
            // throw e;
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
    #region GetMobileRequest
    public DataSet GetMobileRequest(string EmpCode, string RequestId)
    {
        DataSet ds = new DataSet();
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    // Query 1 with parameter
                    string query1 = @"select DOCUMENT_NO,p.MOBILE_NO,INITCAP(e1.Employee_Name)Hod_Name,(e1.Email_Id)Hod_Email,p.HOD,p.HOD_STATUS,p.HOD_APPROVAL_DATE,INITCAP(e2.Employee_Name)Admin_Name,(e2.Email_Id)Admin_Email,
                                    ADMINISTRATION,ADMINISTRATION_STATUS,ADMINISTRATION_APPROVAL_DATE,e.EMP_CODE,e.BUSS_CODE,e.CD_CODE,e.UNIT_CODE,e.LOC_CODE,LOC_DESC,
                                    case when e.EXTENSION_NO is null then e.Off_Mobile_No else e.EXTENSION_NO end ExtPhone,e.Off_Mobile_No,e.Email_Id,INITCAP(Desig_NM)Desig_NM,
                                    INITCAP(e.Employee_Name)Employee_Name,INITcap(hris_get.dept_code(hcf_pkg.dept_code(e.Company,e.Emp_Code)))as Department,p.CREATED_ON,
                                    nvl(HOD_REMARKS,'-')HOD_REMARKS,nvl(ADMIN_REMARKS,'-')ADMIN_REMARKS
                                    from Personel_Mob_Continuation p
                                     left join hrm_employee e on e.EMP_CODE = p.EMP_CODE
                                     left join hrm_employee e1 on e1.EMP_CODE = p.HOD
                                     left join hrm_employee e2 on e2.EMP_CODE = p.ADMINISTRATION
                                     left join hrm_Designation deg on deg.Desig_Code = e.Desig_Code
                                     left join hrm_location loc on loc.LOC_CODE = e.LOC_CODE where p.Id = '" + RequestId + "'";
                    OracleDataAdapter adapter1 = new OracleDataAdapter(query1, con);
                    adapter1.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Varchar2).Value = EmpCode;
                    DataTable dataTable1 = new DataTable("Table1");
                    adapter1.Fill(dataTable1);
                    ds.Tables.Add(dataTable1);

                    //// Query 2 with parameter
                    //string query2 = @"select case when CO_REVIEWER is not null then CO_REVIEWER else Reviewer end as Emp_Code,
                    //                    INITCAP((select Employee_Name from hrm_employee where Emp_Code = (SELECT case when e1.CO_REVIEWER is not null then e1.CO_REVIEWER else e1.Reviewer
                    //                    end FROM hrm_employee e1 WHERE e1.Emp_Code = '" + EmpCode + "')))Employee_Name from hrm_employee where Emp_Code = '" + EmpCode + "'";
                    //OracleDataAdapter adapter2 = new OracleDataAdapter(query2, con);
                    //adapter2.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Varchar2).Value = EmpCode;
                    //DataTable dataTable2 = new DataTable("Table2");
                    //adapter2.Fill(dataTable2);
                    //ds.Tables.Add(dataTable2);

                    //// Query 3 with parameter
                    //string query3 = @"select * from Personel_Mob_Continuation where MOBILE_NO = '" + EmpCode + "'";
                    //OracleDataAdapter adapter3 = new OracleDataAdapter(query3, con);
                    //adapter3.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Varchar2).Value = EmpCode;
                    //DataTable dataTable3 = new DataTable("Table3");
                    //adapter3.Fill(dataTable3);
                    //ds.Tables.Add(dataTable3);
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
    #region ApproveRejectRequest
    public int ApproveRejectRequest(string EmpCode, string RequestId, string Remarks, string Status, string ActionUserType)
    {
        int success = 0;
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    using (cmd = con.CreateCommand())
                    {
                        if (ActionUserType.Equals("Hod"))
                        {
                            if (Status.Equals("Reject"))
                            {
                                cmd.CommandText = @"update Personel_Mob_Continuation set HOD_STATUS = '" + Status + "',STATUS = '" + Status + "',HOD_REMARKS = '" + Remarks + "',HOD_APPROVAL_DATE = sysdate,UPDATED_BY = '" + EmpCode + "',UPDATED_ON = sysdate where ID = '" + RequestId + "'";
                            }
                            else if (Status.Equals("Approved"))
                            {
                                cmd.CommandText = @"update Personel_Mob_Continuation set HOD_STATUS = '" + Status + "',HOD_REMARKS = '" + Remarks + "',HOD_APPROVAL_DATE = sysdate,UPDATED_BY = '" + EmpCode + "',ADMINISTRATION_STATUS = 'Pending',UPDATED_ON = sysdate where ID = '" + RequestId + "'";
                            }
                        }
                        else if (ActionUserType.Equals("Admin"))
                        {
                            cmd.CommandText = @"update Personel_Mob_Continuation set ADMINISTRATION_STATUS = '" + Status + "',STATUS = '" + Status + "',ADMIN_REMARKS = '" + Remarks + "',ADMINISTRATION_APPROVAL_DATE = sysdate,UPDATED_BY = '" + EmpCode + "',UPDATED_ON = sysdate where ID = '" + RequestId + "'";
                        }
                        cmd.CommandType = CommandType.Text;
                        success = cmd.ExecuteNonQuery();
                        objTrans.Commit();
                    }
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
            //throw e;
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return success;
    }
    #endregion
}