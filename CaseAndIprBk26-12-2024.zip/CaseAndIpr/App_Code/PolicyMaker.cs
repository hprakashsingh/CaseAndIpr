﻿using Oracle.ManagedDataAccess.Client;
using Oracle.ManagedDataAccess.Types;
using System;
using System.Activities.Statements;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Web;
using System.Web.UI.WebControls;

/// <summary>
/// Summary description for PolicyMaker
/// </summary>
public class PolicyMaker
{
    #region Variable Declaration
    OracleConnection con;
    ConnectionCode sCon;
    OracleCommand cmd;
    #endregion
    #region CheckUserLink
    public DataSet CheckUserLink(string EmpCode)
    {
        DataSet ds = new DataSet();
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    cmd.CommandText = "select Emp_Code from hrm_Employee where Email_Id = '" + EmpCode + "'";
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "@EmpCode", DbType = DbType.String, Value = EmpCode });
                    using (OracleDataAdapter da = new OracleDataAdapter(cmd))
                    {
                        da.Fill(ds);
                        objTrans.Commit();
                    }
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
    #region GetUserDetailsForLogin
    public DataSet GetUserDetailsForLogin(string UserId,string RequestId = "")
    {
        DataSet ds = new DataSet();
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    // Query 1 with parameter
                    string query1 = @"select e.Emp_Code,INITCAP(e.Employee_Name)Employee_Name,Email_ID,(e.REVIEWER)Func_Reportg,
                                    (SELECT INITCAP(e1.Employee_Name) FROM hrm_employee e1 WHERE e1.Emp_Code = e.REVIEWER)HodName,
                                    INITcap(hris_get.dept_code(hcf_pkg.dept_code(e.company,e.REVIEWER)))HodDepartment,
                                    (SELECT e11.Email_ID FROM hrm_employee e11 WHERE e11.Emp_Code = (SELECT e1.REVIEWER FROM hrm_employee e1 WHERE e1.Emp_Code = '" + UserId + "' and e1.STATUS in ('C','P','N')))HodEmail," +
                                    "case when (select EMP_CODE from hod_list where SPOC_CODE = e.Emp_Code) is null then Emp_Code else " +
                                    "(select EMP_CODE from hod_list where SPOC_CODE = e.Emp_Code) end MappingCode from hrm_employee e where Emp_Code = '" + UserId + "' and STATUS in ('C','P','N')";
                    OracleDataAdapter adapter1 = new OracleDataAdapter(query1, con);
                    //adapter1.SelectCommand.Parameters.Add("@UserId", OracleDbType.Int32).Value = UserId;
                    DataTable dataTable1 = new DataTable("Table1");
                    adapter1.Fill(dataTable1);
                    ds.Tables.Add(dataTable1);

                    // Query 2 with parameter
                    string query2 = @"select FORM_TYPE from pl_InternetAccess where REQUEST_ID = '" + RequestId + "'";
                    OracleDataAdapter adapter2 = new OracleDataAdapter(query2, con);
                    adapter2.SelectCommand.Parameters.Add("@RequestId", OracleDbType.Int32).Value = RequestId;
                    DataTable dataTable2 = new DataTable("Table2");
                    adapter2.Fill(dataTable2);
                    ds.Tables.Add(dataTable2);

                    // Query 3 with parameter
                    string query3 = @"select e.Emp_Code,INITCAP(e.Employee_Name)Employee_Name,Email_ID,(e.REVIEWER)Func_Reportg,
                                    (SELECT INITCAP(e1.Employee_Name) FROM hrm_employee e1 WHERE e1.Emp_Code = e.REVIEWER)HodName,
                                    INITcap(hris_get.dept_code(hcf_pkg.dept_code(e.company,e.REVIEWER)))HodDepartment,
                                    (SELECT e11.Email_ID FROM hrm_employee e11 WHERE e11.Emp_Code = (SELECT e1.REVIEWER FROM hrm_employee e1 WHERE e1.Emp_Code = '" + UserId + "'))HodEmail," +
                                    "case when (select EMP_CODE from hod_list where SPOC_CODE = e.Emp_Code) is null then Emp_Code else " +
                                    "(select EMP_CODE from hod_list where SPOC_CODE = e.Emp_Code) end MappingCode from hrm_employee e where Emp_Code = '" + UserId + "'";
                    OracleDataAdapter adapter3 = new OracleDataAdapter(query3, con);
                    adapter3.SelectCommand.Parameters.Add("@UserId", OracleDbType.Int32).Value = UserId;
                    DataTable dataTable3 = new DataTable("Table3");
                    adapter3.Fill(dataTable3);
                    ds.Tables.Add(dataTable3);
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
            // throw e;
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
    #region GetUserDetails
    public DataSet GetUserDetails(string EmpCode)
    {
        DataSet ds = new DataSet();
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    cmd.CommandText = "select Emp_Code,case when EXTENSION_NO is null then Off_Mobile_No else EXTENSION_NO end ExtPhone,Off_Mobile_No,Email_Id,INITCAP(Employee_Name)Employee_Name,INITcap(hris_get.dept_code(hcf_pkg.dept_code(e.Company,e.Emp_Code)))as Department,(SELECT e2.Employee_Name FROM hrm_employee e2 where e2.emp_Code in (SELECT e1.Func_Reportg FROM hrm_employee e1 WHERE e1.Emp_Code = '" + EmpCode + "'))HodName,INITCAP(Desig_NM)Desig_NM from hrm_employee e inner join hrm_Designation deg on deg.Desig_Code = e.Desig_Code where e.Emp_Code = '" + EmpCode + "'";
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "@EmpCode", DbType = DbType.String, Value = EmpCode });
                    using (OracleDataAdapter da = new OracleDataAdapter(cmd))
                    {
                        da.Fill(ds);
                        objTrans.Commit();
                    }
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
    #region GetUserApprovalList
    public DataSet GetUserApprovalList(string EmpCode)
    {
        DataSet ds = new DataSet();
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    cmd.CommandText = "select case when CO_REVIEWER is not null then CO_REVIEWER else Reviewer end as Emp_Code," +
                        "INITCAP((select Employee_Name from hrm_employee where Emp_Code = (SELECT case when e1.CO_REVIEWER is not null then e1.CO_REVIEWER else e1.Reviewer end FROM hrm_employee e1 WHERE e1.Emp_Code = '" + EmpCode + "')))Employee_Name," +
                        "1 as level_Id from hrm_employee where Emp_Code = '"+EmpCode+ "' union all select am.Emp_Code,INITCAP(e1.Employee_Name)Employee_Name,am.Level_Id from PL_APPROVALMAPPING am left Join hrm_employee e1 on e1.Emp_Code = am.Emp_Code where am.Level_Id in (2,3,4,5,6)";
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "@EmpCode", DbType = DbType.String, Value = EmpCode });
                    using (OracleDataAdapter da = new OracleDataAdapter(cmd))
                    {
                        da.Fill(ds);
                        objTrans.Commit();
                    }
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
    #region GetMaxRequestId
    public DataSet GetMaxRequestId()
    {
        DataSet ds = new DataSet();
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    // cmd.CommandText = "PL_Usp_GetUserDetails";
                    //cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "select max(REQUEST_ID)REQUEST_ID from Pl_InternetAccess";
                    cmd.CommandType = CommandType.Text;
                    //cmd.Parameters.Add(new OracleParameter { ParameterName = "@EmpCode", DbType = DbType.String, Value = EmpCode });
                    using (OracleDataAdapter da = new OracleDataAdapter(cmd))
                    {
                        da.Fill(ds);
                        objTrans.Commit();
                    }
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
            // throw e;
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
    #region GeDsDocumnetNo
    public DataSet GeDsDocumnetNo(string EmpCode)
    {
        DataSet ds = new DataSet();
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    cmd.CommandText = "select EMP_CODE,UNIT_CODE, hris_get.func_code(e.func_code) func_code_desc,CD_CODE,ADMIN_REPORTG,FUNC_REPORTG,MOBILE_NO,(select SBU_CODE from  oc_sbu_mapping where ou_code=E.company and rownum=1)  BUSS_CODE,(select ENTITY_CODE from  oc_sbu_mapping where ou_code=E.company and rownum=1) ENTITY_CODE,FUNC_CODE, EUIN_CODE,(select max(FISCAL_YEAR) from fiscal_years  where company = '55' and status= 'O') FYEAR, (select lpad(nvl(max(substr(DOCUMENT_NO,length(DOCUMENT_NO)-2,length(DOCUMENT_NO))) +1,1),3,'0') from Pl_InternetAccess) MAX_NO from hrm_employee E where emp_code='"+ EmpCode + "' and status in ('C','P','N')";
                    cmd.CommandType = CommandType.Text;
                    using (OracleDataAdapter da = new OracleDataAdapter(cmd))
                    {
                        da.Fill(ds);
                        objTrans.Commit();
                    }
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
            // throw e;
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
    #region SaveInternetAccessRequest
    public int SaveInternetAccessRequest(string EmpCode,string FormType ,string InternetAccessList, string SpecificWebsiteList, 
        string ValidityPeriodFrom,string ValidityPeriodTo,string SpecificTime,string AdditionalComment,string DocumentNo,string RequestId)
    {
        int success = 0;
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                //objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    cmd.CommandText = "INSERT INTO Pl_InternetAccess (DOCUMENT_NO,EMP_CODE,FORM_TYPE,INTERNET_ACCESSTYPE,WEBSITE_CATEGORY, " +
                        "VALIDITY_FROM,VALIDITY_TO,REQ_SPECIFICTIME,ADDITIONAL_COMMENTS,STATUS_ID,CREATED_BY,STATUS)" +
                        "values ('" + DocumentNo + "','"+EmpCode+"','"+ FormType + "','"+ InternetAccessList + "','"+ SpecificWebsiteList + "'," +
                        "'"+ ValidityPeriodFrom + "','"+ ValidityPeriodTo + "','"+ SpecificTime + "','"+ AdditionalComment + "','6','"+ EmpCode + "','A')";
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "EmpCode", DbType = DbType.String, Value = EmpCode });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "FormType", DbType = DbType.String, Value = FormType });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "InternetAccessList", DbType = DbType.String, Value = InternetAccessList });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "SpecificWebsiteList", DbType = DbType.String, Value = SpecificWebsiteList });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "ValidityPeriodFrom", DbType = DbType.String, Value = ValidityPeriodFrom });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "ValidityPeriodTo", DbType = DbType.String, Value = ValidityPeriodTo });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "SpecificTime", DbType = DbType.String, Value = SpecificTime });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "AdditionalComment", DbType = DbType.String, Value = AdditionalComment });
                    success = cmd.ExecuteNonQuery();
                    objTrans.Commit();
                }
            }
        }
        catch (Exception ex)
        {
            objTrans.Rollback();
            //throw ex;
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return success;
    }
    #endregion
    #region SaveExternalStorageDeviceRequestt
    public int SaveExternalStorageDeviceRequestt(string EmpCode,string FormType,string ValidityPeriodFrom, string ValidityPeriodTo, string Purpose,string documentNo,
        string RequestType,string TypeOfDevices,string AccessUSBdevice,string JustificationForAccess,string DeviceInformation)
    {
        int success = 0;
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    using (cmd = con.CreateCommand())
                    {
                        cmd.CommandText = "INSERT INTO Pl_InternetAccess (DOCUMENT_NO,EMP_CODE,FORM_TYPE,VALIDITY_FROM,VALIDITY_TO,ADDITIONAL_COMMENTS,STATUS_ID,CREATED_BY,STATUS,INTERNET_ACCESSTYPE,REQ_SPECIFICTIME,REQUEST_TYPE," +
                            "DEVICEACCESS_TYPE,ACCESSUSB_DEVICE,JUSTIFICATIONFOR_FULLACCESS,DEVICE_INFORMATION)" +
                                "values ('" + documentNo + "','" + EmpCode + "','" + FormType + "','" + ValidityPeriodFrom + "','" + ValidityPeriodTo + "','" + Purpose + "','6','" + EmpCode + "','A','Na','Na','"+ RequestType + "','"+ TypeOfDevices + "','"+ AccessUSBdevice + "','"+ JustificationForAccess + "','"+ DeviceInformation + "')";
                        cmd.CommandType = CommandType.Text;
                        cmd.Parameters.Add(new OracleParameter { ParameterName = "EmpCode", DbType = DbType.String, Value = EmpCode });
                        cmd.Parameters.Add(new OracleParameter { ParameterName = "FormType", DbType = DbType.String, Value = FormType });
                        cmd.Parameters.Add(new OracleParameter { ParameterName = "ValidityPeriodFrom", DbType = DbType.String, Value = ValidityPeriodFrom });
                        cmd.Parameters.Add(new OracleParameter { ParameterName = "ValidityPeriodTo", DbType = DbType.String, Value = ValidityPeriodTo });
                        cmd.Parameters.Add(new OracleParameter { ParameterName = "Purpose", DbType = DbType.String, Value = Purpose });
                        cmd.Parameters.Add(new OracleParameter { ParameterName = "documentNo", DbType = DbType.String, Value = documentNo });
                        cmd.Parameters.Add(new OracleParameter { ParameterName = "RequestType", DbType = DbType.String, Value = RequestType });
                        cmd.Parameters.Add(new OracleParameter { ParameterName = "TypeOfDevices", DbType = DbType.String, Value = TypeOfDevices });
                        cmd.Parameters.Add(new OracleParameter { ParameterName = "AccessUSBdevice", DbType = DbType.String, Value = AccessUSBdevice });
                        cmd.Parameters.Add(new OracleParameter { ParameterName = "JustificationForAccess", DbType = DbType.String, Value = JustificationForAccess });
                        cmd.Parameters.Add(new OracleParameter { ParameterName = "DeviceInformation", DbType = DbType.String, Value = DeviceInformation });
                        success = cmd.ExecuteNonQuery();
                        objTrans.Commit();
                    }
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
            //throw e;
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return success;
    }
    #endregion
    #region GetListOfPolicyRequest
    public DataSet GetListOfPolicyRequest(string EmpCode,string DocumentType)
    {
        DataSet ds = new DataSet();
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    if (DocumentType.Equals("My Request"))
                    {
                        cmd.CommandText = @"select (SELECT INITCAP(e1.Employee_Name) FROM hrm_employee e1 WHERE e1.Emp_Code = (select Emp_Code from Pl_APPROVALREQUEST where REQUEST_ID = IA.REQUEST_ID and LEVEL_ID = 1))HodName,IA.REQUEST_ID,IA.DOCUMENT_NO,IA.FORM_TYPE,IA.EMP_CODE,IA.INTERNET_ACCESSTYPE,TO_DATE(Ia.Validity_From, 'YYYY-MM-DD')VALIDITY_FROM,TO_DATE(Ia.VALIDITY_TO, 'YYYY-MM-DD')VALIDITY_TO,IA.REQ_SPECIFICTIME,IA.CREATED_BY,e.Employee_Name as RequestorName,IA.CREATED_ON,IA.STATUS_ID,s.Status_Name,INITcap(hris_get.dept_code(hcf_pkg.dept_code(e.Company,IA.Emp_Code)))as Department from Pl_InternetAccess IA left join hrm_employee e on IA.Emp_Code = e.Emp_Code left join PL_STATUS s on s.Status_Id = IA.Status_Id where IA.STATUS not in ('I') and IA.Emp_Code = '" + EmpCode + "' order by IA.CREATED_ON desc";
                    }
                    else if (DocumentType.Equals("Pending Request"))
                    {
                        cmd.CommandText = @"select (SELECT INITCAP(e1.Employee_Name) FROM hrm_employee e1 WHERE e1.Emp_Code = (select Emp_Code from Pl_APPROVALREQUEST where REQUEST_ID = IA.REQUEST_ID and LEVEL_ID = 1))HodName,IA.REQUEST_ID,IA.DOCUMENT_NO,IA.FORM_TYPE,IA.EMP_CODE,IA.INTERNET_ACCESSTYPE,TO_DATE(Ia.Validity_From, 'YYYY-MM-DD')VALIDITY_FROM,TO_DATE(Ia.VALIDITY_TO, 'YYYY-MM-DD')VALIDITY_TO,IA.REQ_SPECIFICTIME,IA.CREATED_BY,e.Employee_Name as RequestorName,IA.CREATED_ON,IA.STATUS_ID,s.Status_Name,INITcap(hris_get.dept_code(hcf_pkg.dept_code(e.Company,IA.Emp_Code)))as Department from Pl_InternetAccess IA left join hrm_employee e on IA.Emp_Code = e.Emp_Code left join PL_STATUS s on s.Status_Id = IA.Status_Id where IA.STATUS not in ('I') and Request_Id in (select Request_Id from PL_APPROVALREQUEST where PL_APPROVALREQUEST.Emp_Code = '" + EmpCode + "'  and Status_Id = 3) and Ia.Status_Id = 6 order by IA.CREATED_ON desc";
                    }
                    else if (DocumentType.Equals("Approved Request"))
                    {
                        cmd.CommandText = @"select (SELECT INITCAP(e1.Employee_Name) FROM hrm_employee e1 WHERE e1.Emp_Code = (select Emp_Code from Pl_APPROVALREQUEST where REQUEST_ID = IA.REQUEST_ID and LEVEL_ID = 1))HodName,IA.REQUEST_ID,IA.DOCUMENT_NO,IA.FORM_TYPE,IA.EMP_CODE,IA.INTERNET_ACCESSTYPE,TO_DATE(Ia.Validity_From, 'YYYY-MM-DD')VALIDITY_FROM,TO_DATE(Ia.VALIDITY_TO, 'YYYY-MM-DD')VALIDITY_TO,IA.REQ_SPECIFICTIME,IA.CREATED_BY,e.Employee_Name as RequestorName,IA.CREATED_ON,IA.STATUS_ID,s.Status_Name,INITcap(hris_get.dept_code(hcf_pkg.dept_code(e.Company,IA.Emp_Code)))as Department from Pl_InternetAccess IA left join hrm_employee e on IA.Emp_Code = e.Emp_Code left join PL_STATUS s on s.Status_Id = IA.Status_Id where IA.STATUS not in ('I') and Request_Id in (select Request_Id from PL_APPROVALREQUEST where PL_APPROVALREQUEST.Emp_Code = '" + EmpCode + "'  and Status_Id in (4,7)) order by IA.CREATED_ON desc";
                    }
                    else if (DocumentType.Equals("Rejected Request"))
                    {
                        cmd.CommandText = @"select (SELECT INITCAP(e1.Employee_Name) FROM hrm_employee e1 WHERE e1.Emp_Code = (select Emp_Code from Pl_APPROVALREQUEST where REQUEST_ID = IA.REQUEST_ID and LEVEL_ID = 1))HodName,IA.REQUEST_ID,IA.DOCUMENT_NO,IA.FORM_TYPE,IA.EMP_CODE,IA.INTERNET_ACCESSTYPE,TO_DATE(Ia.Validity_From, 'YYYY-MM-DD')VALIDITY_FROM,TO_DATE(Ia.VALIDITY_TO, 'YYYY-MM-DD')VALIDITY_TO,IA.REQ_SPECIFICTIME,IA.CREATED_BY,e.Employee_Name as RequestorName,IA.CREATED_ON,IA.STATUS_ID,s.Status_Name,INITcap(hris_get.dept_code(hcf_pkg.dept_code(e.Company,IA.Emp_Code)))as Department from Pl_InternetAccess IA left join hrm_employee e on IA.Emp_Code = e.Emp_Code left join PL_STATUS s on s.Status_Id = IA.Status_Id where IA.STATUS not in ('I') and Request_Id in (select Request_Id from PL_APPROVALREQUEST where PL_APPROVALREQUEST.Emp_Code = '" + EmpCode + "'  and Status_Id = 5) order by IA.CREATED_ON desc";
                    }
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "@EmpCode", DbType = DbType.String, Value = EmpCode });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "@DocumentType", DbType = DbType.String, Value = DocumentType });
                    using (OracleDataAdapter da = new OracleDataAdapter(cmd))
                    {
                        da.Fill(ds);
                        objTrans.Commit();
                    }
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
    #region GetDashboardDetails
    public DataSet GetDashboardDetails(string EmpCode)
    {
        DataSet ds = new DataSet();
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    //cmd.CommandText = "PL_GetDashboardDetails";
                    //cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = @"select (select count(*) from Pl_InternetAccess where Emp_Code = '" + EmpCode + "' and STATUS not in ('I') and status_Id in (4, 5, 6)) + " +
                        "(select count(*)  from Pl_Laptop_Request where Emp_Code = '" + EmpCode + "' and STATUS not in ('I') and status_Id in (4, 5, 6)) as MyRequest," +
                        "(select count(*) from Pl_InternetAccess where STATUS not in ('I') and Request_Id in (select Request_Id from PL_APPROVALREQUEST where Emp_Code = '" + EmpCode + "' and Status_Id = 3) " +
                        " and Status_Id = 6) + (select count(*) from Pl_InternetAccess where STATUS not in ('I') and Request_Id in (select Request_Id from Pl_Laptop_Request where Emp_Code = '" + EmpCode + "' and Status_Id = 3) and Status_Id = 6)  as Pending," +
                        "(select count(*) from Pl_InternetAccess where STATUS not in ('I') and Request_Id in (select Request_Id from PL_APPROVALREQUEST where Emp_Code = '" + EmpCode + "' and Status_Id in (4, 7)))  + (select count(*)" +
                        "from Pl_InternetAccess where STATUS not in ('I') and Request_Id in (select Request_Id from Pl_Laptop_Request where Emp_Code = '" + EmpCode + "' and Status_Id in (4, 7))) as Approved," +
                        "(select count(*) from Pl_InternetAccess where STATUS not in ('I') and Request_Id in (select Request_Id from PL_APPROVALREQUEST where Emp_Code = '" + EmpCode + "' and Status_Id = 5)) + (select count(*) from Pl_InternetAccess " +
                         "where STATUS not in ('I') and Request_Id in (select Request_Id from Pl_Laptop_Request where Emp_Code = '" + EmpCode + "' and Status_Id = 5)) as Rejected from dual"; 
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "EmpCode", DbType = DbType.String, Value = EmpCode });
                    using (OracleDataAdapter da = new OracleDataAdapter(cmd))
                    {
                        da.Fill(ds);
                        objTrans.Commit();
                    }
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
            // throw e;
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
    #region getRequestList
    public DataSet getRequestList(string RequestId)
    {
        DataSet ds = new DataSet();
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    // cmd.CommandText = "PL_Usp_GetUserDetails";
                    //cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "select INITCAP(Desig_NM)Desig_NM,Ia.INTERNET_ACCESSTYPE,e.Email_Id,e.Off_Mobile_No,Ia.Request_Id,Ia.Document_No,Ia.Form_Type,Ia.Emp_Code,TO_DATE(Ia.Validity_From, 'YYYY-MM-DD')Validity_From,TO_DATE(Ia.Validity_To, 'YYYY-MM-DD')Validity_To," +
                        "Ia.Status_Id,Ia.Created_On,Ia.Req_Specifictime,Ia.Website_category,Ia.Additional_Comments,e.Employee_Name as RequestorName," +
                        "(SELECT e2.Employee_Name FROM hrm_employee e2 where e2.emp_Code in (SELECT e1.Func_Reportg FROM hrm_employee e1 " +
                        "WHERE e1.Emp_Code = Ia.Emp_Code))HodName,INITcap(hris_get.dept_code(hcf_pkg.dept_code(e.Company,Ia.Emp_Code)))as Department,REQUEST_TYPE,DEVICEACCESS_TYPE,DEVICE_INFORMATION,ACCESSUSB_DEVICE,JUSTIFICATIONFOR_FULLACCESS" +
                        " from  Pl_InternetAccess Ia left join hrm_employee e on e.Emp_Code= Ia.Emp_code inner join hrm_Designation deg on deg.Desig_Code = e.Desig_Code " +
                        "where Request_Id = '"+RequestId+"'";
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "@RequestId", DbType = DbType.String, Value = RequestId });
                    using (OracleDataAdapter da = new OracleDataAdapter(cmd))
                    {
                        da.Fill(ds);
                        objTrans.Commit();
                    }
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
            // throw e;
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
    #region GetApproverDetails
    public DataSet GetApproverDetails(string RequestId)
    {
        DataSet ds = new DataSet();
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    cmd.CommandText = "select ACCESSTYPE_PROVIDED,ar.Approval_Id,ar.Request_Id,ar.Emp_Code,INITCAP(Employee_Name)Employee_Name,ar.Level_Id,ar.Action_On,ar.comments," +
                        "ar.status_Id,s.Status_Name from Pl_APPROVALREQUEST ar left Join hrm_employee e1 on e1.Emp_Code = ar.Emp_Code " +
                        "left join Pl_Status s on s.Status_Id = ar.Status_Id where Request_Id = '"+RequestId+"' order by ar.Level_Id";
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "@RequestId", DbType = DbType.String, Value = RequestId });
                    using (OracleDataAdapter da = new OracleDataAdapter(cmd))
                    {
                        da.Fill(ds);
                        objTrans.Commit();
                    }
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
    #region FowardRequestDeptHead
    public int FowardRequestDeptHead(string EmpCode, string RequestId, string ApproverLevelId, string StatusId)
    {
        int success = 0;
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                //objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    cmd.CommandText = "INSERT INTO Pl_APPROVALREQUEST (Request_ID,EMP_CODE,Level_ID,Status_Id)" +
                        "values ('" + RequestId + "',(select Func_Reportg from hrm_employee where Emp_Code = '"+EmpCode+"'),'" + ApproverLevelId + "','" + StatusId + "')";
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "EmpCode", DbType = DbType.String, Value = EmpCode });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "RequestId", DbType = DbType.String, Value = RequestId });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "ApproverLevelId", DbType = DbType.String, Value = ApproverLevelId });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "StatusId", DbType = DbType.String, Value = StatusId });
                    success = cmd.ExecuteNonQuery();
                    //objTrans.Commit();
                }
            }
        }
        catch (Exception ex)
        {
            //objTrans.Rollback();
            throw ex;
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return success;
    }
    #endregion
    #region ForwardRequestToAuthority
    public int FowardRequestToAuthority(string requestId, string approverEmpCode, string approverLevelId, string statusId)
    {
        int success = 0;

        try
        {
            using (OracleConnection con = new ConnectionCode().getConnection())
            {
                using (OracleCommand cmd = con.CreateCommand())
                {
                    cmd.CommandText = @"INSERT INTO Pl_Laptop_APPROVAL_REQ (Approval_Id,Request_ID, EMP_CODE, Level_ID, Status_Id) 
                                        VALUES (LaptopRequest_ID_Seq.NEXTVAL,:RequestId, :approverEmpCode, :ApproverLevelId, :StatusId)";

                    cmd.Parameters.Add(new OracleParameter { ParameterName = "RequestId", DbType = DbType.String, Value = requestId });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "approverEmpCode", DbType = DbType.String, Value = approverEmpCode });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "ApproverLevelId", DbType = DbType.String, Value = approverLevelId });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "StatusId", DbType = DbType.String, Value = statusId });

                    success = cmd.ExecuteNonQuery();
                }
            }
        }
        catch (Exception ex)
        {
            // Log the exception or handle it appropriately
            throw;
        }

        return success;
    }

    #endregion
    #region UpdateDepartmnetHead
    public int UpdateDepartmnetHead(string EmpCode)
    {
        int success = 0;
        OracleTransaction objTrans = null;
        try
        {
            using (OracleConnection con = new ConnectionCode().getConnection())
            {
                objTrans = con.BeginTransaction();
                using (OracleCommand cmd = con.CreateCommand())
                {
                    cmd.CommandText = "update PL_APPROVALMAPPING set Emp_Code = (select Func_Reportg from hrm_employee where Emp_Code = '" + EmpCode + "') where Level_Id = 1";

                    cmd.Parameters.Add(new OracleParameter { ParameterName = "EmpCode", DbType = DbType.String, Value = EmpCode });

                    success = cmd.ExecuteNonQuery();
                    objTrans.Commit();
                }
            }
        }
        catch (Exception ex)
        {
            objTrans.Rollback();
        }

        return success;
    }

    #endregion
    #region ActionOnPolicyRequest
    public int ActionOnPolicyRequest(string EmpCode,string RequestId,string ApprovalStatusID,string AdditionalComment,string LevelId,string ApprovalId,string InternetAccessCategories)
    {
        int success = 0;
        OracleTransaction objTrans = null;
        try
        {
            using (OracleConnection con = new ConnectionCode().getConnection())
            {

                objTrans = con.BeginTransaction();
                using (OracleCommand cmd = con.CreateCommand())
                {
                    if (LevelId.Equals("4"))
                    {
                        cmd.CommandText = "update Pl_ApprovalRequest set Action_On = sysdate,Status_Id = 7,Comments = '" + AdditionalComment + "',ACCESSTYPE_PROVIDED = '"+ InternetAccessCategories + "'  where Approval_Id = '" + ApprovalId + "' and Request_Id = '" + RequestId + "' and Emp_Code = '" + EmpCode + "'  and Level_Id = '" + LevelId + "'";
                    }
                    else
                    {
                        cmd.CommandText = "update Pl_ApprovalRequest set Action_On = sysdate,Status_Id = '" + ApprovalStatusID + "',Comments = '" + AdditionalComment + "',ACCESSTYPE_PROVIDED = '"+ InternetAccessCategories + "'  where Approval_Id = '" + ApprovalId + "' and Request_Id = '" + RequestId + "' and Emp_Code = '" + EmpCode + "'  and Level_Id = '" + LevelId + "'";
                    }
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "EmpCode", DbType = DbType.String, Value = EmpCode });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "RequestId", DbType = DbType.String, Value = RequestId });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "ApprovalStatusID", DbType = DbType.String, Value = ApprovalStatusID });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "AdditionalComment", DbType = DbType.String, Value = AdditionalComment });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "LevelId", DbType = DbType.String, Value = LevelId });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "ApprovalId", DbType = DbType.String, Value = ApprovalId });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "InternetAccessCategories", DbType = DbType.String, Value = InternetAccessCategories });

                    success = cmd.ExecuteNonQuery();
                    objTrans.Commit();
                }
            }
        }
        catch (Exception ex)
        {
            objTrans.Rollback();
        }

        return success;
    }

    #endregion
    #region ActionOnPolicyRequest1
    public int ActionOnPolicyRequest1(string EmpCode, string RequestId, string ApprovalStatusID, string AdditionalComment, string nextLevelId, string ApprovalId)
    {
        int success = 0;
        OracleTransaction objTrans = null;
        try
        {
            using (OracleConnection con = new ConnectionCode().getConnection())
            {
                objTrans = con.BeginTransaction();
                using (OracleCommand cmd = con.CreateCommand())
                {
                    cmd.CommandText = "update Pl_ApprovalRequest set CREATED_ON = sysdate, Status_Id = 3 where Request_Id = '" + RequestId + "' and Level_Id = '" + nextLevelId + "'";
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "EmpCode", DbType = DbType.String, Value = EmpCode });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "RequestId", DbType = DbType.String, Value = RequestId });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "ApprovalStatusID", DbType = DbType.String, Value = ApprovalStatusID });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "AdditionalComment", DbType = DbType.String, Value = AdditionalComment });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "nextLevelId", DbType = DbType.String, Value = nextLevelId });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "ApprovalId", DbType = DbType.String, Value = ApprovalId });

                    success = cmd.ExecuteNonQuery();
                    objTrans.Commit();
                }
            }
        }
        catch (Exception ex)
        {
            objTrans.Rollback();
        }

        return success;
    }

    #endregion
    #region ApprovedRejectPolicyRequest
    public int ApprovedRejectPolicyRequest(string EmpCode, string RequestId, string ApprovalStatusID, string AdditionalComment, string LevelId, string ApprovalId)
    {
        int success = 0;
        OracleTransaction objTrans = null;
        try
        {
            using (OracleConnection con = new ConnectionCode().getConnection())
            {

                objTrans = con.BeginTransaction();
                using (OracleCommand cmd = con.CreateCommand())
                {
                    cmd.CommandText = "update Pl_InternetAccess set Status_Id = '"+ ApprovalStatusID + "',Last_Upd_By='"+ EmpCode + "',Last_Upd_On = sysdate where Request_Id = '" + RequestId + "'";
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "EmpCode", DbType = DbType.String, Value = EmpCode });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "RequestId", DbType = DbType.String, Value = RequestId });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "ApprovalStatusID", DbType = DbType.String, Value = ApprovalStatusID });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "AdditionalComment", DbType = DbType.String, Value = AdditionalComment });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "LevelId", DbType = DbType.String, Value = LevelId });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "ApprovalId", DbType = DbType.String, Value = ApprovalId });

                    success = cmd.ExecuteNonQuery();
                    objTrans.Commit();
                }
            }
        }
        catch (Exception ex)
        {
            objTrans.Rollback();
        }

        return success;
    }

    #endregion
    #region GetRequestorDetails
    public DataTable GetRequestorDetails(string RequestId)
    {
        DataTable dt = new DataTable();
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    cmd.CommandText = "select r.Request_ID,INITCAP(e.Employee_Name)Employee_Name,e.Emp_Code,e.Email_Id from Pl_INTERNETACCESS r left join hrm_employee e on e.Emp_Code = r.Emp_code where Request_ID = '" + RequestId + "'";
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "@RequestId", DbType = DbType.String, Value = RequestId });
                    using (OracleDataAdapter da = new OracleDataAdapter(cmd))
                    {
                        da.Fill(dt);
                        objTrans.Commit();
                    }
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return dt;
    }
    #endregion
    #region GetApproverList
    public DataTable GetApproverList(string RequestId,string nextLevelId)
    {
        DataTable dt = new DataTable();
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    cmd.CommandText = "select r.Request_ID,INITCAP(e.Employee_Name)Employee_Name,e.Emp_Code,e.Email_Id from Pl_ApprovalRequest r left join hrm_employee e on e.Emp_Code = r.Emp_code where  r.Level_Id = '" + nextLevelId+"'  and Request_Id = '"+RequestId+"'";
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "@RequestId", DbType = DbType.String, Value = RequestId });
                    using (OracleDataAdapter da = new OracleDataAdapter(cmd))
                    {
                        da.Fill(dt);
                        objTrans.Commit();
                    }
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return dt;
    }
    #endregion
    #region GetUsbApprovalList
    public DataSet GetUsbApprovalList(string EmpCode)
    {
        DataSet ds = new DataSet();
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    cmd.CommandText = @"select case when CO_REVIEWER is not null then CO_REVIEWER else Reviewer end as Emp_Code," +
                        "INITCAP(((select Employee_Name from hrm_employee where Emp_Code = (SELECT case when e1.CO_REVIEWER is not null then e1.CO_REVIEWER else e1.Reviewer end FROM hrm_employee e1 WHERE e1.Emp_Code = '" + EmpCode + "'))))Employee_Name," +
                        "1 as level_Id from hrm_employee where Emp_Code = '" + EmpCode + "' union all select am.Emp_Code,INITCAP(e1.Employee_Name)Employee_Name,am.Level_Id from PL_APPROVALMAPPING am left Join hrm_employee e1 on e1.Emp_Code = am.Emp_Code where am.Level_Id in (2,3,9,7)";
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "@EmpCode", DbType = DbType.String, Value = EmpCode });
                    using (OracleDataAdapter da = new OracleDataAdapter(cmd))
                    {
                        da.Fill(ds);
                        objTrans.Commit();
                    }
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
    #region GetRequestListForAdmin
    public DataSet GetRequestListForAdmin(string EmpCode,string WhereCondition)
    {
        DataSet ds = new DataSet();
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    if (WhereCondition == "")
                    {
                        cmd.CommandText = "select (SELECT INITCAP(e1.Employee_Name) FROM hrm_employee e1 WHERE e1.Emp_Code = (select Emp_Code from Pl_APPROVALREQUEST where REQUEST_ID = IA.REQUEST_ID and LEVEL_ID = 1))HodName,IA.REQUEST_ID,IA.DOCUMENT_NO,IA.FORM_TYPE,IA.EMP_CODE,IA.INTERNET_ACCESSTYPE,TO_DATE(Ia.Validity_From, 'YYYY-MM-DD')VALIDITY_FROM,TO_DATE(Ia.VALIDITY_TO, 'YYYY-MM-DD')VALIDITY_TO,IA.REQ_SPECIFICTIME,IA.CREATED_BY,INITCAP(REGEXP_REPLACE(e.Employee_Name, '([[:alpha:]])([[:alpha:]]*)', '\\1' || LOWER('\\2'))) as RequestorName,IA.CREATED_ON,IA.STATUS_ID,s.Status_Name,INITcap(hris_get.dept_code(hcf_pkg.dept_code(e.Company,IA.Emp_Code)))as Department from Pl_InternetAccess IA left join hrm_employee e on IA.Emp_Code = e.Emp_Code left join PL_STATUS s on s.Status_Id = IA.Status_Id where IA.STATUS not in ('I') order by IA.CREATED_ON desc";
                    }
                    else
                    {
                        cmd.CommandText = "select (SELECT INITCAP(e1.Employee_Name) FROM hrm_employee e1 WHERE e1.Emp_Code = (select Emp_Code from Pl_APPROVALREQUEST where REQUEST_ID = IA.REQUEST_ID and LEVEL_ID = 1))HodName,IA.REQUEST_ID,IA.DOCUMENT_NO,IA.FORM_TYPE,IA.EMP_CODE,IA.INTERNET_ACCESSTYPE,TO_DATE(Ia.Validity_From, 'YYYY-MM-DD')VALIDITY_FROM,TO_DATE(Ia.VALIDITY_TO, 'YYYY-MM-DD')VALIDITY_TO,IA.REQ_SPECIFICTIME,IA.CREATED_BY,INITCAP(REGEXP_REPLACE(e.Employee_Name, '([[:alpha:]])([[:alpha:]]*)', '\\1' || LOWER('\\2'))) as RequestorName,IA.CREATED_ON,IA.STATUS_ID,s.Status_Name,INITcap(hris_get.dept_code(hcf_pkg.dept_code(e.Company,IA.Emp_Code)))as Department from Pl_InternetAccess IA left join hrm_employee e on IA.Emp_Code = e.Emp_Code left join PL_STATUS s on s.Status_Id = IA.Status_Id where IA.STATUS not in ('I') " + WhereCondition + " order by IA.CREATED_ON desc";
                    }
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "@EmpCode", DbType = DbType.String, Value = EmpCode });
                    using (OracleDataAdapter da = new OracleDataAdapter(cmd))
                    {
                        da.Fill(ds);
                        objTrans.Commit();
                    }
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
    #region GetRequestorList
    public DataSet GetRequestorList(string EmpCode)
    {
        DataSet ds = new DataSet();
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    cmd.CommandText = "select distinct i.Emp_Code,Employee_Name from Pl_InternetAccess i left join hrm_employee e on i.Emp_Code = e.Emp_Code order by Employee_Name";
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "@EmpCode", DbType = DbType.String, Value = EmpCode });
                    using (OracleDataAdapter da = new OracleDataAdapter(cmd))
                    {
                        da.Fill(ds);
                        objTrans.Commit();
                    }
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
    #region GetDepartment
    public DataSet GetDepartment(string EmpCode)
    {
        DataSet ds = new DataSet();
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    cmd.CommandText = "select distinct e.Dept_Code,INITcap(hris_get.dept_code(hcf_pkg.dept_code(e.company,e.emp_code)))Department from Pl_InternetAccess i left join hrm_employee e on i.Emp_Code = e.Emp_Code order by Department";
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "@EmpCode", DbType = DbType.String, Value = EmpCode });
                    using (OracleDataAdapter da = new OracleDataAdapter(cmd))
                    {
                        da.Fill(ds);
                        objTrans.Commit();
                    }
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
    #region GetPendingWithUserList
    public DataSet GetPendingWithUserList(string EmpCode)
    {
        DataSet ds = new DataSet();
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    cmd.CommandText = "select distinct i.Emp_Code,Employee_Name from PL_APPROVALREQUEST i left join hrm_employee e on i.Emp_Code = e.Emp_Code where i.Request_Id in (select Request_Id from PL_INTERNETACCESS where Status_Id = 6) and i.Status_ID = 3 order by Employee_Name";
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "@EmpCode", DbType = DbType.String, Value = EmpCode });
                    using (OracleDataAdapter da = new OracleDataAdapter(cmd))
                    {
                        da.Fill(ds);
                        objTrans.Commit();
                    }
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
    #region GetDocViewRightsApproverList
    public DataSet GetDocViewRightsApproverList(string EmpCode)
    {
        DataSet ds = new DataSet();
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    // Query 1 with parameter
                    string query1 = @"select da.Emp_Code,Level_Id,INITCAP(Employee_Name)Employee_Name from DocViewRight_AppMapping da left join hrm_employee e on e.Emp_Code = da.Emp_Code order by Level_Id";
                    OracleDataAdapter adapter1 = new OracleDataAdapter(query1, con);
                    //adapter1.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Int32).Value = EmpCode;
                    DataTable dataTable1 = new DataTable("Table1");
                    adapter1.Fill(dataTable1);
                    ds.Tables.Add(dataTable1);

                    // Query 2 with parameter
                    string query2 = @"SELECT Emp_Code,INITCAP(Employee_Name)Employee_Name,Email_Id FROM HRM_EMPLOYEE
                                        WHERE  CD_CODE= 'M0' and status in ('C','P','N') and Email_Id is not null
                                        union all
                                        SELECT Emp_Code,INITCAP(Employee_Name)Employee_Name,Email_Id FROM HRM_EMPLOYEE
                                        WHERE  Emp_Code = '5504905'";
                    OracleDataAdapter adapter2 = new OracleDataAdapter(query2, con);
                    adapter2.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Int32).Value = EmpCode;
                    DataTable dataTable2 = new DataTable("Table2");
                    adapter2.Fill(dataTable2);
                    ds.Tables.Add(dataTable2);

                    // Query 3 with parameter
                    string query3 = @"select da.Emp_Code,Level_Id,INITCAP(Employee_Name)Employee_Name from DocViewRight_AppMapping da 
                                        left join hrm_employee e on e.Emp_Code = da.Emp_Code order by Level_Id";
                    OracleDataAdapter adapter3 = new OracleDataAdapter(query3, con);
                    adapter3.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Int32).Value = EmpCode;
                    DataTable dataTable3 = new DataTable("Table3");
                    adapter3.Fill(dataTable3);
                    ds.Tables.Add(dataTable3);
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
    #region SaveDocViewRightsRequest
    public int SaveDocViewRightsRequest(string EmpCode,string DocumentNo)
    {
        int success = 0;
        OracleTransaction objTrans = null;
        try
        {
            using (OracleConnection con = new ConnectionCode().getConnection())
            {
                objTrans = con.BeginTransaction();
                using (OracleCommand cmd = con.CreateCommand())
                {
                    cmd.CommandText = "INSERT INTO DocViewRight_Request (Emp_Code, CREATED_BY, Document_No,Status_Id) VALUES (:EmpCode, :CreatedBy, :DocumentNo,6) RETURNING Req_Id INTO :LastId";

                    // Use distinct parameter names to avoid conflicts
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "EmpCode", DbType = DbType.String, Value = EmpCode });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "CreatedBy", DbType = DbType.String, Value = EmpCode });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "DocumentNo", DbType = DbType.String, Value = DocumentNo });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "LastId", OracleDbType = OracleDbType.Int32, Direction = ParameterDirection.ReturnValue });

                    success = cmd.ExecuteNonQuery();

                    // Retrieve the last inserted ID
                    OracleDecimal oracleDecimal = (OracleDecimal)cmd.Parameters["LastId"].Value;
                    success = oracleDecimal.ToInt32();

                    objTrans.Commit();
                }
            }
        }
        catch (Exception ex)
        {
            objTrans.Rollback();
        }

        return success;
    }
    #endregion
    #region SaveDocViewRightsUserList
    public int SaveDocViewRightsUserList(string Req_Id,string RequesterName,string RequestorID,string Entity,string SBUCode, string Department,string DocumentType,string ValidityPeriod,string ValidityTo)
    {
        int success = 0;
        OracleTransaction objTrans = null;
        try
        {
            using (OracleConnection con = new ConnectionCode().getConnection())
            {
                objTrans = con.BeginTransaction();
                using (OracleCommand cmd = con.CreateCommand())
                {
                    cmd.CommandText = "INSERT INTO DocViewRight_ReqList (REQ_ID, REQUESTER_NAME, REQUESTOR_ID,ENTITY,SBU_CODE,DEPARTMENT,DOCUMENT_TYPE,VALIDITY_PERIOD,Validity_To) " +
                        "VALUES (:Req_Id, :RequesterName, :RequestorID, :Entity, :SBUCode, :Department, :DocumentType, :ValidityPeriod, :ValidityTo)";

                    // Use distinct parameter names to avoid conflicts
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "Req_Id", DbType = DbType.String, Value = Req_Id });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "RequesterName", DbType = DbType.String, Value = RequesterName });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "RequestorID", DbType = DbType.String, Value = RequestorID });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "Entity", DbType = DbType.String, Value = Entity });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "SBUCode", DbType = DbType.String, Value = SBUCode });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "Department", DbType = DbType.String, Value = Department });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "DocumentType", DbType = DbType.String, Value = DocumentType });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "ValidityPeriod", DbType = DbType.String, Value = ValidityPeriod });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "ValidityTo", DbType = DbType.String, Value = ValidityTo });

                    success = cmd.ExecuteNonQuery();
                    objTrans.Commit();
                }
            }
        }
        catch (Exception ex)
        {
            objTrans.Rollback();
        }

        return success;
    }
    #endregion
    #region GetListOfDocViewRequest
    public DataSet GetListOfDocViewRequest(string EmpCode, string DocumentType)
    {
        DataSet ds = new DataSet();
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    if (DocumentType.Equals("My Request"))
                    {
                        cmd.CommandText = "select INITcap(hris_get.dept_code(hcf_pkg.dept_code(e.company,e.emp_code)))Department,Req_Id,Document_No,INITCAP(Employee_Name)Employee_Name,dv.CREATED_ON,dv.Status_Id,s.Status_Name from DocViewRight_Request dv left join hrm_employee e on dv.Emp_Code = e.Emp_Code left join PL_STATUS s on s.Status_Id = dv.Status_Id where dv.Emp_Code = '" + EmpCode + "' order by dv.CREATED_ON desc";
                    }
                    else if (DocumentType.Equals("Pending Request"))
                    {
                        cmd.CommandText = "select INITcap(hris_get.dept_code(hcf_pkg.dept_code(e.company,e.emp_code)))Department,Req_Id,Document_No,INITCAP(Employee_Name)Employee_Name,dv.CREATED_ON,dv.Status_Id,s.Status_Name from DocViewRight_Request dv left join hrm_employee e on dv.Emp_Code = e.Emp_Code left join PL_STATUS s on s.Status_Id = dv.Status_Id where Req_Id in (select Req_Id from DocViewRight_AppReq where DocViewRight_AppReq.Emp_Code = '" + EmpCode + "'  and Status_Id = 3) and dv.Status_Id = 6 order by dv.CREATED_ON desc";
                    }
                    else if (DocumentType.Equals("Approved Request"))
                    {
                        cmd.CommandText = "select INITcap(hris_get.dept_code(hcf_pkg.dept_code(e.company,e.emp_code)))Department,Req_Id,Document_No,INITCAP(Employee_Name)Employee_Name,dv.CREATED_ON,dv.Status_Id,s.Status_Name from DocViewRight_Request dv left join hrm_employee e on dv.Emp_Code = e.Emp_Code left join PL_STATUS s on s.Status_Id = dv.Status_Id where Req_Id in (select Req_Id from DocViewRight_AppReq where DocViewRight_AppReq.Emp_Code = '" + EmpCode + "'  and Status_Id = 4) order by dv.CREATED_ON desc";
                    }
                    else if (DocumentType.Equals("Reject Request"))
                    {
                        cmd.CommandText = "select INITcap(hris_get.dept_code(hcf_pkg.dept_code(e.company,e.emp_code)))Department,Req_Id,Document_No,INITCAP(Employee_Name)Employee_Name,dv.CREATED_ON,dv.Status_Id,s.Status_Name from DocViewRight_Request dv left join hrm_employee e on dv.Emp_Code = e.Emp_Code left join PL_STATUS s on s.Status_Id = dv.Status_Id where Req_Id in (select Req_Id from DocViewRight_AppReq where DocViewRight_AppReq.Emp_Code = '" + EmpCode + "'  and Status_Id = 5) and dv.Status_Id = 5 order by dv.CREATED_ON desc";
                    }
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "@EmpCode", DbType = DbType.String, Value = EmpCode });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "@DocumentType", DbType = DbType.String, Value = DocumentType });
                    using (OracleDataAdapter da = new OracleDataAdapter(cmd))
                    {
                        da.Fill(ds);
                        objTrans.Commit();
                    }
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
    #region GetocViewReqDashBoard
    public DataSet GetocViewReqDashBoard(string EmpCode)
    {
        DataSet ds = new DataSet();
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    //cmd.CommandText = "PL_GetDashboardDetails";
                    //cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "select count(*)MyRequest from DocViewRight_Request where Emp_Code = '" + EmpCode + "' and Status_Id in (4,5,6) " +
                        "union all select count(*)Pending from DocViewRight_Request where Req_Id in (select Req_Id from DocViewRight_AppReq where Emp_Code = '" + EmpCode + "'  and Status_Id = 3) and Status_Id = 6 union all select count(*)Approved from DocViewRight_Request where Req_Id in (select Req_Id from DocViewRight_AppReq where Emp_Code = '" + EmpCode + "'  and Status_Id in (4)) union all select count(*)Reject from DocViewRight_Request where Req_Id in (select Req_Id from DocViewRight_AppReq where Emp_Code = '" + EmpCode + "'  and Status_Id = 5)";
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "EmpCode", DbType = DbType.String, Value = EmpCode });
                    using (OracleDataAdapter da = new OracleDataAdapter(cmd))
                    {
                        da.Fill(ds);
                        objTrans.Commit();
                    }
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
            // throw e;
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
    #region GeDocViewRightsDocumnetNo
    public DataSet GeDocViewRightsDocumnetNo(string EmpCode)
    {
        DataSet ds = new DataSet();
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    cmd.CommandText = @"select EMP_CODE,UNIT_CODE, hris_get.func_code(e.func_code) func_code_desc,CD_CODE,ADMIN_REPORTG,FUNC_REPORTG,MOBILE_NO,
                                    (select SBU_CODE from  oc_sbu_mapping where ou_code=E.company and rownum=1)  BUSS_CODE,
                                    (select ENTITY_CODE from  oc_sbu_mapping where ou_code=E.company and rownum=1) ENTITY_CODE,
                                    FUNC_CODE, EUIN_CODE,(select max(FISCAL_YEAR) from fiscal_years  where company = '55' and status= 'O') FYEAR,
                                    (select lpad(nvl(max(substr(DOCUMENT_NO,length(DOCUMENT_NO)-1,length(DOCUMENT_NO))) +1,1),3,'0') from DocViewRight_Request)MAX_NO
                                     from hrm_employee E where emp_code='"+ EmpCode + "' and status in ('C','P','N')";
                    cmd.CommandType = CommandType.Text;
                    using (OracleDataAdapter da = new OracleDataAdapter(cmd))
                    {
                        da.Fill(ds);
                        objTrans.Commit();
                    }
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
            // throw e;
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
    #region ForwaredDocViewRightsRequestToApprover
    public int ForwaredDocViewRightsRequestToApprover(string ReqId, string EmpCode, string LevelId, string Status)
    {
        int success = 0;
        OracleTransaction objTrans = null;
        try
        {
            using (OracleConnection con = new ConnectionCode().getConnection())
            {
                objTrans = con.BeginTransaction();
                using (OracleCommand cmd = con.CreateCommand())
                {
                    cmd.CommandText = "INSERT INTO DocViewRight_AppReq (REQ_ID, EMP_CODE, LEVEL_ID,STATUS_ID) VALUES (:ReqId, :EmpCode, :LevelId, :Status)";

                    // Use distinct parameter names to avoid conflicts
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "ReqId", DbType = DbType.String, Value = ReqId });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "EmpCode", DbType = DbType.String, Value = EmpCode });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "LevelId", DbType = DbType.String, Value = LevelId });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "Status", DbType = DbType.String, Value = Status });

                    success = cmd.ExecuteNonQuery();
                    objTrans.Commit();
                }
            }
        }
        catch (Exception ex)
        {
            objTrans.Rollback();
        }

        return success;
    }
    #endregion
    #region GetDocViewRightsRequestDetails
    public DataSet GetDocViewRightsRequestDetails(string EmpCode,string ReqId)
    {
        DataSet ds = new DataSet();
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    // Query 1 with parameter
                    string query1 = "select REQLIST_ID,REQ_ID,REQUESTER_NAME,REQUESTOR_ID,ENTITY,SBU_CODE,DEPARTMENT,DOCUMENT_TYPE,TO_DATE(VALIDITY_PERIOD, 'YYYY-MM-DD')VALIDITY_PERIOD,TO_DATE(VALIDITY_TO, 'YYYY-MM-DD')VALIDITY_TO from DocViewRight_ReqList where REQ_ID = '" + ReqId+"'";
                    OracleDataAdapter adapter1 = new OracleDataAdapter(query1, con);
                    adapter1.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Varchar2).Value = EmpCode;
                    adapter1.SelectCommand.Parameters.Add("@ReqId", OracleDbType.Varchar2).Value = ReqId;
                    DataTable dataTable1 = new DataTable("Table1");
                    adapter1.Fill(dataTable1);
                    ds.Tables.Add(dataTable1);

                    // Query 2 with parameter
                    string query2 = "select dr.EMP_CODE,REQUESTORID_YESNO,COMOWNLAPTOP_YESNO,HARDENINGLAPTOP_YESNO,VIEWRIGHTSALLOCATED_YESNO,Req_Id,Status_Id,Email_Id,dr.Created_On,Document_No,INITCAP(Employee_Name)Employee_Name from DocViewRight_Request dr left join hrm_employee e on e.Emp_Code = dr.Emp_Code where Req_Id = '" + ReqId + "'";
                    OracleDataAdapter adapter2 = new OracleDataAdapter(query2, con);
                    adapter2.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Varchar2).Value = EmpCode;
                    adapter2.SelectCommand.Parameters.Add("@ReqId", OracleDbType.Varchar2).Value = ReqId;
                    DataTable dataTable2 = new DataTable("Table2");
                    adapter2.Fill(dataTable2);
                    ds.Tables.Add(dataTable2);

                    // Query 3 with parameter
                    string query3 = "select Email_Id,INITCAP(Employee_Name)Employee_Name,Approval_Id,Req_Id,ar.Emp_Code,ar.Status_Id,Comments,Action_On,Status_Name,Level_Id from DocViewRight_AppReq ar left join hrm_employee e on e.Emp_Code = ar.Emp_Code left join Pl_Status s on s.Status_Id = ar.Status_Id where Req_Id = '" + ReqId+"' order by  Level_Id";
                    OracleDataAdapter adapter3 = new OracleDataAdapter(query3, con);
                    adapter3.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Varchar2).Value = EmpCode;
                    adapter3.SelectCommand.Parameters.Add("@ReqId", OracleDbType.Varchar2).Value = ReqId;
                    DataTable dataTable3 = new DataTable("Table3");
                    adapter3.Fill(dataTable3);
                    ds.Tables.Add(dataTable3);

                    // Query 4 with parameter
                    string query4 = "select Email_Id,INITCAP(Employee_Name)Employee_Name,Approval_Id,Req_Id,ar.Emp_Code,ar.Status_Id,Comments,Action_On,Status_Name,Level_Id from DocViewRight_AppReq ar left join hrm_employee e on e.Emp_Code = ar.Emp_Code left join Pl_Status s on s.Status_Id = ar.Status_Id where Req_Id = '" + ReqId + "' and Level_Id = '"+ EmpCode + "' order by  Level_Id";
                    OracleDataAdapter adapter4 = new OracleDataAdapter(query4, con);
                    adapter4.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Varchar2).Value = EmpCode;
                    adapter4.SelectCommand.Parameters.Add("@ReqId", OracleDbType.Varchar2).Value = ReqId;
                    DataTable dataTable4 = new DataTable("Table4");
                    adapter4.Fill(dataTable4);
                    ds.Tables.Add(dataTable4);
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
    #region RejectDocViewRightsRequest
    public int RejectDocViewRightsRequest(string empCode, string ReqId, string ApprovalStatusId, string additionalComment, string LevelId, string ApprovalId)
    {
        int success = 0;
        OracleTransaction objTrans = null;
        try
        {
            using (OracleConnection con = new ConnectionCode().getConnection())
            {
                objTrans = con.BeginTransaction();
                using (OracleCommand cmd = con.CreateCommand())
                {
                    cmd.CommandText = "update DocViewRight_AppReq set Status_Id = '"+ ApprovalStatusId + "',Action_On = sysdate,Comments = '"+ additionalComment + "'" +
                        "where Level_Id = '"+ LevelId + "' and Emp_Code = '"+ empCode + "' and Req_Id = '"+ReqId+ "' and Approval_Id = '" + ApprovalId + "'";

                    // Use distinct parameter names to avoid conflicts
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "empCode", DbType = DbType.String, Value = empCode });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "ReqId", DbType = DbType.String, Value = ReqId });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "ApprovalStatusId", DbType = DbType.String, Value = ApprovalStatusId });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "additionalComment", DbType = DbType.String, Value = additionalComment });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "LevelId", DbType = DbType.String, Value = LevelId });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "ApprovalId", DbType = DbType.String, Value = ApprovalId });

                    success = cmd.ExecuteNonQuery();
                }
                // Update the second table
                using (OracleCommand cmd2 = con.CreateCommand())
                {
                    cmd2.Transaction = objTrans;
                    cmd2.CommandText = "update DocViewRight_Request set Status_Id = '"+ ApprovalStatusId + "' where Req_Id = '"+ReqId+ "'";

                    // Add parameters for the second command if needed
                    cmd2.Parameters.Add(new OracleParameter { ParameterName = "ReqId", DbType = DbType.String, Value = ReqId });
                    cmd2.Parameters.Add(new OracleParameter { ParameterName = "ApprovalStatusId", DbType = DbType.String, Value = ApprovalStatusId });

                    success += cmd2.ExecuteNonQuery();
                }
                objTrans.Commit();
            }
        }
        catch (Exception ex)
        {
            objTrans.Rollback();
        }

        return success;
    }
    #endregion
    #region ApprovedDocViewRightsRequest
    public int ApprovedDocViewRightsRequest(string empCode, string ReqId, string ApprovalStatusId, string additionalComment, string LevelId, string ApprovalId,
        string Requestercreated,string CompanyOwnedLaptop,string HardeningOfLaptop,string ViewRightsAllocated)
    {
        int success = 0;
        OracleTransaction objTrans = null;
        try
        {
            using (OracleConnection con = new ConnectionCode().getConnection())
            {
                objTrans = con.BeginTransaction();
                using (OracleCommand cmd = con.CreateCommand())
                {
                    cmd.CommandText = "update DocViewRight_AppReq set Status_Id = '" + ApprovalStatusId + "',Action_On = sysdate,Comments = '" + additionalComment + "'" +
                        "where Level_Id = '" + LevelId + "' and Emp_Code = '" + empCode + "' and Req_Id = '" + ReqId + "' and Approval_Id = '" + ApprovalId + "'";

                    // Use distinct parameter names to avoid conflicts
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "empCode", DbType = DbType.String, Value = empCode });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "ReqId", DbType = DbType.String, Value = ReqId });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "ApprovalStatusId", DbType = DbType.String, Value = ApprovalStatusId });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "additionalComment", DbType = DbType.String, Value = additionalComment });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "LevelId", DbType = DbType.String, Value = LevelId });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "ApprovalId", DbType = DbType.String, Value = ApprovalId });

                    success = cmd.ExecuteNonQuery();
                }
                // Update the second table
                using (OracleCommand cmd2 = con.CreateCommand())
                {
                    cmd2.Transaction = objTrans;
                    cmd2.CommandText = "update DocViewRight_AppReq set Status_Id = 3 where Level_Id = '"+ (Convert.ToInt32(LevelId) + 1).ToString() + "' and Req_Id = '" + ReqId + "' ";

                    // Add parameters for the second command if needed
                    cmd2.Parameters.Add(new OracleParameter { ParameterName = "ReqId", DbType = DbType.String, Value = ReqId });
                    cmd2.Parameters.Add(new OracleParameter { ParameterName = "LevelId", DbType = DbType.String, Value = LevelId });

                    success += cmd2.ExecuteNonQuery();
                }
                if (Convert.ToInt32(LevelId) == 5)
                {
                    // Update the third table
                    using (OracleCommand cmd3 = con.CreateCommand())
                    {
                        cmd3.Transaction = objTrans;
                        cmd3.CommandText = "update DocViewRight_Request set Status_Id = '"+ ApprovalStatusId + "' where Req_Id = '"+ ReqId + "' ";

                        // Add parameters for the third command if needed
                        cmd3.Parameters.Add(new OracleParameter { ParameterName = "ReqId", DbType = DbType.String, Value = ReqId });
                        cmd3.Parameters.Add(new OracleParameter { ParameterName = "ApprovalStatusId", DbType = DbType.String, Value = ApprovalStatusId });

                        success += cmd3.ExecuteNonQuery();
                    }
                }

                if (Convert.ToInt32(LevelId) == 2 || Convert.ToInt32(LevelId) == 3 || Convert.ToInt32(LevelId) == 5)
                {
                    // Update the fourth table
                    using (OracleCommand cmd4 = con.CreateCommand())
                    {
                        cmd4.Transaction = objTrans;
                        cmd4.CommandText = "update DocViewRight_Request set REQUESTORID_YESNO = '"+Requestercreated+"',COMOWNLAPTOP_YESNO = '"+CompanyOwnedLaptop + "',HARDENINGLAPTOP_YESNO = '" + HardeningOfLaptop + "',VIEWRIGHTSALLOCATED_YESNO = '"+ViewRightsAllocated + "' where Req_Id = '"+ReqId+"' ";

                        // Add parameters for the fourth command if needed
                        cmd4.Parameters.Add(new OracleParameter { ParameterName = "ReqId", DbType = DbType.String, Value = ReqId });
                        cmd4.Parameters.Add(new OracleParameter { ParameterName = "Requestercreated", DbType = DbType.String, Value = Requestercreated });
                        cmd4.Parameters.Add(new OracleParameter { ParameterName = "CompanyOwnedLaptop", DbType = DbType.String, Value = CompanyOwnedLaptop });
                        cmd4.Parameters.Add(new OracleParameter { ParameterName = "HardeningOfLaptop", DbType = DbType.String, Value = HardeningOfLaptop });
                        cmd4.Parameters.Add(new OracleParameter { ParameterName = "ViewRightsAllocated", DbType = DbType.String, Value = ViewRightsAllocated });

                        success += cmd4.ExecuteNonQuery();
                    }
                }

                objTrans.Commit();
            }
        }
        catch (Exception ex)
        {
            objTrans.Rollback();
        }

        return success;
    }
    #endregion
    #region HodMailId
    public DataSet HodMailId(string HodCode)
    {
        DataSet ds = new DataSet();
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    cmd.CommandText = @"select EMAIL_ID,EMPLOYEE_NAME from hrm_employee where EMP_CODE = '" + HodCode + "'";
                    cmd.CommandType = CommandType.Text;
                    using (OracleDataAdapter da = new OracleDataAdapter(cmd))
                    {
                        da.Fill(ds);
                        objTrans.Commit();
                    }
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
            // throw e;
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
    #region GetPrivacyQuestionnaireList
    public DataSet GetPrivacyQuestionnaireList(string EmpCode,string ChildId = "")
    {
        DataSet ds = new DataSet();
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    // Query 1 with parameter
                    string query1 = "select QUES_RECID,QUES_SEQ_NO,QUES_DESC,QUES_TYPE,CHILD_RECID,'' as Remarks from Privacy_Ques_List where STATUS = 'A' order by QUES_SEQ_NO";
                    OracleDataAdapter adapter1 = new OracleDataAdapter(query1, con);
                    adapter1.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Varchar2).Value = EmpCode;
                    DataTable dataTable1 = new DataTable("Table1");
                    adapter1.Fill(dataTable1);
                    ds.Tables.Add(dataTable1);

                    // Query 2 with parameter
                    string query2 = "select SUB_QUES_ID,SUB_QUES_SEQ_NO,SUB_QUES_DESC,SUB_QUES_TYPE,CHILD_RECID from Privacy_Sub_Ques_List where CHILD_RECID = '" + ChildId + "'";
                    OracleDataAdapter adapter2 = new OracleDataAdapter(query2, con);
                    adapter2.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Varchar2).Value = EmpCode;
                    adapter2.SelectCommand.Parameters.Add("@ChildId", OracleDbType.Varchar2).Value = ChildId;
                    DataTable dataTable2 = new DataTable("Table2");
                    adapter2.Fill(dataTable2);
                    ds.Tables.Add(dataTable2);

                    // Query 3 with parameter
                    string query3 = "select distinct DOC_NO from Privacy_Ques_Ans where CREATED_BY = '"+EmpCode+"'";
                    OracleDataAdapter adapter3 = new OracleDataAdapter(query3, con);
                    adapter3.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Varchar2).Value = EmpCode;
                    DataTable dataTable3 = new DataTable("Table3");
                    adapter3.Fill(dataTable3);
                    ds.Tables.Add(dataTable3);

                    // Query 4 with parameter
                    string query4 = "select ANS_RECID,DOC_NO,QUES_SEQ_NO,QUES_DESC,ANSWER,REMARKS,OTHER,CREATED_BY,CREATED_ON from Privacy_Ques_Ans where DOC_NO = '" + EmpCode+"' order by QUES_SEQ_NO";
                    OracleDataAdapter adapter4 = new OracleDataAdapter(query4, con);
                    adapter4.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Varchar2).Value = EmpCode;
                    DataTable dataTable4 = new DataTable("Table4");
                    adapter4.Fill(dataTable4);
                    ds.Tables.Add(dataTable4);
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
    #region GeQuesAnsDocumnetNo
    public DataSet GeQuesAnsDocumnetNo(string EmpCode)
    {
        DataSet ds = new DataSet();
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    cmd.CommandText = @"select EMP_CODE,UNIT_CODE, hris_get.func_code(e.func_code) func_code_desc,CD_CODE,ADMIN_REPORTG,FUNC_REPORTG,MOBILE_NO,
                                        (select SBU_CODE from  oc_sbu_mapping where ou_code=E.company and rownum=1)  BUSS_CODE,(select ENTITY_CODE from  oc_sbu_mapping where ou_code=E.company and rownum=1) ENTITY_CODE,
                                        FUNC_CODE, EUIN_CODE,(select max(FISCAL_YEAR) from fiscal_years  where company = '55' and status= 'O') FYEAR,
                                        (select lpad(nvl(max(substr(DOC_NO,length(DOC_NO)-1,length(DOC_NO))) +1,1),3,'0') from Privacy_Ques_Ans) MAX_NO
                                        from hrm_employee E where emp_code='"+ EmpCode + "' and status in ('C','P','N')";
                    cmd.CommandType = CommandType.Text;
                    using (OracleDataAdapter da = new OracleDataAdapter(cmd))
                    {
                        da.Fill(ds);
                        objTrans.Commit();
                    }
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
            // throw e;
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
    #region SavePrivacyQuestionnaireData
    public int SavePrivacyQuestionnaireData(string EmpCode, string DocumentNo, string QuesNo, string QuesDes, string Answer, string Remarks, string Other)
    {
        int success = 0;
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    cmd.CommandText = @"INSERT INTO Privacy_Ques_Ans (Ans_RecId,Doc_No,QUES_SEQ_NO,QUES_DESC,Answer,Remarks,STATUS,Created_By,Created_On,OTHER)
                                        values (Privacy_Ques_Seq.nextval,'" + DocumentNo + "','"+ QuesNo + "','"+ QuesDes + "','"+ Answer + "','"+ Remarks + "','A','"+EmpCode+"',sysdate,'"+Other+"')"; 
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "EmpCode", DbType = DbType.String, Value = EmpCode });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "DocumentNo", DbType = DbType.String, Value = DocumentNo });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "QuesNo", DbType = DbType.String, Value = QuesNo });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "QuesDes", DbType = DbType.String, Value = QuesDes });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "Remarks", DbType = DbType.String, Value = Remarks });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "Answer", DbType = DbType.String, Value = Answer });
                    success = cmd.ExecuteNonQuery();
                    objTrans.Commit();
                }
            }
        }
        catch (Exception ex)
        {
            objTrans.Rollback();
            //throw ex;
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return success;
    }
    #endregion
    #region UpdateFromToDate
    public int UpdateFromToDate(string EmpCode,string FromDate,string ToDate, string RequestId)
    {
        int success = 0;
        OracleTransaction objTrans = null;
        try
        {
            using (OracleConnection con = new ConnectionCode().getConnection())
            {

                objTrans = con.BeginTransaction();
                using (OracleCommand cmd = con.CreateCommand())
                {
                    cmd.CommandText = "update Pl_InternetAccess set VALIDITY_FROM = '" + FromDate + "',VALIDITY_TO = '" + ToDate + "',Last_Upd_By='" + EmpCode + "',Last_Upd_On = sysdate where Request_Id = '" + RequestId + "'";
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "EmpCode", DbType = DbType.String, Value = EmpCode });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "RequestId", DbType = DbType.String, Value = RequestId });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "FromDate", DbType = DbType.String, Value = FromDate });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "ToDate", DbType = DbType.String, Value = ToDate });

                    success = cmd.ExecuteNonQuery();
                    objTrans.Commit();
                }
            }
        }
        catch (Exception ex)
        {
            objTrans.Rollback();
        }

        return success;
    }

    #endregion
    #region GetAllDocViewRequest
    public DataSet GetAllDocViewRequest(string EmpCode)
    {
        DataSet ds = new DataSet();
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    cmd.CommandText = "select INITcap(hris_get.dept_code(hcf_pkg.dept_code(e.company,e.emp_code)))Department,Req_Id,Document_No,INITCAP(Employee_Name)Employee_Name,dv.CREATED_ON,dv.Status_Id,s.Status_Name from DocViewRight_Request dv left join hrm_employee e on dv.Emp_Code = e.Emp_Code left join PL_STATUS s on s.Status_Id = dv.Status_Id order by dv.CREATED_ON desc";
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "@EmpCode", DbType = DbType.String, Value = EmpCode });
                    using (OracleDataAdapter da = new OracleDataAdapter(cmd))
                    {
                        da.Fill(ds);
                        objTrans.Commit();
                    }
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
    #region updateflag
    public int updateflag(string RequestId)
    {
        int success = 0;
        OracleTransaction objTrans = null;
        try
        {
            using (OracleConnection con = new ConnectionCode().getConnection())
            {

                objTrans = con.BeginTransaction();
                using (OracleCommand cmd = con.CreateCommand())
                {
                    cmd.CommandText = "update DocViewRight_Request set Status_Id = 5 where Req_Id = '"+RequestId+"'";

                    success = cmd.ExecuteNonQuery();
                    objTrans.Commit();
                }
            }
        }
        catch (Exception ex)
        {
            objTrans.Rollback();
        }

        return success;
    }

    #endregion
    #region GetExpiredRequestForAdmin
    public DataSet GetExpiredRequestForAdmin(string EmpCode)
    {
        DataSet ds = new DataSet();
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    cmd.CommandText = @"SELECT
                                        (SELECT INITCAP(e1.Employee_Name)FROM hrm_employee e1 WHERE e1.Emp_Code = (SELECT Emp_Code FROM Pl_APPROVALREQUEST WHERE REQUEST_ID = IA.REQUEST_ID AND LEVEL_ID = 1)) AS HodName,
                                        IA.REQUEST_ID,IA.DOCUMENT_NO,IA.FORM_TYPE,IA.EMP_CODE,IA.INTERNET_ACCESSTYPE,TO_DATE(IA.Validity_From, 'YYYY-MM-DD') AS VALIDITY_FROM,TO_DATE(IA.Validity_TO, 'YYYY-MM-DD') AS VALIDITY_TO,
                                        IA.REQ_SPECIFICTIME,IA.CREATED_BY,IA.CREATED_ON,IA.STATUS_ID,s.Status_Name,INITCAP(hris_get.dept_code(hcf_pkg.dept_code(e.Company, IA.Emp_Code))) AS Department,
                                        INITCAP(e.Employee_Name) AS RequestorName,e.Email_Id AS To_Mail
                                    FROM Pl_InternetAccess IA
                                    LEFT JOIN hrm_employee e ON IA.Emp_Code = e.Emp_Code
                                    LEFT JOIN PL_STATUS s ON s.Status_Id = IA.Status_Id
                                    WHERE IA.STATUS_ID = 4 AND TO_DATE(IA.VALIDITY_TO, 'YYYY-MM-DD') < TRUNC(CURRENT_DATE) AND
                                    IA.REQUEST_ID NOT IN (SELECT REQUEST_ID FROM Pl_InternetAccess  WHERE STATUS_ID = 4 AND FORM_TYPE = IA.FORM_TYPE AND TO_DATE(VALIDITY_TO, 'YYYY-MM-DD') > TRUNC(CURRENT_DATE))
                                    ORDER BY RequestorName";
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "@EmpCode", DbType = DbType.String, Value = EmpCode });
                    using (OracleDataAdapter da = new OracleDataAdapter(cmd))
                    {
                        da.Fill(ds);
                        objTrans.Commit();
                    }
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
    #region GetLaptopRequestDocumnetNo
    public DataSet GetLaptopRequestDocumnetNo(string EmpCode)
    {
        DataSet ds = new DataSet();
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    cmd.CommandText = @"select EMP_CODE,UNIT_CODE, hris_get.func_code(e.func_code) func_code_desc,CD_CODE,ADMIN_REPORTG,FUNC_REPORTG,MOBILE_NO,
                                        (select SBU_CODE from  oc_sbu_mapping where ou_code=E.company and rownum=1)  BUSS_CODE,
                                        (select ENTITY_CODE from  oc_sbu_mapping where ou_code=E.company and rownum=1) ENTITY_CODE,FUNC_CODE, EUIN_CODE,
                                        (select max(FISCAL_YEAR) from fiscal_years  where company = '55' and status= 'O') FYEAR, 
                                        (select lpad(nvl(max(substr(DOCUMENT_NO,length(DOCUMENT_NO)-2,length(DOCUMENT_NO))) +1,1),3,'0') from Pl_Laptop_Request) MAX_NO 
                                        from hrm_employee E where emp_code='" + EmpCode + "' and status in ('C','P','N')";
                    cmd.CommandType = CommandType.Text;
                    using (OracleDataAdapter da = new OracleDataAdapter(cmd))
                    {
                        da.Fill(ds);
                        objTrans.Commit();
                    }
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
            // throw e;
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
    #region SaveLaptopDesktopRequest
    public int SaveLaptopDesktopRequest(string EmpCode, string DocumentNo, string FileName,string RequestType, string Justification, string ReasonForReplacement, string ProvideDetailsIncident)
    {
        int success = 0;
        OracleTransaction objTrans = null;
        try
        {
            using (OracleConnection con = new ConnectionCode().getConnection())
            {
                objTrans = con.BeginTransaction();
                using (OracleCommand cmd = con.CreateCommand())
                {
                    cmd.CommandText = @"INSERT INTO Pl_Laptop_Request (Emp_Code, Document_No, Fire_Copy_Path,Request_Type,Justification,Reason_For_Replacement,Detail_Incident,Created_By,Status_Id) 
                                        VALUES (:EmpCode, :DocumentNo, :FileName, :RequestType, :Justification, :ReasonForReplacement, :ProvideDetailsIncident, :CreatedBy,6) RETURNING Request_Id INTO :LastId";

                    // Use distinct parameter names to avoid conflicts
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "EmpCode", DbType = DbType.String, Value = EmpCode });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "DocumentNo", DbType = DbType.String, Value = DocumentNo });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "FileName", DbType = DbType.String, Value = FileName });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "RequestType", DbType = DbType.String, Value = RequestType });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "Justification", DbType = DbType.String, Value = Justification });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "ReasonForReplacement", DbType = DbType.String, Value = ReasonForReplacement });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "ProvideDetailsIncident", DbType = DbType.String, Value = ProvideDetailsIncident });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "CreatedBy", DbType = DbType.String, Value = EmpCode });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "LastId", OracleDbType = OracleDbType.Int32, Direction = ParameterDirection.ReturnValue });

                    success = cmd.ExecuteNonQuery();

                    // Retrieve the last inserted ID
                    OracleDecimal oracleDecimal = (OracleDecimal)cmd.Parameters["LastId"].Value;
                    success = oracleDecimal.ToInt32();

                    objTrans.Commit();
                }
            }
        }
        catch (Exception ex)
        {
            objTrans.Rollback();
        }

        return success;
    }
    #endregion
    #region GetLaptopApprovalList
    public DataSet GetLaptopApprovalList(string EmpCode)
    {
        DataSet ds = new DataSet();
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    cmd.CommandText = @"select case when CO_REVIEWER is not null then CO_REVIEWER else Reviewer end as Emp_Code,
                                        INITCAP((select Employee_Name from hrm_employee where Emp_Code = (SELECT case when e1.CO_REVIEWER is not null then e1.CO_REVIEWER else e1.Reviewer end 
                                        FROM hrm_employee e1 WHERE e1.Emp_Code = '" + EmpCode + "')))Employee_Name,1 as level_Id from hrm_employee " +
                                        "where Emp_Code = '" + EmpCode + "' union all select am.Emp_Code,INITCAP(e1.Employee_Name)Employee_Name,am.Level_Id " +
                                        "from PL_Laptop_Approver am left Join hrm_employee e1 on e1.Emp_Code = am.Emp_Code where am.Level_Id in (2,3,4,5)";
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "@EmpCode", DbType = DbType.String, Value = EmpCode });
                    using (OracleDataAdapter da = new OracleDataAdapter(cmd))
                    {
                        da.Fill(ds);
                        objTrans.Commit();
                    }
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
    #region GetLaptopApproverDetails
    public DataSet GetLaptopApproverDetails(string RequestId)
    {
        DataSet ds = new DataSet();
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    cmd.CommandText = @"select ar.Approval_Id,ar.Request_Id,ar.Emp_Code,INITCAP(Employee_Name)Employee_Name,ar.Level_Id,ar.Action_On,ar.comments,
                        ar.status_Id,s.Status_Name from Pl_Laptop_APPROVAL_REQ ar left Join hrm_employee e1 on e1.Emp_Code = ar.Emp_Code
                        left join Pl_Status s on s.Status_Id = ar.Status_Id where Request_Id = '" + RequestId + "' order by ar.Level_Id";
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "@RequestId", DbType = DbType.String, Value = RequestId });
                    using (OracleDataAdapter da = new OracleDataAdapter(cmd))
                    {
                        da.Fill(ds);
                        objTrans.Commit();
                    }
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
    #region ForwaredLaptopRequestToApprover
    public int ForwaredLaptopRequestToApprover(string requestId, string approverEmpCode, string approverLevelId, string statusId)
    {
        int success = 0;

        try
        {
            using (OracleConnection con = new ConnectionCode().getConnection())
            {
                using (OracleCommand cmd = con.CreateCommand())
                {
                    cmd.CommandText = "INSERT INTO Pl_APPROVALREQUEST (Request_ID, EMP_CODE, Level_ID, Status_Id)" +
                        " VALUES (:RequestId, :approverEmpCode, :ApproverLevelId, :StatusId)";

                    cmd.Parameters.Add(new OracleParameter { ParameterName = "RequestId", DbType = DbType.String, Value = requestId });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "approverEmpCode", DbType = DbType.String, Value = approverEmpCode });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "ApproverLevelId", DbType = DbType.String, Value = approverLevelId });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "StatusId", DbType = DbType.String, Value = statusId });

                    success = cmd.ExecuteNonQuery();
                }
            }
        }
        catch (Exception ex)
        {
            // Log the exception or handle it appropriately
            throw;
        }

        return success;
    }

    #endregion
    #region getLaptopRequestList
    public DataSet getLaptopRequestList(string RequestId)
    {
        DataSet ds = new DataSet();
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    // cmd.CommandText = "PL_Usp_GetUserDetails";
                    //cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = @"select REQUEST_ID,DOCUMENT_NO,ia.EMP_CODE,REQUEST_TYPE,JUSTIFICATION,REASON_FOR_REPLACEMENT,DETAIL_INCIDENT,FIRE_COPY_PATH,LAPTOP_ASSIGNED,
                                        DLP_UNINSTALLED,S1_UNINSTALLED,Ia.Status_Id,Ia.Created_at,e.Employee_Name as RequestorName,(SELECT e2.Employee_Name FROM hrm_employee e2 where e2.emp_Code in 
                                        (SELECT e1.Func_Reportg FROM hrm_employee e1 WHERE e1.Emp_Code = Ia.Emp_Code))HodName,
                                        INITcap(hris_get.dept_code(hcf_pkg.dept_code(e.Company,Ia.Emp_Code)))as Department,REQUEST_TYPE,e.Off_Mobile_No,Email_Id,Desig_NM
                                        from  Pl_Laptop_Request Ia
                                        left join hrm_employee e on e.Emp_Code= Ia.Emp_code
                                        inner join hrm_Designation deg on deg.Desig_Code = e.Desig_Code where Request_Id = '" + RequestId + "'";
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "@RequestId", DbType = DbType.String, Value = RequestId });
                    using (OracleDataAdapter da = new OracleDataAdapter(cmd))
                    {
                        da.Fill(ds);
                        objTrans.Commit();
                    }
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
            // throw e;
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
    #region GetListOfLaptopRequest
    public DataSet GetListOfLaptopRequest(string EmpCode, string DocumentType)
    {
        DataSet ds = new DataSet();
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    if (DocumentType.Equals("My Request"))
                    {
                        cmd.CommandText = @"select (SELECT INITCAP(e1.Employee_Name) FROM hrm_employee e1 WHERE e1.Emp_Code = (select Emp_Code from Pl_Laptop_APPROVAL_REQ where REQUEST_ID = IA.REQUEST_ID and LEVEL_ID = 1))HodName,
                                            REQUEST_ID,DOCUMENT_NO,ia.EMP_CODE,REQUEST_TYPE,JUSTIFICATION,REASON_FOR_REPLACEMENT,DETAIL_INCIDENT,FIRE_COPY_PATH,LAPTOP_ASSIGNED,
                                            DLP_UNINSTALLED,S1_UNINSTALLED,IA.CREATED_BY,e.Employee_Name as RequestorName,IA.CREATED_at,IA.STATUS_ID,s.Status_Name,
                                            INITcap(hris_get.dept_code(hcf_pkg.dept_code(e.Company,IA.Emp_Code)))as Department 
                                            from Pl_Laptop_Request IA
                                            left join hrm_employee e on IA.Emp_Code = e.Emp_Code
                                            left join PL_STATUS s on s.Status_Id = IA.Status_Id
                                             where IA.STATUS not in ('I') and IA.Emp_Code = '" + EmpCode + "' order by IA.CREATED_at desc";
                    }
                    else if (DocumentType.Equals("Pending Request"))
                    {
                        cmd.CommandText = @"select (SELECT INITCAP(e1.Employee_Name) FROM hrm_employee e1 WHERE e1.Emp_Code = (select Emp_Code from Pl_Laptop_APPROVAL_REQ where REQUEST_ID = IA.REQUEST_ID and LEVEL_ID = 1))HodName,
                                            REQUEST_ID,DOCUMENT_NO,ia.EMP_CODE,REQUEST_TYPE,JUSTIFICATION,REASON_FOR_REPLACEMENT,DETAIL_INCIDENT,FIRE_COPY_PATH,LAPTOP_ASSIGNED,
                                            DLP_UNINSTALLED,S1_UNINSTALLED,IA.CREATED_BY,e.Employee_Name as RequestorName,IA.CREATED_at,IA.STATUS_ID,s.Status_Name,
                                            INITcap(hris_get.dept_code(hcf_pkg.dept_code(e.Company,IA.Emp_Code)))as Department 
                                            from Pl_Laptop_Request IA 
                                            left join hrm_employee e on IA.Emp_Code = e.Emp_Code 
                                            left join PL_STATUS s on s.Status_Id = IA.Status_Id 
                                            where IA.STATUS not in ('I') and Request_Id in (select Request_Id from Pl_Laptop_APPROVAL_REQ where Pl_Laptop_APPROVAL_REQ.Emp_Code = '" + EmpCode + "'  and Status_Id = 3) " +
                                            "and Ia.Status_Id = 6 order by IA.CREATED_at desc";
                    }
                    else if (DocumentType.Equals("Approved Request"))
                    {
                        cmd.CommandText = @"select (SELECT INITCAP(e1.Employee_Name) FROM hrm_employee e1 WHERE e1.Emp_Code = (select Emp_Code from Pl_Laptop_APPROVAL_REQ where REQUEST_ID = IA.REQUEST_ID and LEVEL_ID = 1))HodName,
                                            REQUEST_ID,DOCUMENT_NO,ia.EMP_CODE,REQUEST_TYPE,JUSTIFICATION,REASON_FOR_REPLACEMENT,DETAIL_INCIDENT,FIRE_COPY_PATH,LAPTOP_ASSIGNED,
                                            DLP_UNINSTALLED,S1_UNINSTALLED,IA.CREATED_BY,e.Employee_Name as RequestorName,IA.CREATED_at,IA.STATUS_ID,s.Status_Name,
                                            INITcap(hris_get.dept_code(hcf_pkg.dept_code(e.Company,IA.Emp_Code)))as Department  
                                            from Pl_Laptop_Request IA 
                                            left join hrm_employee e on IA.Emp_Code = e.Emp_Code 
                                            left join PL_STATUS s on s.Status_Id = IA.Status_Id where IA.STATUS not in ('I') and 
                                            Request_Id in (select Request_Id from Pl_Laptop_APPROVAL_REQ where Pl_Laptop_APPROVAL_REQ.Emp_Code = '" + EmpCode + "'  and " +
                                            "Status_Id in (4,7)) order by IA.CREATED_at desc";
                    }
                    else if (DocumentType.Equals("Rejected Request"))
                    {
                        cmd.CommandText = @"select (SELECT INITCAP(e1.Employee_Name) FROM hrm_employee e1 WHERE e1.Emp_Code = (select Emp_Code from Pl_Laptop_APPROVAL_REQ where REQUEST_ID = IA.REQUEST_ID and LEVEL_ID = 1))HodName,
                                            REQUEST_ID,DOCUMENT_NO,ia.EMP_CODE,REQUEST_TYPE,JUSTIFICATION,REASON_FOR_REPLACEMENT,DETAIL_INCIDENT,FIRE_COPY_PATH,LAPTOP_ASSIGNED,
                                            DLP_UNINSTALLED,S1_UNINSTALLED,IA.CREATED_BY,e.Employee_Name as RequestorName,IA.CREATED_at,IA.STATUS_ID,s.Status_Name,
                                            INITcap(hris_get.dept_code(hcf_pkg.dept_code(e.Company,IA.Emp_Code)))as Department  
                                            from Pl_Laptop_Request IA 
                                            left join hrm_employee e on IA.Emp_Code = e.Emp_Code 
                                            left join PL_STATUS s on s.Status_Id = IA.Status_Id where IA.STATUS not in ('I') and 
                                            Request_Id in (select Request_Id from Pl_Laptop_APPROVAL_REQ where Pl_Laptop_APPROVAL_REQ.Emp_Code = '" + EmpCode + "'  " +
                                            "and Status_Id = 5) order by IA.CREATED_at desc";
                    }
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "@EmpCode", DbType = DbType.String, Value = EmpCode });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "@DocumentType", DbType = DbType.String, Value = DocumentType });
                    using (OracleDataAdapter da = new OracleDataAdapter(cmd))
                    {
                        da.Fill(ds);
                        objTrans.Commit();
                    }
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
}