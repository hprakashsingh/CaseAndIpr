﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Data;
/// <summary>
/// Summary description for IprRenewalRegis
/// </summary>
public class IprRenewalRegis
{
    #region VariableDeclaration
    OracleConnection con;
    ConnectionCode sCon;
    OracleCommand cmd;
    #endregion
    #region GetIprList
    public DataSet GetIprList(string EmpCode)
    {
        DataSet ds = new DataSet();
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    // Query 0 with parameter
                    string query1 = @"select IRR_RECID,IPR_CODE,CATEGORY_DESC,REG_NO,MASK_DESC,ENTRY_DATE,RENEW_DATE,ipr.CREATED_BY,initcap(e.EMPLOYEE_NAME)CreatedByName,
                                        ipr.CREATED_ON,ipr.LAST_UPD_BY,initcap(e1.EMPLOYEE_NAME)UpdatedByName,ipr.LAST_UPD_ON,nvl(ATT1,'NA')ATT1,nvl(ATT2,'NA')ATT2,ATT3,
                                        nvl(TRADE_IMG_PATH,'NA')TRADE_IMG_PATH,nvl(BRAND_IMG_PATH,'NA')BRAND_IMG_PATH
                                        from IPR_REG_RENEW ipr
                                        left join hrm_employee e on e.EMP_CODE = ipr.CREATED_BY
                                        left join hrm_employee e1 on e1.EMP_CODE = ipr.LAST_UPD_BY
                                        order by 1 desc";
                    OracleDataAdapter adapter1 = new OracleDataAdapter(query1, con);
                    //adapter1.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Int32).Value = EmpCode;
                    DataTable dataTable1 = new DataTable("Table1");
                    adapter1.Fill(dataTable1);
                    ds.Tables.Add(dataTable1);

                    // Query 1 with parameter
                    string query2 = @"select IRR_RECID,IPR_CODE,CATEGORY_DESC,REG_NO,MASK_DESC,ENTRY_DATE,RENEW_DATE,ipr.CREATED_BY,initcap(e.EMPLOYEE_NAME)CreatedByName,
                                        ipr.CREATED_ON,ipr.LAST_UPD_BY,initcap(e1.EMPLOYEE_NAME)UpdatedByName,ipr.LAST_UPD_ON,nvl(ATT1,'NA')ATT1,nvl(ATT2,'NA')ATT2,ATT3,
                                        nvl(TRADE_IMG_PATH,'NA')TRADE_IMG_PATH,nvl(BRAND_IMG_PATH,'NA')BRAND_IMG_PATH
                                        from IPR_REG_RENEW ipr
                                        left join hrm_employee e on e.EMP_CODE = ipr.CREATED_BY
                                        left join hrm_employee e1 on e1.EMP_CODE = ipr.LAST_UPD_BY
                                        where  TRUNC(ipr.CREATED_ON) < TRUNC(ADD_MONTHS(SYSDATE, -60))
                                        order by 1 desc";
                    OracleDataAdapter adapter2 = new OracleDataAdapter(query2, con);
                    //adapter1.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Int32).Value = EmpCode;
                    DataTable dataTable2 = new DataTable("Table2");
                    adapter2.Fill(dataTable2);
                    ds.Tables.Add(dataTable2);

                    //// Query 2 with parameter
                    //string query3 = @"select Lg_Cases_Id,Category,Legal_Person_Handling,In_House_Req,Next_Date,Purpose_Fixed,Priority,Case_Title,For_Against_Ds,Court,City,
                    //                Product_Property,Issue_Offence,Advocate_Name,lc.Status,lc.Created_By,lc.Created_On,Case_No,Last_Date,lc.Updated_By,lc.Updated_On,
                    //                initcap(e.Employee_Name)CreatedByName,
                    //                initcap(e1.Employee_Name)UpdatedByName
                    //                from Lg_Litigation_Cases lc
                    //                left join Hrm_Employee e on e.Emp_Code = lc.Created_By
                    //                left join Hrm_Employee e1 on e1.Emp_Code = lc.Updated_By where Case_No = '" + CaseNo + "' order by 1 desc";
                    //OracleDataAdapter adapter3 = new OracleDataAdapter(query3, con);
                    ////adapter1.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Int32).Value = EmpCode;
                    //DataTable dataTable3 = new DataTable("Table3");
                    //adapter3.Fill(dataTable3);
                    //ds.Tables.Add(dataTable3);
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
            // throw e;
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
    #region AddUpdateIprDetails
    public int AddUpdateIprDetails(string EmpCode, string IprRecId, string DocumentNo, string Category, string RegistrationNo, string EntryDate, 
        string RenewalDate, string Mark, string TradeFileName, string BrandFileName)
    {
        int success = 0;

        try
        {
            using (OracleConnection con = new ConnectionCode().getConnection())
            {
                if (IprRecId == "")
                {
                    using (OracleCommand cmd = con.CreateCommand())
                    {
                        cmd.CommandText = @"INSERT INTO IPR_REG_RENEW (IRR_RECID,IPR_CODE,CATEGORY_DESC,REG_NO,MASK_DESC,ENTRY_DATE,RENEW_DATE,TRADE_IMG_PATH,BRAND_IMG_PATH,STATUS,CREATED_BY,CREATED_ON)" +
                            " VALUES (portal_recid.nextval, '" + DocumentNo + "','" + Category + "', '" + RegistrationNo + "', '" + Mark + "', to_date('" + EntryDate + "', 'dd/mm/yyyy'), to_date('" + RenewalDate + "', 'dd/mm/yyyy'),'" + TradeFileName + "'," +
                            "'" + BrandFileName + "','A','" + EmpCode + "', sysdate)";

                        success = cmd.ExecuteNonQuery();
                    }
                }
                else if (IprRecId != "")
                {
                    using (OracleCommand cmd = con.CreateCommand())
                    {
                        cmd.CommandText = @"update IPR_REG_RENEW set CATEGORY_DESC = '" + Category + "',REG_NO = '" + RegistrationNo + "',MASK_DESC = '" + Mark + "',ENTRY_DATE = '" + EntryDate + "'," +
                            "RENEW_DATE = '" + RenewalDate + "',LAST_UPD_BY = '" + EmpCode + "',LAST_UPD_ON = sysdate where IRR_RECID = '" + IprRecId + "'";

                        success = cmd.ExecuteNonQuery();
                    }
                }
            }
        }
        catch (Exception ex)
        {
            // Log the exception or handle it appropriately
            throw;
        }

        return success;
    }

    #endregion
    #region GetDocumentNo
    public DataSet GetDocumentNo(string EmpCode)
    {
        DataSet ds = new DataSet();
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    // Query 0 with parameter
                    string query1 = @"select EMP_CODE,UNIT_CODE, hris_get.func_code(e.func_code) func_code_desc,CD_CODE,ADMIN_REPORTG,FUNC_REPORTG,MOBILE_NO,
                                    (select SBU_CODE from  oc_sbu_mapping where ou_code=E.company and rownum=1)  BUSS_CODE,
                                    (select ENTITY_CODE from  oc_sbu_mapping where ou_code=E.company and rownum=1) ENTITY_CODE,
                                    FUNC_CODE, EUIN_CODE,(select max(FISCAL_YEAR) from fiscal_years  where company = '55' and status= 'O') FYEAR,
                                     (select lpad(nvl(max(substr(IPR_CODE,length(IPR_CODE)-2,length(IPR_CODE))) +1,1),4,'0') from IPR_REG_RENEW) MAX_NO
                                     from hrm_employee E where emp_code='" + EmpCode + "' and status in ('C','P','N')";
                    OracleDataAdapter adapter1 = new OracleDataAdapter(query1, con);
                    //adapter1.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Int32).Value = EmpCode;
                    DataTable dataTable1 = new DataTable("Table1");
                    adapter1.Fill(dataTable1);
                    ds.Tables.Add(dataTable1);
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
            // throw e;
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
}