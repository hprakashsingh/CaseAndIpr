﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Data;

/// <summary>
/// Summary description for LoginModule
/// </summary>
public class LoginModule
{
    #region Variable Declaration
    OracleConnection con;
    ConnectionCode sCon;
    OracleCommand cmd;
    #endregion
    #region GetUserDetailsForAutoLogin
    public DataSet GetUserDetailsForAutoLogin(string EmailId)
    {
        DataSet ds = new DataSet();
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    // Query 0 with parameter
                    string query1 = @"select e.Dept_Code,(DESCRIPTION)Dept_Name,TITLE,EMP_CODE,EMAIL_ID,INITCAP(Employee_Name)EMPLOYEE_NAME
                                    from hrm_employee e
                                    left join hrm_Department d on d.Dept_Code = e.Dept_Code 
                                    where e.EMAIL_ID = '" + EmailId + "'";
                    OracleDataAdapter adapter1 = new OracleDataAdapter(query1, con);
                    adapter1.SelectCommand.Parameters.Add("@EmailId", OracleDbType.Int32).Value = EmailId;
                    DataTable dataTable1 = new DataTable("Table1");
                    adapter1.Fill(dataTable1);
                    ds.Tables.Add(dataTable1);
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
    #region AddUserLocation
    public int AddUserLocation(string MobileNo,string UserId, string StateId, string DistrictId,string StatusId)
    {
        int success = 0;
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    cmd.CommandText = @"INSERT INTO PoP_User_State_Mapping (MAPPING_ID,USER_ID,STATE_ID,DISTRICT_ID,STATUS_ID,CREATED_BY,CREATED_ON)
                            values (PoP_ID_Seq.nextval,'" + UserId + "','" + StateId + "','" + DistrictId + "','" + StatusId + "','" + MobileNo + "',sysdate)";
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "UserId", DbType = DbType.String, Value = UserId });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "StateId", DbType = DbType.String, Value = StateId });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "DistrictId", DbType = DbType.String, Value = DistrictId });
                    cmd.Parameters.Add(new OracleParameter { ParameterName = "MobileNo", DbType = DbType.String, Value = MobileNo });
                    success = cmd.ExecuteNonQuery();
                    objTrans.Commit();
                }
            }
        }
        catch (Exception ex)
        {
            objTrans.Rollback();
            throw ex;
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return success;
    }
    #endregion
}