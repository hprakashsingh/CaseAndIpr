﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ApiSalesData_SalesOrderData : System.Web.UI.Page
{
    #region VariableDeclare
    ApiSalesOrder obj = new ApiSalesOrder();
    #endregion
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            txtFromDate.Attributes["max"] = DateTime.Now.ToString("yyyy-MM-dd");
            txtToDate.Attributes["max"] = DateTime.Now.ToString("yyyy-MM-dd");
            txtToDate.Text = DateTime.Now.ToString("yyyy-MM-dd");
            if (Session["EmpCode"] != null)
            {
                if (!string.IsNullOrEmpty(Request.QueryString["ReportType"]))
                {
                    hndReportType.Value = CommonUtility.Decryption(HttpUtility.UrlDecode(Request.QueryString["ReportType"].ToString()));
                    if (hndReportType.Value.Equals("INACTIVE"))
                    {
                        hndWhereCondition.Value = hndWhereCondition.Value + " and SAP_INVOICE_NO = '" + hndReportType.Value + "'" ;
                    }
                    else if (hndReportType.Value.Equals("ACTIVE"))
                    {
                        hndWhereCondition.Value = hndWhereCondition.Value + " and SAP_INVOICE_NO IS NULL";
                    }
                }
                else
                {
                    hndWhereCondition.Value = hndWhereCondition.Value + " and SAP_INVOICE_NO IS NULL";
                }
                GetSalesOrderData(hndWhereCondition.Value);
            }
        }
    }
    #region GetSalesOrderData
    private void GetSalesOrderData(string WhereCondition="")
    {
        try
        {
            DataSet ds = obj.GetSalesOrderData(Session["EmpCode"].ToString(), WhereCondition);
            if (ds.Tables[0].Rows.Count > 0)
            {
                btnExcelExport.Visible = true;
                GrdSalesOrderData.DataSource = ds.Tables[0];
                GrdSalesOrderData.DataBind();
            }
            else
            {
                btnExcelExport.Visible = false;
                GrdSalesOrderData.DataSource = null;
                GrdSalesOrderData.DataBind();
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region UpdateStatus
    protected void btnUpdateStatus_Click(object sender, EventArgs e)
    {
        int success = 0;
        int counter = 0;
        string connectionString = ConfigurationManager.ConnectionStrings["GstDbConnect"].ConnectionString;
        // Create a connection to the Oracle database
        using (OracleConnection conn = new OracleConnection(connectionString))
        {
            conn.Open();
            OracleTransaction transaction = conn.BeginTransaction();
            try
            {
                foreach (GridViewRow row in GrdSalesOrderData.Rows)
                {
                    if (row.RowType == DataControlRowType.DataRow)
                    {
                        CheckBox chkRow = (row.Cells[0].FindControl("chkRow") as CheckBox);
                        if (chkRow.Checked)
                        {
                            string ASO_RECID = (row.Cells[1].FindControl("hndASO_RECID") as HiddenField).Value;
                            string SAP_INVOICE_NO = (row.Cells[1].FindControl("hndSAP_INVOICE_NO") as HiddenField).Value;
                            success = obj.UpdateSalesOrderStatus(Session["EmpCode"].ToString(), ASO_RECID, SAP_INVOICE_NO == "" ? "INACTIVE" : "", conn, transaction);
                            counter++;
                        }
                    }
                }
                if (counter == 0)
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "showErrorToast", "showToast('error', 'Please select at least one Sales order to update the status.', 'Error');", true);
                    return;
                }
                if (success > 0)
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "showSuccessToast", "showToast('success', 'Sales Order status is successfully updated.', 'Success');", true);
                    transaction.Commit(); // Commit the transaction
                    GetSalesOrderData(hndWhereCondition.Value);
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "showErrorToast", "showToast('error', 'Due to technical or network connectivity issue.The sales oredr data status is not updated. Please try again later!', 'Error');", true);
                    transaction.Rollback(); // Rollback the transaction
                }
            }
            catch (Exception ex)
            {
                transaction.Rollback(); // Rollback the transaction
                throw ex;
            }
        }
    }
    #endregion
    #region SearchRecord
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        try
        {
            if (txtFromDate.Text != "")
            {
                hndWhereCondition.Value = hndWhereCondition.Value + " and CREATED_ON >=  TO_DATE('" + txtFromDate.Text.Trim() + "','yyyy-mm-dd')  ";
            }
            if (txtToDate.Text != "")
            {
                hndWhereCondition.Value = hndWhereCondition.Value + " and CREATED_ON <= TO_DATE('" + txtToDate.Text.Trim() + "','yyyy-MM-dd') ";
            }
            if (txtOrderID.Text != "")
            {
                hndWhereCondition.Value = hndWhereCondition.Value + " and ORDERID = '" + txtOrderID.Text.Trim() + "'";
            }
            if (txtCustomerID.Text != "")
            {
                hndWhereCondition.Value = hndWhereCondition.Value + " and CUSTOMERID = '" + txtCustomerID.Text.Trim() + "'";
            }
            if (txtProductID.Text != "")
            {
                hndWhereCondition.Value = hndWhereCondition.Value + " and PRODUCTID = '" + txtProductID.Text.Trim() + "'";
            }
            if (txtMobileNumber.Text != "")
            {
                hndWhereCondition.Value = hndWhereCondition.Value + " and (SELECT BILL_PHONENUMBER FROM API_CUSTOMERS WHERE ORDERID =  A.ORDERID) = '" + txtMobileNumber.Text.Trim() + "'";
            }
            GetSalesOrderData(hndWhereCondition.Value);
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region ClearFilter
    protected void btnViewAll_Click(object sender, EventArgs e)
    {
        try
        {
            txtFromDate.Text = "";
            txtToDate.Text = DateTime.Now.ToString("yyyy-MM-dd");
            txtOrderID.Text = "";
            txtCustomerID.Text = "";
            txtMobileNumber.Text = "";
            txtProductID.Text = "";
            hndWhereCondition.Value = "";
            if (!string.IsNullOrEmpty(Request.QueryString["ReportType"]))
            {
                hndReportType.Value = CommonUtility.Decryption(HttpUtility.UrlDecode(Request.QueryString["ReportType"].ToString()));
                if (hndReportType.Value.Equals("INACTIVE"))
                {
                    hndWhereCondition.Value = hndWhereCondition.Value + " and SAP_INVOICE_NO = '" + hndReportType.Value + "'";
                }
                else if (hndReportType.Value.Equals("ACTIVE"))
                {
                    hndWhereCondition.Value = hndWhereCondition.Value + " and SAP_INVOICE_NO IS NULL";
                }
            }
            else
            {
                hndWhereCondition.Value = hndWhereCondition.Value + " and SAP_INVOICE_NO IS NULL";
            }
            GetSalesOrderData(hndWhereCondition.Value);
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region RestrictCalender
    protected void txtFromDate_TextChanged(object sender, EventArgs e)
    {
        try
        {
            txtToDate.Attributes["min"] = Convert.ToDateTime(txtFromDate.Text).ToString("yyyy-MM-dd");
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region PageChangeCode
    protected void GrdSalesOrderData_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            GrdSalesOrderData.PageIndex = e.NewPageIndex;
            this.GetSalesOrderData(hndWhereCondition.Value);
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region ExportDataToExcel
    protected void btnExcelExport_Click(object sender, EventArgs e)
    {
        try
        {
            ExportGridViewToExcel();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region ExportGridViewToExcel
    private void ExportGridViewToExcel()
    {
        Response.Clear();
        Response.Buffer = true;
        Response.AddHeader("content-disposition", "attachment;filename=ApiSalesOrder.xls");
        Response.Charset = "";
        Response.ContentType = "application/vnd.ms-excel";

        using (StringWriter sw = new StringWriter())
        {
            HtmlTextWriter hw = new HtmlTextWriter(sw);

            // To Export all pages
            GrdSalesOrderData.AllowPaging = false;
            this.GetSalesOrderData(hndWhereCondition.Value);

            // This is to ensure that the gridview is formatted correctly in Excel
            GrdSalesOrderData.HeaderRow.BackColor = System.Drawing.Color.Green;
            GrdSalesOrderData.HeaderRow.ForeColor = System.Drawing.Color.White;
            GrdSalesOrderData.Columns[0].Visible = false;
            foreach (TableCell cell in GrdSalesOrderData.HeaderRow.Cells)
            {
                cell.BackColor = GrdSalesOrderData.HeaderStyle.BackColor;
                cell.Font.Size = FontUnit.Point(12);
            }
            foreach (GridViewRow row in GrdSalesOrderData.Rows)
            {
                row.BackColor = System.Drawing.Color.White;
                foreach (TableCell cell in row.Cells)
                {
                    if (row.RowIndex % 2 == 0)
                    {
                        cell.BackColor = System.Drawing.Color.White;
                        cell.ForeColor = System.Drawing.Color.Black;
                        cell.Font.Size = FontUnit.Point(10);
                    }
                    else
                    {
                        cell.BackColor = System.Drawing.Color.White;
                        cell.ForeColor = System.Drawing.Color.Black;
                        cell.Font.Size = FontUnit.Point(10);
                    }
                    cell.CssClass = "textmode";
                }
            }

            GrdSalesOrderData.RenderControl(hw);

            // Style to format numbers to text
            string style = @"<style> .textmode { mso-number-format:\@; } </style>";
            Response.Write(style);
            Response.Output.Write(sw.ToString());
            Response.Flush();
            Response.End();
        }
    }
    #endregion
    #region VerifyRenderingInServerForm
    public override void VerifyRenderingInServerForm(Control control)
    {
        // Confirms that an HtmlForm control is rendered for the specified ASP.NET
        // server control at run time. Required for GridView export to Excel
    }
    #endregion
}