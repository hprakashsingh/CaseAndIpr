﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ApiSalesData_Dashboard : System.Web.UI.Page
{
    #region
    ApiSalesOrder obj = new ApiSalesOrder();
    protected string TotalOrder = string.Empty;
    protected string TotalActiveOrder = string.Empty;
    protected string TotalInActiveOrder = string.Empty;
    #endregion
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["EmpCode"] != null)
            {
                GetDashboardData();
            }
        }
    }
    #region GetDashboardData
    private void GetDashboardData()
    {
        try
        {
            DataSet ds = obj.GetDashboardData(Session["EmpCode"].ToString());
            if (ds.Tables[0].Rows.Count > 0)
            {
                TotalOrder = ds.Tables[0].Rows[0]["TotalOrder"].ToString();
                TotalActiveOrder = ds.Tables[0].Rows[1]["TotalOrder"].ToString();
                TotalInActiveOrder = ds.Tables[0].Rows[2]["TotalOrder"].ToString();
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
}