﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Dashboard : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            // Generate a new CSRF token
            ViewState["CSRFToken"] = Guid.NewGuid().ToString();
            hiddenCsrfToken.Value = ViewState["CSRFToken"].ToString();
            //// Success Toast
            //ScriptManager.RegisterStartupScript(this, this.GetType(), "showSuccessToast", "showToast('success', 'Operation completed successfully.', 'Success');", true);

            //// Error Toast
            //ScriptManager.RegisterStartupScript(this, this.GetType(), "showErrorToast", "showToast('error', 'User Id And Password is not correct.', 'Error');", true);

            //// Info Toast
            //ScriptManager.RegisterStartupScript(this, this.GetType(), "showInfoToast", "showToast('info', 'Here is some important information.', 'Information');", true);

            //// Warning Toast
            //ScriptManager.RegisterStartupScript(this, this.GetType(), "showWarningToast", "showToast('warning', 'This is a warning message.', 'Warning');", true);
        }
    }
}