﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace DataAccess
{
    public class GlobalConnection
    {

        static protected readonly string connectionstring = string.Empty;
        protected SqlCommand dbCommand;
        protected SqlDataAdapter dbAdapter;
        protected SqlDataReader dbDataReader;
        protected DataTable dbDataTable;
        protected DataSet dbDataSet;
        protected SqlTransaction dbTransaction;
        protected SqlConnection dbConnection;

        static GlobalConnection()
        {
            connectionstring = ConfigurationManager.ConnectionStrings["ELPConnectionString"].ToString();

            if (string.IsNullOrEmpty(connectionstring))
            {
                throw new Exception("Connection String Not Set");
            }
        }
    }
}
