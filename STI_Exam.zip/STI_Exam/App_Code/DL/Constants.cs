﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataAccess
{
    public class Constants
    {
        #region Login
        public static string Usp_UserLoginDetails = "Usp_UserLoginDetails";
        public static string Usp_GetBatchList = "Usp_GetBatchList";
        public static string Usp_SaveBatchDetails = "Usp_SaveBatchDetails";
        public static string Usp_SaveUserDetails = "Usp_SaveUserDetails";
        public static string Usp_GetUserList = "Usp_GetUserList";
        public static string Usp_SaveCandidateDetails = "Usp_SaveCandidateDetails";
        public static string Usp_SaveCourseDetails = "Usp_SaveCourseDetails";
        public static string Usp_GetCourseLis = "Usp_GetCourseLis";
        public static string Usp_GetCandidateDetails = "Usp_GetCandidateDetails";
        public static string Usp_GetOldPassEmployee = "Usp_GetOldPassEmployee";
        public static string Usp_GetDashboardData = "Usp_GetDashboardData";
        public static string Usp_GetCandidateReport = "Usp_GetCandidateReport";
        public static string Usp_GetOldPassEmp = "Usp_GetOldPassEmp";
        public static string Update_passforEmp = "Update_passforEmp";
        #endregion
        public static string AuditLogDetails = "Usp_AuditTrail";
    }
}
