﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess
{
    class ELPConnection
    {

        public string strCon; // Public variable to hold connection string
        /// <summary>
        /// Class Constructor to initialize ElekhaConnect class instance.
        /// </summary>
        public ELPConnection()
        {
            strCon = ConfigurationManager.ConnectionStrings["ELPConnectionString"].ConnectionString;
        }
        /// <summary>
        /// Obtains Data Base Connection
        /// </summary>
        /// <returns>An opened SqlConnection object</returns>
        public SqlConnection getConnection()
        {
            SqlConnection dbCon = null;
            try
            {
                dbCon = new SqlConnection(strCon);
                dbCon.Open();
            }
            catch (Exception ex)
            {
                if (dbCon.State != ConnectionState.Open)
                {
                    throw new Exception("ConOpenFail");
                }
                throw ex;
            }
            return dbCon;
        }

        /// <summary>
        /// Close DataBase Connection
        /// </summary>
        /// <param name="con">An SqlConnection object</param>
        /// <returns>True, if connection is closed; False, if connection is not closed</returns>
        public bool returnConnection(SqlConnection con)
        {
            if (con != null)
            {
                if (con.State != ConnectionState.Closed)
                    con.Close();
                if (con.State == ConnectionState.Closed)
                {
                    con = null;
                    return true;
                }
                else
                    return false;
            }
            else
                return true;
        }
        public void CloseConnection(SqlConnection con)
        {
            if (con != null)
            {
                if (con.State != ConnectionState.Closed)
                    con.Close();
                if (con.State == ConnectionState.Closed)
                {
                    con = null;
                }
            }
        }
    }
}
