﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using DataAccess;
using System.Data;

/// <summary>
/// Summary description for StiExam
/// </summary>
public class StiExam
{
    #region VariableDeclaration
    SqlConnection con;
    ConnectionCode sCon;
    SqlCommand cmd;
    #endregion
    #region GetDashboardCounter
    public DataSet GetDashboardCounter(string UserId)
    {
        DataSet ds = new DataSet();
        try
        {
            sCon = new ConnectionCode();
            con = new SqlConnection();
            cmd = new SqlCommand();
            using (con = sCon.getConnection())
            {
                using (cmd = con.CreateCommand())
                {
                    cmd.CommandText = "Usp_GetDashboardCounter";
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter { ParameterName = "@UserId", DbType = DbType.String, Value = UserId });
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        da.Fill(ds);
                    }
                }
            }
        }
        catch (Exception e)
        {
            throw e;
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
    #region GetCourseDetails
    public DataSet GetCourseDetails(string UserId,string CourseId = "0")
    {
        DataSet ds = new DataSet();
        try
        {
            sCon = new ConnectionCode();
            con = new SqlConnection();
            cmd = new SqlCommand();
            using (con = sCon.getConnection())
            {
                using (cmd = con.CreateCommand())
                {
                    cmd.CommandText = "Usp_GetCourseDetails";
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter { ParameterName = "@UserId", DbType = DbType.String, Value = UserId });
                    cmd.Parameters.Add(new SqlParameter { ParameterName = "@CourseId", DbType = DbType.String, Value = CourseId });
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        da.Fill(ds);
                    }
                }
            }
        }
        catch (Exception e)
        {
            throw e;
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
    #region AddUpdateCourse
    public int AddUpdateCourse(string UserId, string CourseId, string CourseName, string CourseCode, string StudentLimit, string Status)
    {
        int success = 0;
        try
        {
            sCon = new ConnectionCode();
            con = new SqlConnection();
            cmd = new SqlCommand();
            using (con = sCon.getConnection())
            {
                using (cmd = con.CreateCommand())
                {
                    cmd.CommandText = "Usp_AddUpdateCourse";
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter { ParameterName = "@UserId", DbType = DbType.String, Value = UserId });
                    cmd.Parameters.Add(new SqlParameter { ParameterName = "@CourseId", DbType = DbType.String, Value = CourseId });
                    cmd.Parameters.Add(new SqlParameter { ParameterName = "@CourseName", DbType = DbType.String, Value = CourseName });
                    cmd.Parameters.Add(new SqlParameter { ParameterName = "@CourseCode", DbType = DbType.String, Value = CourseCode });
                    cmd.Parameters.Add(new SqlParameter { ParameterName = "@StudentLimit", DbType = DbType.String, Value = StudentLimit });
                    cmd.Parameters.Add(new SqlParameter { ParameterName = "@Status", DbType = DbType.String, Value = Status });
                    success = cmd.ExecuteNonQuery();
                }
            }
        }
        catch (Exception e)
        {
            throw e;
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return success;
    }
    #endregion
    #region CheckCourseAndCode
    public DataSet CheckCourseAndCode(string UserId, string Flag)
    {
        DataSet ds = new DataSet();
        try
        {
            sCon = new ConnectionCode();
            con = new SqlConnection();
            cmd = new SqlCommand();
            using (con = sCon.getConnection())
            {
                using (cmd = con.CreateCommand())
                {
                    cmd.CommandText = "Usp_CheckCourseAndCode";
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter { ParameterName = "@UserId", DbType = DbType.String, Value = UserId });
                    cmd.Parameters.Add(new SqlParameter { ParameterName = "@Flag", DbType = DbType.String, Value = Flag });
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        da.Fill(ds);
                    }
                }
            }
        }
        catch (Exception e)
        {
            throw e;
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
    #region AddUpdateCandidateDetail
    public int AddUpdateCandidateDetail(string UserId, string CandidateId, string CandidateAadharNumber, string CandidateName, string FatherHusbandName, string MotherName,
        string CandidateQualification, string CandidateApplyForCourse, string CandidateMobileNumber, string GuardianMobileNumber, string Gender, string DateOfBirth, 
        string Cast, string Date, string Place, string Pincode, string Addess, string FileName)
    {
        int success = 0;
        try
        {
            sCon = new ConnectionCode();
            con = new SqlConnection();
            cmd = new SqlCommand();
            using (con = sCon.getConnection())
            {
                using (cmd = con.CreateCommand())
                {
                    cmd.CommandText = "Usp_AddUpdateCandidateDetail";
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter { ParameterName = "@UserId", DbType = DbType.String, Value = UserId });
                    cmd.Parameters.Add(new SqlParameter { ParameterName = "@CandidateId", DbType = DbType.String, Value = CandidateId });
                    cmd.Parameters.Add(new SqlParameter { ParameterName = "@CandidateAadharNumber", DbType = DbType.String, Value = CandidateAadharNumber });
                    cmd.Parameters.Add(new SqlParameter { ParameterName = "@CandidateName", DbType = DbType.String, Value = CandidateName });
                    cmd.Parameters.Add(new SqlParameter { ParameterName = "@FatherHusbandName", DbType = DbType.String, Value = FatherHusbandName });
                    cmd.Parameters.Add(new SqlParameter { ParameterName = "@MotherName", DbType = DbType.String, Value = MotherName });
                    cmd.Parameters.Add(new SqlParameter { ParameterName = "@CandidateQualification", DbType = DbType.String, Value = CandidateQualification });
                    cmd.Parameters.Add(new SqlParameter { ParameterName = "@CandidateApplyForCourse", DbType = DbType.String, Value = CandidateApplyForCourse });
                    cmd.Parameters.Add(new SqlParameter { ParameterName = "@CandidateMobileNumber", DbType = DbType.String, Value = CandidateMobileNumber });
                    cmd.Parameters.Add(new SqlParameter { ParameterName = "@GuardianMobileNumber", DbType = DbType.String, Value = GuardianMobileNumber });
                    cmd.Parameters.Add(new SqlParameter { ParameterName = "@Gender", DbType = DbType.String, Value = Gender });
                    cmd.Parameters.Add(new SqlParameter { ParameterName = "@DateOfBirth", DbType = DbType.String, Value = DateOfBirth });
                    cmd.Parameters.Add(new SqlParameter { ParameterName = "@Cast", DbType = DbType.String, Value = Cast });
                    cmd.Parameters.Add(new SqlParameter { ParameterName = "@Date", DbType = DbType.String, Value = Date });
                    cmd.Parameters.Add(new SqlParameter { ParameterName = "@Place", DbType = DbType.String, Value = Place });
                    cmd.Parameters.Add(new SqlParameter { ParameterName = "@Pincode", DbType = DbType.String, Value = Pincode });
                    cmd.Parameters.Add(new SqlParameter { ParameterName = "@Addess", DbType = DbType.String, Value = Addess });
                    cmd.Parameters.Add(new SqlParameter { ParameterName = "@FileName", DbType = DbType.String, Value = FileName });
                    success = cmd.ExecuteNonQuery();
                }
            }
        }
        catch (Exception e)
        {
            throw e;
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return success;
    }
    #endregion
    #region GetCandidateList
    public DataSet GetCandidateList(string UserId, string CandidateId = "0")
    {
        DataSet ds = new DataSet();
        try
        {
            sCon = new ConnectionCode();
            con = new SqlConnection();
            cmd = new SqlCommand();
            using (con = sCon.getConnection())
            {
                using (cmd = con.CreateCommand())
                {
                    cmd.CommandText = "Usp_GetCandidateList";
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter { ParameterName = "@UserId", DbType = DbType.String, Value = UserId });
                    cmd.Parameters.Add(new SqlParameter { ParameterName = "@CandidateId", DbType = DbType.String, Value = CandidateId });
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        da.Fill(ds);
                    }
                }
            }
        }
        catch (Exception e)
        {
            throw e;
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
    #region GetCandidateWiseCourseList
    public DataSet GetCandidateWiseCourseList(string UserId, string CandidateId = "0", string CourseId = "0")
    {
        DataSet ds = new DataSet();
        try
        {
            sCon = new ConnectionCode();
            con = new SqlConnection();
            cmd = new SqlCommand();
            using (con = sCon.getConnection())
            {
                using (cmd = con.CreateCommand())
                {
                    cmd.CommandText = "Usp_GetCandidateWiseCourseList";
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter { ParameterName = "@UserId", DbType = DbType.String, Value = UserId });
                    cmd.Parameters.Add(new SqlParameter { ParameterName = "@CandidateId", DbType = DbType.String, Value = CandidateId });
                    cmd.Parameters.Add(new SqlParameter { ParameterName = "@CourseId", DbType = DbType.String, Value = CourseId });
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        da.Fill(ds);
                    }
                }
            }
        }
        catch (Exception e)
        {
            throw e;
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
    #region AddMultipleCourse
    public int AddMultipleCourse(string UserId, string CandidateId, string CourseId, string Flag)
    {
        int success = 0;
        try
        {
            sCon = new ConnectionCode();
            con = new SqlConnection();
            cmd = new SqlCommand();
            using (con = sCon.getConnection())
            {
                using (cmd = con.CreateCommand())
                {
                    cmd.CommandText = "Usp_AddMultipleCourse";
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter { ParameterName = "@UserId", DbType = DbType.String, Value = UserId });
                    cmd.Parameters.Add(new SqlParameter { ParameterName = "@CandidateId", DbType = DbType.String, Value = CandidateId });
                    cmd.Parameters.Add(new SqlParameter { ParameterName = "@CourseId", DbType = DbType.String, Value = CourseId });
                    cmd.Parameters.Add(new SqlParameter { ParameterName = "@Flag", DbType = DbType.String, Value = Flag });
                    success = cmd.ExecuteNonQuery();
                }
            }
        }
        catch (Exception e)
        {
            throw e;
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return success;
    }
    #endregion
    #region DeleteRecord
    public int DeleteRecord(string UserId, string RecId, string Flag)
    {
        int success = 0;
        try
        {
            sCon = new ConnectionCode();
            con = new SqlConnection();
            cmd = new SqlCommand();
            using (con = sCon.getConnection())
            {
                using (cmd = con.CreateCommand())
                {
                    cmd.CommandText = "Usp_DeleteRecord";
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter { ParameterName = "@UserId", DbType = DbType.String, Value = UserId });
                    cmd.Parameters.Add(new SqlParameter { ParameterName = "@RecId", DbType = DbType.String, Value = RecId });
                    cmd.Parameters.Add(new SqlParameter { ParameterName = "@Flag", DbType = DbType.String, Value = Flag });
                    success = cmd.ExecuteNonQuery();
                }
            }
        }
        catch (Exception e)
        {
            throw e;
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return success;
    }
    #endregion
}