﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_AddMultipleCourse : System.Web.UI.Page
{
    #region DeclareVariable
    StiExam obj = new StiExam();
    #endregion
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserId"] != null)
            {
                GetCourseDetails();
                GetCandidateCourseDetails();
            }
        }
    }
    #region GetCourseDetails
    private void GetCourseDetails()
    {
        try
        {
            DataSet ds = obj.GetCourseDetails(Session["UserId"].ToString());
            if (ds.Tables[2].Rows.Count > 0)
            {
                ddlCourse.DataSource = ds.Tables[2];
                ddlCourse.DataTextField = "CourseName";
                ddlCourse.DataValueField = "CourseID";
                ddlCourse.DataBind();
                ddlCourse.Items.Insert(0, new ListItem("--Select Course--", ""));
            }
            if (ds.Tables[3].Rows.Count > 0)
            {
                ddlCandidateName.DataSource = ds.Tables[3];
                ddlCandidateName.DataTextField = "CandidateName";
                ddlCandidateName.DataValueField = "CandidateID";
                ddlCandidateName.DataBind();
                ddlCandidateName.Items.Insert(0, new ListItem("--Select Candidate--", ""));
            }
            if (ds.Tables[5].Rows.Count > 0)
            {
                GrdCandidateCourseList.DataSource = ds.Tables[5];
                GrdCandidateCourseList.DataBind();
            }
            else
            {
                GrdCandidateCourseList.DataSource = ds.Tables[5];
                GrdCandidateCourseList.DataBind();
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region GetCandidateCourseDetails
    private void GetCandidateCourseDetails()
    {
        try
        {
            DataSet ds = obj.GetCourseDetails(Session["UserId"].ToString());
            if (ds.Tables[5].Rows.Count > 0)
            {
                GrdCandidateCourseList.DataSource = ds.Tables[5];
                GrdCandidateCourseList.DataBind();
            }
            else
            {
                GrdCandidateCourseList.DataSource = ds.Tables[5];
                GrdCandidateCourseList.DataBind();
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region AddNewCourseForCandidate
    protected void btnAddUpdateCourse_Click(object sender, EventArgs e)
    {
        int success = 0;
        try
        {
            DataSet ds = obj.GetCandidateWiseCourseList(Session["UserId"].ToString(),ddlCandidateName.SelectedValue,ddlCourse.SelectedValue);
            if (ds.Tables[0].Rows.Count > 0)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "showErrorToast", "showToast('error', 'selected course is already added for selected candidate.', 'Error');", true);
            }
            else
            {
                if (ds.Tables[1].Rows.Count > 0)
                {
                    if (Convert.ToInt32(ds.Tables[1].Rows[0]["RemainingSpots"]) > 0)
                    {
                        success = obj.AddMultipleCourse(Session["UserId"].ToString(),ddlCandidateName.SelectedValue,ddlCourse.SelectedValue,"Insert");
                        if(success > 0)
                        {
                            ClearFormData();
                            GetCandidateCourseDetails();
                            ScriptManager.RegisterStartupScript(this, this.GetType(), "showSuccessToast", "showToast('success', 'Course is successfully added to the selected candidate.', 'Success');", true);
                        }
                        else
                        {
                            ScriptManager.RegisterStartupScript(this, this.GetType(), "showErrorToast", "showToast('error', 'Course is not added to the selected candidate. Please try again later!', 'Error');", true);
                        }
                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "showErrorToast", "showToast('error', 'Student limit is full for selected course. Please increase the Student limit of selected course.', 'Error');", true);
                    }
                }
            }
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "showErrorToast", "showToast('error', '" + HttpUtility.JavaScriptStringEncode(ex.Message) + "', 'Error');", true);
        }
    }
    #endregion
    #region ResetPageData
    protected void btnReset_Click(object sender, EventArgs e)
    {
        try
        {
            ClearFormData();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region ClearFormData
    private void ClearFormData()
    {
        try
        {
            ddlCandidateName.SelectedValue = "";
            ddlCourse.SelectedValue = "";
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region DeleteCandidateCourse
    protected void GrdCandidateCourseList_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        int success = 0;
        try
        {
            if (e.CommandName.Equals("DeleteCourse"))
            {
                string StudentCourseID = e.CommandArgument.ToString();
                success = obj.AddMultipleCourse(Session["UserId"].ToString(), "", StudentCourseID, "Delete");
                if (success > 0)
                {
                    GetCandidateCourseDetails();
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "showSuccessToast", "showToast('success', 'Candidate course is successfully deleted.', 'Success');", true);
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "showErrorToast", "showToast('error', 'Candidate course is not deleted. Please try again later!', 'Error');", true);
                }
            }
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "showErrorToast", "showToast('error', '" + HttpUtility.JavaScriptStringEncode(ex.Message) + "', 'Error');", true);
        }
    }
    #endregion
}