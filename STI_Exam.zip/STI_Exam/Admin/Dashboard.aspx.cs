﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ApiSalesData_Dashboard : System.Web.UI.Page
{
    #region
    StiExam obj = new StiExam();
    protected string TotalCourse = string.Empty;
    protected string TotalCandidate = string.Empty;
    protected string Upcoming = string.Empty;
    #endregion
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserId"] != null)
            {
                GetDashboardCounter();
            }
        }
    }
    #region GetDashboardCounter
    private void GetDashboardCounter()
    {
        try
        {
            DataSet ds = obj.GetDashboardCounter(Session["UserId"].ToString());
            if (ds.Tables[0].Rows.Count > 0)
            {
                TotalCourse = ds.Tables[0].Rows[0]["TotalCourses"].ToString();
                TotalCandidate = ds.Tables[1].Rows[0]["TotalCandidate"].ToString();
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
}