﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Configuration;
using System.IO;
using Org.BouncyCastle.Asn1.Cmp;

public partial class Admin_AddUpdateCandidate : System.Web.UI.Page
{
    #region DeclareVariable
    StiExam obj = new StiExam();
    #endregion
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!IsPostBack)
        {
            // Generate a new CSRF token and store it in ViewState
            string csrfToken = Guid.NewGuid().ToString();
            ViewState["CSRFToken"] = csrfToken;

            // Set the value of the hidden field to the CSRF token
            hndCsrfToken.Value = csrfToken;

            txtDate.Text = DateTime.Now.ToString("yyyy-MM-dd");
            txtDate.Attributes["max"] = DateTime.Now.ToString("yyyy-MM-dd");
            txtDateOfBirth.Attributes["max"] = DateTime.Now.ToString("yyyy-MM-dd");
            txtAddess.Attributes.Add("maxlength", txtAddess.MaxLength.ToString());
            if (Session["UserId"] != null)
            {
                GetCourseDetails();
                GetCandidateList();
            }
        }
    }
    #region GetCourseDetails
    private void GetCourseDetails()
    {
        try
        {
            DataSet ds = obj.GetCourseDetails(Session["UserId"].ToString());
            if (ds.Tables[2].Rows.Count > 0)
            {
                ddlCandidateApplyForCourse.DataSource = ds.Tables[2];
                ddlCandidateApplyForCourse.DataTextField = "CourseName";
                ddlCandidateApplyForCourse.DataValueField = "CourseID";
                ddlCandidateApplyForCourse.DataBind();
                ddlCandidateApplyForCourse.Items.Insert(0, new ListItem("--Select Course--", ""));
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region GetCandidateList
    private void GetCandidateList()
    {
        try
        {
            DataSet ds = obj.GetCandidateList(Session["UserId"].ToString());
            if (ds.Tables[0].Rows.Count > 0)
            {
                GrdCandidateList.DataSource = ds.Tables[0];
                GrdCandidateList.DataBind();
            }
            else
            {
                GrdCandidateList.DataSource = ds.Tables[0];
                GrdCandidateList.DataBind();
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region AddUpdateCandidateDetail
    protected void btnAddUpdateCandidate_Click(object sender, EventArgs e)
    {
        int success = 0;
        string FileName = string.Empty;
        string ProfileFolderPath = string.Empty;
        try
        {
            if (ViewState["CSRFToken"] != null && ViewState["CSRFToken"].ToString() == hndCsrfToken.Value)
            {
                DataSet ds = obj.GetCourseDetails(Session["UserId"].ToString(),ddlCandidateApplyForCourse.SelectedValue);
                if (ds.Tables[4].Rows.Count > 0)
                {
                    if (Convert.ToInt32(ds.Tables[4].Rows[0]["RemainingSpots"]) > 0)
                    {
                        success = obj.AddUpdateCandidateDetail(Session["UserId"].ToString(), hndCandidateId.Value.ToString(), HttpUtility.HtmlEncode(txtCandidateAadharNumber.Text.Trim())
                            , HttpUtility.HtmlEncode(txtCandidateName.Text.Trim()), HttpUtility.HtmlEncode(txtFatherHusbandName.Text.Trim()),
                            HttpUtility.HtmlEncode(txtMotherName.Text.Trim()), HttpUtility.HtmlEncode(txtCandidateQualification.Text.Trim()),
                            ddlCandidateApplyForCourse.SelectedValue, HttpUtility.HtmlEncode(txtCandidateMobileNumber.Text.Trim())
                            , HttpUtility.HtmlEncode(txtGuardianMobileNumber.Text.Trim()), ddlGender.SelectedValue, HttpUtility.HtmlEncode(txtDateOfBirth.Text.Trim()),
                            ddlCast.SelectedValue, HttpUtility.HtmlEncode(txtDate.Text.Trim()), HttpUtility.HtmlEncode(txtPlace.Text.Trim()),
                            HttpUtility.HtmlEncode(txtPincode.Text.Trim()), HttpUtility.HtmlEncode(txtAddess.Text.Trim()), hndProfileName.Value);
                        if (success > 0)
                        {
                            if (hndCandidateId.Value != "")
                            {
                                ScriptManager.RegisterStartupScript(this, this.GetType(), "showSuccessToast", "showToast('success', 'Candidate is successfully updated.', 'Success');", true);
                            }
                            else
                            {
                                ScriptManager.RegisterStartupScript(this, this.GetType(), "showSuccessToast", "showToast('success', 'Candidate is successfully added.', 'Success');", true);
                            }
                            ClearFormData();
                            GetCandidateList();
                        }
                        else
                        {
                            ScriptManager.RegisterStartupScript(this, this.GetType(), "showErrorToast", "showToast('error', 'Candidate is not added. Please try again later!', 'Error');", true);
                        }
                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "showErrorToast", "showToast('error', 'Student limit is full for selected course. Please increase the Student limit of selected course.', 'Error');", true);
                    }
                }
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "showErrorToast", "showToast('error', 'Invalid CSRF token. Please try again later!', 'Error');", true);
            }
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "showErrorToast", "showToast('error', '" + HttpUtility.JavaScriptStringEncode(ex.Message) + "', 'Error');", true);
        }
    }
    #endregion
    #region ResetPageData
    protected void btnReset_Click(object sender, EventArgs e)
    {
        try
        {
            ClearFormData();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region ClearFormData
    private void ClearFormData()
    {
        try
        {
            hndCandidateId.Value = "";
            txtCandidateAadharNumber.Text = "";
            txtCandidateName.Text = "";
            txtFatherHusbandName.Text = "";
            txtMotherName.Text = "";
            txtCandidateQualification.Text = "";
            ddlCandidateApplyForCourse.SelectedValue = "";
            txtCandidateMobileNumber.Text = "";
            txtGuardianMobileNumber.Text = "";
            ddlGender.SelectedValue = "";
            txtDateOfBirth.Text = "";
            ddlCast.SelectedValue = "";
            txtDate.Text = "";
            txtPlace.Text = "";
            txtPincode.Text = "";
            txtAddess.Text = "";
            btnAddUpdateCandidate.Text= "Add Candidate";  
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region EditCandidateDetails
    protected void GrdCandidateList_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        int success = 0;
        try
        {
            if (e.CommandName.Equals("EditCandidate"))
            {
                hndCandidateId.Value = e.CommandArgument.ToString();
                DataSet ds = obj.GetCandidateList(Session["UserID"].ToString(), hndCandidateId.Value);
                if (ds.Tables[1].Rows.Count > 0)
                {
                    txtCandidateAadharNumber.Text = HttpUtility.HtmlDecode(ds.Tables[1].Rows[0]["CandidateAadharNo"].ToString());
                    txtCandidateName.Text = HttpUtility.HtmlDecode(ds.Tables[1].Rows[0]["CandidateName"].ToString());
                    txtFatherHusbandName.Text = HttpUtility.HtmlDecode(ds.Tables[1].Rows[0]["Father_HusbandName"].ToString());
                    txtMotherName.Text = HttpUtility.HtmlDecode(ds.Tables[1].Rows[0]["MotherName"].ToString());
                    txtCandidateQualification.Text = HttpUtility.HtmlDecode(ds.Tables[1].Rows[0]["CandidateQualification"].ToString());
                    ddlCandidateApplyForCourse.SelectedValue = HttpUtility.HtmlDecode(ds.Tables[1].Rows[0]["CourseID"].ToString());
                    txtCandidateMobileNumber.Text = HttpUtility.HtmlDecode(ds.Tables[1].Rows[0]["MobileNo"].ToString());
                    txtGuardianMobileNumber.Text = HttpUtility.HtmlDecode(ds.Tables[1].Rows[0]["GuardianMobileNo"].ToString());
                    ddlGender.SelectedValue = HttpUtility.HtmlDecode(ds.Tables[1].Rows[0]["Gender"].ToString());
                    txtDateOfBirth.Text = HttpUtility.HtmlDecode(ds.Tables[1].Rows[0]["DateOfBirth"].ToString());
                    ddlCast.SelectedValue = HttpUtility.HtmlDecode(ds.Tables[1].Rows[0]["Caste"].ToString());
                    txtDate.Text = HttpUtility.HtmlDecode(ds.Tables[1].Rows[0]["RegisterationDate"].ToString());
                    txtPlace.Text = HttpUtility.HtmlDecode(ds.Tables[1].Rows[0]["Place"].ToString());
                    txtPincode.Text = HttpUtility.HtmlDecode(ds.Tables[1].Rows[0]["PinCode"].ToString());
                    txtAddess.Text = HttpUtility.HtmlDecode(ds.Tables[1].Rows[0]["PermanentAddress"].ToString());
                    hndProfileName.Value = HttpUtility.HtmlDecode(ds.Tables[1].Rows[0]["PhotoFileName"].ToString());
                    imgPhoto.ImageUrl = "~/WriteReadData/Profile/" + hndProfileName.Value;
                    btnAddUpdateCandidate.Text = "Update Candidate";
                    btnAddUpdateCandidate.ToolTip = "Click here to update Candidate details";
                    btnAddUpdateCandidate.Focus();
                }
            }
            if (e.CommandName.Equals("DeleteCandidate"))
            {
                hndCandidateId.Value = e.CommandArgument.ToString();
                success = obj.DeleteRecord(Session["UserID"].ToString(), hndCandidateId.Value, "DeleteCandidate");
                if (success > 0)
                {
                    GetCandidateList();
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "showSuccessToast", "showToast('success', 'Candidate is successfully deleted.', 'Success');", true);
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "showErrorToast", "showToast('error', 'Candidate is not deleted. Please try again later!', 'Error');", true);
                }
            }
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "showErrorToast", "showToast('error', '" + HttpUtility.JavaScriptStringEncode(ex.Message) + "', 'Error');", true);
        }
    }
    #endregion
    #region UploadPrfile
    protected void btnUploadProfile_Click(object sender, EventArgs e)
    {
        string FileName = string.Empty;
        string ProfileFolderPath = string.Empty;
        try
        {
            if (fuPhoto.HasFile)
            {
                string FileExt = Path.GetExtension(fuPhoto.FileName);
                decimal FileSize = Math.Round(((decimal)fuPhoto.PostedFile.ContentLength / (decimal)1024), 2);
                if (FileExt.Equals(".jpeg") || FileExt.Equals(".jpg"))
                {
                    if (FileSize <= 5000)
                    {
                        ProfileFolderPath = Server.MapPath(WebConfigurationManager.AppSettings["Profile"]);
                        FileName = Path.GetFileNameWithoutExtension(fuPhoto.PostedFile.FileName) + "_" + DateTime.Now.ToString("yyyy-dd-M--HH-mm-ss") + FileExt;
                        if (!Directory.Exists(ProfileFolderPath))
                        {
                            Directory.CreateDirectory(ProfileFolderPath);
                        }
                        if (FileName.Length > 4)
                        {
                            fuPhoto.PostedFile.SaveAs(ProfileFolderPath + "\\" + FileName);
                            hndProfileName.Value = FileName;
                            imgPhoto.ImageUrl = "~/WriteReadData/Profile/" + FileName;
                        }
                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "showErrorToast", "showToast('error', 'The file size exceeds 5 MB. Kindly resubmit the document with a file size not exceeding 5 MB', 'Error');", true);
                        return;
                    }
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "showErrorToast", "showToast('error', 'we need you to upload documents in either jpeg or jpg file formats only', 'Error');", true);
                    return;
                }
            }
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "showErrorToast", "showToast('error', '" + HttpUtility.JavaScriptStringEncode(ex.Message) + "', 'Error');", true);
        }
    }
    #endregion
}